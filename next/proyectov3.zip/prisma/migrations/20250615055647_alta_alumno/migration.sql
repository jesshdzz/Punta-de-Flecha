/*
  Warnings:

  - The values [INSCRIPCION,REINSCRIPCION,BAJA,PAGO,CAMBIO_GRUPO,SOLICITUD_DOCUMENTO,OTRO] on the enum `Tramite_tipo` will be removed. If these variants are still used in the database, this will fail.
  - The values [PENDIENTE,ACEPTADO,RECHAZADO] on the enum `Tramite_estado` will be removed. If these variants are still used in the database, this will fail.
  - The values [ADMINISTRADOR,PROFESOR,ESTUDIANTE,PADRE_FAMILIA,SECRETARIA] on the enum `Usuario_puesto` will be removed. If these variants are still used in the database, this will fail.

*/
-- AlterTable
ALTER TABLE `Tramite` MODIFY `tipo` ENUM('Inscripcion', 'Reinscripcion', 'Baja', 'Pago', 'Solicitud_documento', 'Otro') NOT NULL,
    MODIFY `estado` ENUM('Aceptado', 'Pendiente', 'Rechazado') NOT NULL;

-- AlterTable
ALTER TABLE `Usuario` MODIFY `puesto` ENUM('Administrador', 'Profesor', 'Estudiante', 'Padre_familia', 'Secretaria') NOT NULL;
