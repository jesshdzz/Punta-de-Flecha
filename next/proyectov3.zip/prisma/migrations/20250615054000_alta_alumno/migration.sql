/*
  Warnings:

  - You are about to drop the column `estudianteId` on the `Inscripcion` table. All the data in the column will be lost.
  - You are about to drop the column `fecha` on the `Inscripcion` table. All the data in the column will be lost.
  - You are about to drop the column `estado` on the `Pago` table. All the data in the column will be lost.
  - You are about to drop the column `estudianteId` on the `Pago` table. All the data in the column will be lost.
  - You are about to drop the column `fecha` on the `Pago` table. All the data in the column will be lost.
  - You are about to alter the column `tipo` on the `Tramite` table. The data in that column could be lost. The data in that column will be cast from `VarChar(191)` to `Enum(EnumId(1))`.
  - You are about to alter the column `estado` on the `Tramite` table. The data in that column could be lost. The data in that column will be cast from `VarChar(191)` to `Enum(EnumId(2))`.
  - You are about to drop the column `fechaCreado` on the `Usuario` table. All the data in the column will be lost.
  - Added the required column `tramiteId` to the `Inscripcion` table without a default value. This is not possible if the table is not empty.
  - Added the required column `tramiteId` to the `Pago` table without a default value. This is not possible if the table is not empty.
  - Added the required column `monto` to the `Recibo` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE `Inscripcion` DROP FOREIGN KEY `Inscripcion_estudianteId_fkey`;

-- DropForeignKey
ALTER TABLE `Pago` DROP FOREIGN KEY `Pago_estudianteId_fkey`;

-- DropIndex
DROP INDEX `Inscripcion_estudianteId_fkey` ON `Inscripcion`;

-- DropIndex
DROP INDEX `Pago_estudianteId_fkey` ON `Pago`;

-- AlterTable
ALTER TABLE `Inscripcion` DROP COLUMN `estudianteId`,
    DROP COLUMN `fecha`,
    ADD COLUMN `tramiteId` INTEGER NOT NULL;

-- AlterTable
ALTER TABLE `Pago` DROP COLUMN `estado`,
    DROP COLUMN `estudianteId`,
    DROP COLUMN `fecha`,
    ADD COLUMN `tramiteId` INTEGER NOT NULL;

-- AlterTable
ALTER TABLE `Recibo` ADD COLUMN `monto` DOUBLE NOT NULL;

-- AlterTable
ALTER TABLE `Tramite` MODIFY `tipo` ENUM('INSCRIPCION', 'REINSCRIPCION', 'BAJA', 'PAGO', 'CAMBIO_GRUPO', 'SOLICITUD_DOCUMENTO', 'OTRO') NOT NULL,
    MODIFY `estado` ENUM('PENDIENTE', 'ACEPTADO', 'RECHAZADO') NOT NULL;

-- AlterTable
ALTER TABLE `Usuario` DROP COLUMN `fechaCreado`,
    ADD COLUMN `fechaCreacion` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3);

-- AddForeignKey
ALTER TABLE `Inscripcion` ADD CONSTRAINT `Inscripcion_tramiteId_fkey` FOREIGN KEY (`tramiteId`) REFERENCES `Tramite`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `Inscripcion` ADD CONSTRAINT `Inscripcion_grupoId_fkey` FOREIGN KEY (`grupoId`) REFERENCES `Grupo`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `Pago` ADD CONSTRAINT `Pago_tramiteId_fkey` FOREIGN KEY (`tramiteId`) REFERENCES `Tramite`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
