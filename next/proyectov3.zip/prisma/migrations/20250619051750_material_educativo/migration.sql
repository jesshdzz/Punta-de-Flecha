/*
  Warnings:

  - Added the required column `grupoId` to the `MaterialEducativo` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE `MaterialEducativo` ADD COLUMN `grupoId` INTEGER NOT NULL;

-- AddForeignKey
ALTER TABLE `MaterialEducativo` ADD CONSTRAINT `MaterialEducativo_grupoId_fkey` FOREIGN KEY (`grupoId`) REFERENCES `Grupo`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
