/*
  Warnings:

  - The values [Baja] on the enum `Tramite_tipo` will be removed. If these variants are still used in the database, this will fail.

*/
-- AlterTable
ALTER TABLE `Estudiante` ADD COLUMN `estado` ENUM('Activo', 'BajaTemporal', 'BajaDefinitiva') NOT NULL DEFAULT 'Activo';

-- AlterTable
ALTER TABLE `Tramite` MODIFY `tipo` ENUM('Inscripcion', 'Reinscripcion', 'BajaTemporal', 'BajaDefinitiva', 'Pago') NOT NULL;

-- CreateTable
CREATE TABLE `Profesor` (
    `usuarioId` INTEGER NOT NULL,

    PRIMARY KEY (`usuarioId`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `MaterialEducativo` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `titulo` VARCHAR(191) NOT NULL,
    `descripcion` VARCHAR(191) NOT NULL,
    `categoria` VARCHAR(191) NOT NULL,
    `existencia` BOOLEAN NOT NULL DEFAULT false,
    `fecha` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `tipoArchivo` VARCHAR(191) NOT NULL,
    `profesorId` INTEGER NOT NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `ArchivoSubido` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `materialId` INTEGER NOT NULL,
    `nombreArchivo` VARCHAR(191) NOT NULL,
    `urlNube` VARCHAR(191) NOT NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AddForeignKey
ALTER TABLE `Profesor` ADD CONSTRAINT `Profesor_usuarioId_fkey` FOREIGN KEY (`usuarioId`) REFERENCES `Usuario`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `MaterialEducativo` ADD CONSTRAINT `MaterialEducativo_profesorId_fkey` FOREIGN KEY (`profesorId`) REFERENCES `Profesor`(`usuarioId`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `ArchivoSubido` ADD CONSTRAINT `ArchivoSubido_materialId_fkey` FOREIGN KEY (`materialId`) REFERENCES `MaterialEducativo`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
