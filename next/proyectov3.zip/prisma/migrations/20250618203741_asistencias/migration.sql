/*
  Warnings:

  - You are about to drop the column `asistencia1` on the `Calificacion` table. All the data in the column will be lost.
  - You are about to drop the column `asistencia2` on the `Calificacion` table. All the data in the column will be lost.
  - You are about to drop the column `asistenciaFin` on the `Calificacion` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE `Calificacion` DROP COLUMN `asistencia1`,
    DROP COLUMN `asistencia2`,
    DROP COLUMN `asistenciaFin`;

-- CreateTable
CREATE TABLE `Asistencia` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `estudianteId` INTEGER NOT NULL,
    `materiaId` INTEGER NOT NULL,
    `parcial1` INTEGER NOT NULL DEFAULT 0,
    `parcial2` INTEGER NOT NULL DEFAULT 0,
    `final` INTEGER NOT NULL DEFAULT 0,
    `fecha` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AddForeignKey
ALTER TABLE `Asistencia` ADD CONSTRAINT `Asistencia_estudianteId_fkey` FOREIGN KEY (`estudianteId`) REFERENCES `Estudiante`(`usuarioId`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `Asistencia` ADD CONSTRAINT `Asistencia_materiaId_fkey` FOREIGN KEY (`materiaId`) REFERENCES `Materia`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
