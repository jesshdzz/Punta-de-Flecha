/*
  Warnings:

  - The values [Solicitud_documento,Otro] on the enum `Tramite_tipo` will be removed. If these variants are still used in the database, this will fail.

*/
-- AlterTable
ALTER TABLE `Tramite` MODIFY `tipo` ENUM('Inscripcion', 'Reinscripcion', 'Baja', 'Pago') NOT NULL;
