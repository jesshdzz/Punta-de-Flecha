-- AlterTable
ALTER TABLE `Estudiante` ADD COLUMN `padreFamiliaId` INTEGER NULL;

-- CreateTable
CREATE TABLE `PadreFamilia` (
    `usuarioId` INTEGER NOT NULL,
    `domicilio` VARCHAR(191) NOT NULL,

    PRIMARY KEY (`usuarioId`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AddForeignKey
ALTER TABLE `Estudiante` ADD CONSTRAINT `Estudiante_padreFamiliaId_fkey` FOREIGN KEY (`padreFamiliaId`) REFERENCES `PadreFamilia`(`usuarioId`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `PadreFamilia` ADD CONSTRAINT `PadreFamilia_usuarioId_fkey` FOREIGN KEY (`usuarioId`) REFERENCES `Usuario`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
