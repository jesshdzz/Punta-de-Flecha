/*
  Warnings:

  - You are about to drop the column `asistencias` on the `Calificacion` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE `Calificacion` DROP COLUMN `asistencias`,
    ADD COLUMN `asistencia1` INTEGER NOT NULL DEFAULT 0,
    ADD COLUMN `asistencia2` INTEGER NOT NULL DEFAULT 0,
    ADD COLUMN `asistenciaFin` INTEGER NOT NULL DEFAULT 0,
    MODIFY `parcial1` DOUBLE NOT NULL DEFAULT 0.0,
    MODIFY `parcial2` DOUBLE NOT NULL DEFAULT 0.0,
    MODIFY `ordinario` DOUBLE NOT NULL DEFAULT 0.0,
    MODIFY `final` DOUBLE NOT NULL DEFAULT 0.0;
