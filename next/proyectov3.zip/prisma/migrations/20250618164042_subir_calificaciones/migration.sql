/*
  Warnings:

  - You are about to drop the column `parcial3` on the `Calificacion` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE `Calificacion` DROP COLUMN `parcial3`;
