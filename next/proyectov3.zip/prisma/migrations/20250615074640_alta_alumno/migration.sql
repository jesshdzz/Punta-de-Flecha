/*
  Warnings:

  - The primary key for the `Estudiante` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `id` on the `Estudiante` table. All the data in the column will be lost.
  - The primary key for the `Inscripcion` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `id` on the `Inscripcion` table. All the data in the column will be lost.
  - The primary key for the `Pago` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `id` on the `Pago` table. All the data in the column will be lost.
  - Added the required column `grado` to the `Grupo` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE `Recibo` DROP FOREIGN KEY `Recibo_pagoId_fkey`;

-- DropForeignKey
ALTER TABLE `Tramite` DROP FOREIGN KEY `Tramite_estudianteId_fkey`;

-- DropIndex
DROP INDEX `Recibo_pagoId_fkey` ON `Recibo`;

-- DropIndex
DROP INDEX `Tramite_estudianteId_fkey` ON `Tramite`;

-- AlterTable
ALTER TABLE `Estudiante` DROP PRIMARY KEY,
    DROP COLUMN `id`,
    ADD PRIMARY KEY (`usuarioId`);

-- AlterTable
ALTER TABLE `Grupo` ADD COLUMN `grado` INTEGER NOT NULL;

-- AlterTable
ALTER TABLE `Inscripcion` DROP PRIMARY KEY,
    DROP COLUMN `id`,
    ADD PRIMARY KEY (`tramiteId`);

-- AlterTable
ALTER TABLE `Pago` DROP PRIMARY KEY,
    DROP COLUMN `id`,
    ADD PRIMARY KEY (`tramiteId`);

-- AddForeignKey
ALTER TABLE `Tramite` ADD CONSTRAINT `Tramite_estudianteId_fkey` FOREIGN KEY (`estudianteId`) REFERENCES `Estudiante`(`usuarioId`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `Recibo` ADD CONSTRAINT `Recibo_pagoId_fkey` FOREIGN KEY (`pagoId`) REFERENCES `Pago`(`tramiteId`) ON DELETE RESTRICT ON UPDATE CASCADE;
