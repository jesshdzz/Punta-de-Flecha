export class Horario{
    
}