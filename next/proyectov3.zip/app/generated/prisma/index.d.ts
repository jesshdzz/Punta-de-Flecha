
/**
 * Client
**/

import * as runtime from './runtime/library.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model Usuario
 * 
 */
export type Usuario = $Result.DefaultSelection<Prisma.$UsuarioPayload>
/**
 * Model Estudiante
 * 
 */
export type Estudiante = $Result.DefaultSelection<Prisma.$EstudiantePayload>
/**
 * Model Profesor
 * 
 */
export type Profesor = $Result.DefaultSelection<Prisma.$ProfesorPayload>
/**
 * Model PadreFamilia
 * 
 */
export type PadreFamilia = $Result.DefaultSelection<Prisma.$PadreFamiliaPayload>
/**
 * Model Grupo
 * 
 */
export type Grupo = $Result.DefaultSelection<Prisma.$GrupoPayload>
/**
 * Model Tramite
 * 
 */
export type Tramite = $Result.DefaultSelection<Prisma.$TramitePayload>
/**
 * Model Inscripcion
 * 
 */
export type Inscripcion = $Result.DefaultSelection<Prisma.$InscripcionPayload>
/**
 * Model Pago
 * 
 */
export type Pago = $Result.DefaultSelection<Prisma.$PagoPayload>
/**
 * Model Recibo
 * 
 */
export type Recibo = $Result.DefaultSelection<Prisma.$ReciboPayload>
/**
 * Model MaterialEducativo
 * 
 */
export type MaterialEducativo = $Result.DefaultSelection<Prisma.$MaterialEducativoPayload>
/**
 * Model ArchivoSubido
 * 
 */
export type ArchivoSubido = $Result.DefaultSelection<Prisma.$ArchivoSubidoPayload>
/**
 * Model Materia
 * 
 */
export type Materia = $Result.DefaultSelection<Prisma.$MateriaPayload>
/**
 * Model Calificacion
 * 
 */
export type Calificacion = $Result.DefaultSelection<Prisma.$CalificacionPayload>
/**
 * Model Asistencia
 * 
 */
export type Asistencia = $Result.DefaultSelection<Prisma.$AsistenciaPayload>

/**
 * Enums
 */
export namespace $Enums {
  export const RolUsuario: {
  Administrador: 'Administrador',
  Profesor: 'Profesor',
  Estudiante: 'Estudiante',
  Padre_familia: 'Padre_familia',
  Secretaria: 'Secretaria'
};

export type RolUsuario = (typeof RolUsuario)[keyof typeof RolUsuario]


export const EstadoTramite: {
  Aceptado: 'Aceptado',
  Pendiente: 'Pendiente',
  Rechazado: 'Rechazado'
};

export type EstadoTramite = (typeof EstadoTramite)[keyof typeof EstadoTramite]


export const TipoTramite: {
  Inscripcion: 'Inscripcion',
  Reinscripcion: 'Reinscripcion',
  BajaTemporal: 'BajaTemporal',
  BajaDefinitiva: 'BajaDefinitiva',
  Pago: 'Pago'
};

export type TipoTramite = (typeof TipoTramite)[keyof typeof TipoTramite]


export const EstadoEstudiante: {
  Activo: 'Activo',
  BajaTemporal: 'BajaTemporal',
  BajaDefinitiva: 'BajaDefinitiva'
};

export type EstadoEstudiante = (typeof EstadoEstudiante)[keyof typeof EstadoEstudiante]

}

export type RolUsuario = $Enums.RolUsuario

export const RolUsuario: typeof $Enums.RolUsuario

export type EstadoTramite = $Enums.EstadoTramite

export const EstadoTramite: typeof $Enums.EstadoTramite

export type TipoTramite = $Enums.TipoTramite

export const TipoTramite: typeof $Enums.TipoTramite

export type EstadoEstudiante = $Enums.EstadoEstudiante

export const EstadoEstudiante: typeof $Enums.EstadoEstudiante

/**
 * ##  Prisma Client ʲˢ
 *
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient()
 * // Fetch zero or more Usuarios
 * const usuarios = await prisma.usuario.findMany()
 * ```
 *
 *
 * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
 */
export class PrismaClient<
  ClientOptions extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  U = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   *
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient()
   * // Fetch zero or more Usuarios
   * const usuarios = await prisma.usuario.findMany()
   * ```
   *
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
   */

  constructor(optionsArg ?: Prisma.Subset<ClientOptions, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): PrismaClient;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

  /**
   * Add a middleware
   * @deprecated since 4.16.0. For new code, prefer client extensions instead.
   * @see https://pris.ly/d/extensions
   */
  $use(cb: Prisma.Middleware): void

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;


  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/concepts/components/prisma-client/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>


  $extends: $Extensions.ExtendsHook<"extends", Prisma.TypeMapCb<ClientOptions>, ExtArgs, $Utils.Call<Prisma.TypeMapCb<ClientOptions>, {
    extArgs: ExtArgs
  }>>

      /**
   * `prisma.usuario`: Exposes CRUD operations for the **Usuario** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Usuarios
    * const usuarios = await prisma.usuario.findMany()
    * ```
    */
  get usuario(): Prisma.UsuarioDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.estudiante`: Exposes CRUD operations for the **Estudiante** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Estudiantes
    * const estudiantes = await prisma.estudiante.findMany()
    * ```
    */
  get estudiante(): Prisma.EstudianteDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.profesor`: Exposes CRUD operations for the **Profesor** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Profesors
    * const profesors = await prisma.profesor.findMany()
    * ```
    */
  get profesor(): Prisma.ProfesorDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.padreFamilia`: Exposes CRUD operations for the **PadreFamilia** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more PadreFamilias
    * const padreFamilias = await prisma.padreFamilia.findMany()
    * ```
    */
  get padreFamilia(): Prisma.PadreFamiliaDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.grupo`: Exposes CRUD operations for the **Grupo** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Grupos
    * const grupos = await prisma.grupo.findMany()
    * ```
    */
  get grupo(): Prisma.GrupoDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.tramite`: Exposes CRUD operations for the **Tramite** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Tramites
    * const tramites = await prisma.tramite.findMany()
    * ```
    */
  get tramite(): Prisma.TramiteDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.inscripcion`: Exposes CRUD operations for the **Inscripcion** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Inscripcions
    * const inscripcions = await prisma.inscripcion.findMany()
    * ```
    */
  get inscripcion(): Prisma.InscripcionDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.pago`: Exposes CRUD operations for the **Pago** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Pagos
    * const pagos = await prisma.pago.findMany()
    * ```
    */
  get pago(): Prisma.PagoDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.recibo`: Exposes CRUD operations for the **Recibo** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Recibos
    * const recibos = await prisma.recibo.findMany()
    * ```
    */
  get recibo(): Prisma.ReciboDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.materialEducativo`: Exposes CRUD operations for the **MaterialEducativo** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more MaterialEducativos
    * const materialEducativos = await prisma.materialEducativo.findMany()
    * ```
    */
  get materialEducativo(): Prisma.MaterialEducativoDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.archivoSubido`: Exposes CRUD operations for the **ArchivoSubido** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more ArchivoSubidos
    * const archivoSubidos = await prisma.archivoSubido.findMany()
    * ```
    */
  get archivoSubido(): Prisma.ArchivoSubidoDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.materia`: Exposes CRUD operations for the **Materia** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Materias
    * const materias = await prisma.materia.findMany()
    * ```
    */
  get materia(): Prisma.MateriaDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.calificacion`: Exposes CRUD operations for the **Calificacion** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Calificacions
    * const calificacions = await prisma.calificacion.findMany()
    * ```
    */
  get calificacion(): Prisma.CalificacionDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.asistencia`: Exposes CRUD operations for the **Asistencia** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Asistencias
    * const asistencias = await prisma.asistencia.findMany()
    * ```
    */
  get asistencia(): Prisma.AsistenciaDelegate<ExtArgs, ClientOptions>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql



  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
   * Metrics
   */
  export type Metrics = runtime.Metrics
  export type Metric<T> = runtime.Metric<T>
  export type MetricHistogram = runtime.MetricHistogram
  export type MetricHistogramBucket = runtime.MetricHistogramBucket

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 6.9.0
   * Query Engine version: 81e4af48011447c3cc503a190e86995b66d2a28e
   */
  export type PrismaVersion = {
    client: string
  }

  export const prismaVersion: PrismaVersion

  /**
   * Utility Types
   */


  export import JsonObject = runtime.JsonObject
  export import JsonArray = runtime.JsonArray
  export import JsonValue = runtime.JsonValue
  export import InputJsonObject = runtime.InputJsonObject
  export import InputJsonArray = runtime.InputJsonArray
  export import InputJsonValue = runtime.InputJsonValue

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? P : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    Usuario: 'Usuario',
    Estudiante: 'Estudiante',
    Profesor: 'Profesor',
    PadreFamilia: 'PadreFamilia',
    Grupo: 'Grupo',
    Tramite: 'Tramite',
    Inscripcion: 'Inscripcion',
    Pago: 'Pago',
    Recibo: 'Recibo',
    MaterialEducativo: 'MaterialEducativo',
    ArchivoSubido: 'ArchivoSubido',
    Materia: 'Materia',
    Calificacion: 'Calificacion',
    Asistencia: 'Asistencia'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]


  export type Datasources = {
    db?: Datasource
  }

  interface TypeMapCb<ClientOptions = {}> extends $Utils.Fn<{extArgs: $Extensions.InternalArgs }, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs'], ClientOptions extends { omit: infer OmitOptions } ? OmitOptions : {}>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> = {
    globalOmitOptions: {
      omit: GlobalOmitOptions
    }
    meta: {
      modelProps: "usuario" | "estudiante" | "profesor" | "padreFamilia" | "grupo" | "tramite" | "inscripcion" | "pago" | "recibo" | "materialEducativo" | "archivoSubido" | "materia" | "calificacion" | "asistencia"
      txIsolationLevel: Prisma.TransactionIsolationLevel
    }
    model: {
      Usuario: {
        payload: Prisma.$UsuarioPayload<ExtArgs>
        fields: Prisma.UsuarioFieldRefs
        operations: {
          findUnique: {
            args: Prisma.UsuarioFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UsuarioPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.UsuarioFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UsuarioPayload>
          }
          findFirst: {
            args: Prisma.UsuarioFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UsuarioPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.UsuarioFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UsuarioPayload>
          }
          findMany: {
            args: Prisma.UsuarioFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UsuarioPayload>[]
          }
          create: {
            args: Prisma.UsuarioCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UsuarioPayload>
          }
          createMany: {
            args: Prisma.UsuarioCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.UsuarioDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UsuarioPayload>
          }
          update: {
            args: Prisma.UsuarioUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UsuarioPayload>
          }
          deleteMany: {
            args: Prisma.UsuarioDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.UsuarioUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.UsuarioUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UsuarioPayload>
          }
          aggregate: {
            args: Prisma.UsuarioAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateUsuario>
          }
          groupBy: {
            args: Prisma.UsuarioGroupByArgs<ExtArgs>
            result: $Utils.Optional<UsuarioGroupByOutputType>[]
          }
          count: {
            args: Prisma.UsuarioCountArgs<ExtArgs>
            result: $Utils.Optional<UsuarioCountAggregateOutputType> | number
          }
        }
      }
      Estudiante: {
        payload: Prisma.$EstudiantePayload<ExtArgs>
        fields: Prisma.EstudianteFieldRefs
        operations: {
          findUnique: {
            args: Prisma.EstudianteFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EstudiantePayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.EstudianteFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EstudiantePayload>
          }
          findFirst: {
            args: Prisma.EstudianteFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EstudiantePayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.EstudianteFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EstudiantePayload>
          }
          findMany: {
            args: Prisma.EstudianteFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EstudiantePayload>[]
          }
          create: {
            args: Prisma.EstudianteCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EstudiantePayload>
          }
          createMany: {
            args: Prisma.EstudianteCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.EstudianteDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EstudiantePayload>
          }
          update: {
            args: Prisma.EstudianteUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EstudiantePayload>
          }
          deleteMany: {
            args: Prisma.EstudianteDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.EstudianteUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.EstudianteUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EstudiantePayload>
          }
          aggregate: {
            args: Prisma.EstudianteAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateEstudiante>
          }
          groupBy: {
            args: Prisma.EstudianteGroupByArgs<ExtArgs>
            result: $Utils.Optional<EstudianteGroupByOutputType>[]
          }
          count: {
            args: Prisma.EstudianteCountArgs<ExtArgs>
            result: $Utils.Optional<EstudianteCountAggregateOutputType> | number
          }
        }
      }
      Profesor: {
        payload: Prisma.$ProfesorPayload<ExtArgs>
        fields: Prisma.ProfesorFieldRefs
        operations: {
          findUnique: {
            args: Prisma.ProfesorFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ProfesorPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.ProfesorFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ProfesorPayload>
          }
          findFirst: {
            args: Prisma.ProfesorFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ProfesorPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.ProfesorFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ProfesorPayload>
          }
          findMany: {
            args: Prisma.ProfesorFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ProfesorPayload>[]
          }
          create: {
            args: Prisma.ProfesorCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ProfesorPayload>
          }
          createMany: {
            args: Prisma.ProfesorCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.ProfesorDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ProfesorPayload>
          }
          update: {
            args: Prisma.ProfesorUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ProfesorPayload>
          }
          deleteMany: {
            args: Prisma.ProfesorDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.ProfesorUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.ProfesorUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ProfesorPayload>
          }
          aggregate: {
            args: Prisma.ProfesorAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateProfesor>
          }
          groupBy: {
            args: Prisma.ProfesorGroupByArgs<ExtArgs>
            result: $Utils.Optional<ProfesorGroupByOutputType>[]
          }
          count: {
            args: Prisma.ProfesorCountArgs<ExtArgs>
            result: $Utils.Optional<ProfesorCountAggregateOutputType> | number
          }
        }
      }
      PadreFamilia: {
        payload: Prisma.$PadreFamiliaPayload<ExtArgs>
        fields: Prisma.PadreFamiliaFieldRefs
        operations: {
          findUnique: {
            args: Prisma.PadreFamiliaFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PadreFamiliaPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.PadreFamiliaFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PadreFamiliaPayload>
          }
          findFirst: {
            args: Prisma.PadreFamiliaFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PadreFamiliaPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.PadreFamiliaFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PadreFamiliaPayload>
          }
          findMany: {
            args: Prisma.PadreFamiliaFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PadreFamiliaPayload>[]
          }
          create: {
            args: Prisma.PadreFamiliaCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PadreFamiliaPayload>
          }
          createMany: {
            args: Prisma.PadreFamiliaCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.PadreFamiliaDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PadreFamiliaPayload>
          }
          update: {
            args: Prisma.PadreFamiliaUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PadreFamiliaPayload>
          }
          deleteMany: {
            args: Prisma.PadreFamiliaDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.PadreFamiliaUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.PadreFamiliaUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PadreFamiliaPayload>
          }
          aggregate: {
            args: Prisma.PadreFamiliaAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregatePadreFamilia>
          }
          groupBy: {
            args: Prisma.PadreFamiliaGroupByArgs<ExtArgs>
            result: $Utils.Optional<PadreFamiliaGroupByOutputType>[]
          }
          count: {
            args: Prisma.PadreFamiliaCountArgs<ExtArgs>
            result: $Utils.Optional<PadreFamiliaCountAggregateOutputType> | number
          }
        }
      }
      Grupo: {
        payload: Prisma.$GrupoPayload<ExtArgs>
        fields: Prisma.GrupoFieldRefs
        operations: {
          findUnique: {
            args: Prisma.GrupoFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$GrupoPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.GrupoFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$GrupoPayload>
          }
          findFirst: {
            args: Prisma.GrupoFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$GrupoPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.GrupoFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$GrupoPayload>
          }
          findMany: {
            args: Prisma.GrupoFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$GrupoPayload>[]
          }
          create: {
            args: Prisma.GrupoCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$GrupoPayload>
          }
          createMany: {
            args: Prisma.GrupoCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.GrupoDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$GrupoPayload>
          }
          update: {
            args: Prisma.GrupoUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$GrupoPayload>
          }
          deleteMany: {
            args: Prisma.GrupoDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.GrupoUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.GrupoUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$GrupoPayload>
          }
          aggregate: {
            args: Prisma.GrupoAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateGrupo>
          }
          groupBy: {
            args: Prisma.GrupoGroupByArgs<ExtArgs>
            result: $Utils.Optional<GrupoGroupByOutputType>[]
          }
          count: {
            args: Prisma.GrupoCountArgs<ExtArgs>
            result: $Utils.Optional<GrupoCountAggregateOutputType> | number
          }
        }
      }
      Tramite: {
        payload: Prisma.$TramitePayload<ExtArgs>
        fields: Prisma.TramiteFieldRefs
        operations: {
          findUnique: {
            args: Prisma.TramiteFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TramitePayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.TramiteFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TramitePayload>
          }
          findFirst: {
            args: Prisma.TramiteFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TramitePayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.TramiteFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TramitePayload>
          }
          findMany: {
            args: Prisma.TramiteFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TramitePayload>[]
          }
          create: {
            args: Prisma.TramiteCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TramitePayload>
          }
          createMany: {
            args: Prisma.TramiteCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.TramiteDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TramitePayload>
          }
          update: {
            args: Prisma.TramiteUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TramitePayload>
          }
          deleteMany: {
            args: Prisma.TramiteDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.TramiteUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.TramiteUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TramitePayload>
          }
          aggregate: {
            args: Prisma.TramiteAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateTramite>
          }
          groupBy: {
            args: Prisma.TramiteGroupByArgs<ExtArgs>
            result: $Utils.Optional<TramiteGroupByOutputType>[]
          }
          count: {
            args: Prisma.TramiteCountArgs<ExtArgs>
            result: $Utils.Optional<TramiteCountAggregateOutputType> | number
          }
        }
      }
      Inscripcion: {
        payload: Prisma.$InscripcionPayload<ExtArgs>
        fields: Prisma.InscripcionFieldRefs
        operations: {
          findUnique: {
            args: Prisma.InscripcionFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$InscripcionPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.InscripcionFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$InscripcionPayload>
          }
          findFirst: {
            args: Prisma.InscripcionFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$InscripcionPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.InscripcionFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$InscripcionPayload>
          }
          findMany: {
            args: Prisma.InscripcionFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$InscripcionPayload>[]
          }
          create: {
            args: Prisma.InscripcionCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$InscripcionPayload>
          }
          createMany: {
            args: Prisma.InscripcionCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.InscripcionDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$InscripcionPayload>
          }
          update: {
            args: Prisma.InscripcionUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$InscripcionPayload>
          }
          deleteMany: {
            args: Prisma.InscripcionDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.InscripcionUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.InscripcionUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$InscripcionPayload>
          }
          aggregate: {
            args: Prisma.InscripcionAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateInscripcion>
          }
          groupBy: {
            args: Prisma.InscripcionGroupByArgs<ExtArgs>
            result: $Utils.Optional<InscripcionGroupByOutputType>[]
          }
          count: {
            args: Prisma.InscripcionCountArgs<ExtArgs>
            result: $Utils.Optional<InscripcionCountAggregateOutputType> | number
          }
        }
      }
      Pago: {
        payload: Prisma.$PagoPayload<ExtArgs>
        fields: Prisma.PagoFieldRefs
        operations: {
          findUnique: {
            args: Prisma.PagoFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PagoPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.PagoFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PagoPayload>
          }
          findFirst: {
            args: Prisma.PagoFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PagoPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.PagoFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PagoPayload>
          }
          findMany: {
            args: Prisma.PagoFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PagoPayload>[]
          }
          create: {
            args: Prisma.PagoCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PagoPayload>
          }
          createMany: {
            args: Prisma.PagoCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.PagoDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PagoPayload>
          }
          update: {
            args: Prisma.PagoUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PagoPayload>
          }
          deleteMany: {
            args: Prisma.PagoDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.PagoUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.PagoUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PagoPayload>
          }
          aggregate: {
            args: Prisma.PagoAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregatePago>
          }
          groupBy: {
            args: Prisma.PagoGroupByArgs<ExtArgs>
            result: $Utils.Optional<PagoGroupByOutputType>[]
          }
          count: {
            args: Prisma.PagoCountArgs<ExtArgs>
            result: $Utils.Optional<PagoCountAggregateOutputType> | number
          }
        }
      }
      Recibo: {
        payload: Prisma.$ReciboPayload<ExtArgs>
        fields: Prisma.ReciboFieldRefs
        operations: {
          findUnique: {
            args: Prisma.ReciboFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ReciboPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.ReciboFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ReciboPayload>
          }
          findFirst: {
            args: Prisma.ReciboFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ReciboPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.ReciboFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ReciboPayload>
          }
          findMany: {
            args: Prisma.ReciboFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ReciboPayload>[]
          }
          create: {
            args: Prisma.ReciboCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ReciboPayload>
          }
          createMany: {
            args: Prisma.ReciboCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.ReciboDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ReciboPayload>
          }
          update: {
            args: Prisma.ReciboUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ReciboPayload>
          }
          deleteMany: {
            args: Prisma.ReciboDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.ReciboUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.ReciboUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ReciboPayload>
          }
          aggregate: {
            args: Prisma.ReciboAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateRecibo>
          }
          groupBy: {
            args: Prisma.ReciboGroupByArgs<ExtArgs>
            result: $Utils.Optional<ReciboGroupByOutputType>[]
          }
          count: {
            args: Prisma.ReciboCountArgs<ExtArgs>
            result: $Utils.Optional<ReciboCountAggregateOutputType> | number
          }
        }
      }
      MaterialEducativo: {
        payload: Prisma.$MaterialEducativoPayload<ExtArgs>
        fields: Prisma.MaterialEducativoFieldRefs
        operations: {
          findUnique: {
            args: Prisma.MaterialEducativoFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MaterialEducativoPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.MaterialEducativoFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MaterialEducativoPayload>
          }
          findFirst: {
            args: Prisma.MaterialEducativoFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MaterialEducativoPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.MaterialEducativoFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MaterialEducativoPayload>
          }
          findMany: {
            args: Prisma.MaterialEducativoFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MaterialEducativoPayload>[]
          }
          create: {
            args: Prisma.MaterialEducativoCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MaterialEducativoPayload>
          }
          createMany: {
            args: Prisma.MaterialEducativoCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.MaterialEducativoDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MaterialEducativoPayload>
          }
          update: {
            args: Prisma.MaterialEducativoUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MaterialEducativoPayload>
          }
          deleteMany: {
            args: Prisma.MaterialEducativoDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.MaterialEducativoUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.MaterialEducativoUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MaterialEducativoPayload>
          }
          aggregate: {
            args: Prisma.MaterialEducativoAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateMaterialEducativo>
          }
          groupBy: {
            args: Prisma.MaterialEducativoGroupByArgs<ExtArgs>
            result: $Utils.Optional<MaterialEducativoGroupByOutputType>[]
          }
          count: {
            args: Prisma.MaterialEducativoCountArgs<ExtArgs>
            result: $Utils.Optional<MaterialEducativoCountAggregateOutputType> | number
          }
        }
      }
      ArchivoSubido: {
        payload: Prisma.$ArchivoSubidoPayload<ExtArgs>
        fields: Prisma.ArchivoSubidoFieldRefs
        operations: {
          findUnique: {
            args: Prisma.ArchivoSubidoFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ArchivoSubidoPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.ArchivoSubidoFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ArchivoSubidoPayload>
          }
          findFirst: {
            args: Prisma.ArchivoSubidoFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ArchivoSubidoPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.ArchivoSubidoFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ArchivoSubidoPayload>
          }
          findMany: {
            args: Prisma.ArchivoSubidoFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ArchivoSubidoPayload>[]
          }
          create: {
            args: Prisma.ArchivoSubidoCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ArchivoSubidoPayload>
          }
          createMany: {
            args: Prisma.ArchivoSubidoCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.ArchivoSubidoDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ArchivoSubidoPayload>
          }
          update: {
            args: Prisma.ArchivoSubidoUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ArchivoSubidoPayload>
          }
          deleteMany: {
            args: Prisma.ArchivoSubidoDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.ArchivoSubidoUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.ArchivoSubidoUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ArchivoSubidoPayload>
          }
          aggregate: {
            args: Prisma.ArchivoSubidoAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateArchivoSubido>
          }
          groupBy: {
            args: Prisma.ArchivoSubidoGroupByArgs<ExtArgs>
            result: $Utils.Optional<ArchivoSubidoGroupByOutputType>[]
          }
          count: {
            args: Prisma.ArchivoSubidoCountArgs<ExtArgs>
            result: $Utils.Optional<ArchivoSubidoCountAggregateOutputType> | number
          }
        }
      }
      Materia: {
        payload: Prisma.$MateriaPayload<ExtArgs>
        fields: Prisma.MateriaFieldRefs
        operations: {
          findUnique: {
            args: Prisma.MateriaFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MateriaPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.MateriaFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MateriaPayload>
          }
          findFirst: {
            args: Prisma.MateriaFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MateriaPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.MateriaFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MateriaPayload>
          }
          findMany: {
            args: Prisma.MateriaFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MateriaPayload>[]
          }
          create: {
            args: Prisma.MateriaCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MateriaPayload>
          }
          createMany: {
            args: Prisma.MateriaCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.MateriaDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MateriaPayload>
          }
          update: {
            args: Prisma.MateriaUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MateriaPayload>
          }
          deleteMany: {
            args: Prisma.MateriaDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.MateriaUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.MateriaUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MateriaPayload>
          }
          aggregate: {
            args: Prisma.MateriaAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateMateria>
          }
          groupBy: {
            args: Prisma.MateriaGroupByArgs<ExtArgs>
            result: $Utils.Optional<MateriaGroupByOutputType>[]
          }
          count: {
            args: Prisma.MateriaCountArgs<ExtArgs>
            result: $Utils.Optional<MateriaCountAggregateOutputType> | number
          }
        }
      }
      Calificacion: {
        payload: Prisma.$CalificacionPayload<ExtArgs>
        fields: Prisma.CalificacionFieldRefs
        operations: {
          findUnique: {
            args: Prisma.CalificacionFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CalificacionPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.CalificacionFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CalificacionPayload>
          }
          findFirst: {
            args: Prisma.CalificacionFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CalificacionPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.CalificacionFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CalificacionPayload>
          }
          findMany: {
            args: Prisma.CalificacionFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CalificacionPayload>[]
          }
          create: {
            args: Prisma.CalificacionCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CalificacionPayload>
          }
          createMany: {
            args: Prisma.CalificacionCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.CalificacionDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CalificacionPayload>
          }
          update: {
            args: Prisma.CalificacionUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CalificacionPayload>
          }
          deleteMany: {
            args: Prisma.CalificacionDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.CalificacionUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.CalificacionUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CalificacionPayload>
          }
          aggregate: {
            args: Prisma.CalificacionAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateCalificacion>
          }
          groupBy: {
            args: Prisma.CalificacionGroupByArgs<ExtArgs>
            result: $Utils.Optional<CalificacionGroupByOutputType>[]
          }
          count: {
            args: Prisma.CalificacionCountArgs<ExtArgs>
            result: $Utils.Optional<CalificacionCountAggregateOutputType> | number
          }
        }
      }
      Asistencia: {
        payload: Prisma.$AsistenciaPayload<ExtArgs>
        fields: Prisma.AsistenciaFieldRefs
        operations: {
          findUnique: {
            args: Prisma.AsistenciaFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AsistenciaPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.AsistenciaFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AsistenciaPayload>
          }
          findFirst: {
            args: Prisma.AsistenciaFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AsistenciaPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.AsistenciaFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AsistenciaPayload>
          }
          findMany: {
            args: Prisma.AsistenciaFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AsistenciaPayload>[]
          }
          create: {
            args: Prisma.AsistenciaCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AsistenciaPayload>
          }
          createMany: {
            args: Prisma.AsistenciaCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.AsistenciaDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AsistenciaPayload>
          }
          update: {
            args: Prisma.AsistenciaUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AsistenciaPayload>
          }
          deleteMany: {
            args: Prisma.AsistenciaDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.AsistenciaUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.AsistenciaUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AsistenciaPayload>
          }
          aggregate: {
            args: Prisma.AsistenciaAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateAsistencia>
          }
          groupBy: {
            args: Prisma.AsistenciaGroupByArgs<ExtArgs>
            result: $Utils.Optional<AsistenciaGroupByOutputType>[]
          }
          count: {
            args: Prisma.AsistenciaCountArgs<ExtArgs>
            result: $Utils.Optional<AsistenciaCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<"define", Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasources?: Datasources
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasourceUrl?: string
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Defaults to stdout
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events
     * log: [
     *   { emit: 'stdout', level: 'query' },
     *   { emit: 'stdout', level: 'info' },
     *   { emit: 'stdout', level: 'warn' }
     *   { emit: 'stdout', level: 'error' }
     * ]
     * ```
     * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/logging#the-log-option).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
    /**
     * Global configuration for omitting model fields by default.
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   omit: {
     *     user: {
     *       password: true
     *     }
     *   }
     * })
     * ```
     */
    omit?: Prisma.GlobalOmitConfig
  }
  export type GlobalOmitConfig = {
    usuario?: UsuarioOmit
    estudiante?: EstudianteOmit
    profesor?: ProfesorOmit
    padreFamilia?: PadreFamiliaOmit
    grupo?: GrupoOmit
    tramite?: TramiteOmit
    inscripcion?: InscripcionOmit
    pago?: PagoOmit
    recibo?: ReciboOmit
    materialEducativo?: MaterialEducativoOmit
    archivoSubido?: ArchivoSubidoOmit
    materia?: MateriaOmit
    calificacion?: CalificacionOmit
    asistencia?: AsistenciaOmit
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type GetLogType<T extends LogLevel | LogDefinition> = T extends LogDefinition ? T['emit'] extends 'event' ? T['level'] : never : never
  export type GetEvents<T extends any> = T extends Array<LogLevel | LogDefinition> ?
    GetLogType<T[0]> | GetLogType<T[1]> | GetLogType<T[2]> | GetLogType<T[3]>
    : never

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'updateManyAndReturn'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  /**
   * These options are being passed into the middleware as "params"
   */
  export type MiddlewareParams = {
    model?: ModelName
    action: PrismaAction
    args: any
    dataPath: string[]
    runInTransaction: boolean
  }

  /**
   * The `T` type makes sure, that the `return proceed` is not forgotten in the middleware implementation
   */
  export type Middleware<T = any> = (
    params: MiddlewareParams,
    next: (params: MiddlewareParams) => $Utils.JsPromise<T>,
  ) => $Utils.JsPromise<T>

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */


  /**
   * Count Type UsuarioCountOutputType
   */

  export type UsuarioCountOutputType = {
    PadreFamilia: number
  }

  export type UsuarioCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    PadreFamilia?: boolean | UsuarioCountOutputTypeCountPadreFamiliaArgs
  }

  // Custom InputTypes
  /**
   * UsuarioCountOutputType without action
   */
  export type UsuarioCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UsuarioCountOutputType
     */
    select?: UsuarioCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * UsuarioCountOutputType without action
   */
  export type UsuarioCountOutputTypeCountPadreFamiliaArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PadreFamiliaWhereInput
  }


  /**
   * Count Type EstudianteCountOutputType
   */

  export type EstudianteCountOutputType = {
    tramites: number
    Calificacion: number
    Asistencia: number
  }

  export type EstudianteCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    tramites?: boolean | EstudianteCountOutputTypeCountTramitesArgs
    Calificacion?: boolean | EstudianteCountOutputTypeCountCalificacionArgs
    Asistencia?: boolean | EstudianteCountOutputTypeCountAsistenciaArgs
  }

  // Custom InputTypes
  /**
   * EstudianteCountOutputType without action
   */
  export type EstudianteCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the EstudianteCountOutputType
     */
    select?: EstudianteCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * EstudianteCountOutputType without action
   */
  export type EstudianteCountOutputTypeCountTramitesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: TramiteWhereInput
  }

  /**
   * EstudianteCountOutputType without action
   */
  export type EstudianteCountOutputTypeCountCalificacionArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: CalificacionWhereInput
  }

  /**
   * EstudianteCountOutputType without action
   */
  export type EstudianteCountOutputTypeCountAsistenciaArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: AsistenciaWhereInput
  }


  /**
   * Count Type ProfesorCountOutputType
   */

  export type ProfesorCountOutputType = {
    materiales: number
    Materia: number
  }

  export type ProfesorCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    materiales?: boolean | ProfesorCountOutputTypeCountMaterialesArgs
    Materia?: boolean | ProfesorCountOutputTypeCountMateriaArgs
  }

  // Custom InputTypes
  /**
   * ProfesorCountOutputType without action
   */
  export type ProfesorCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ProfesorCountOutputType
     */
    select?: ProfesorCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * ProfesorCountOutputType without action
   */
  export type ProfesorCountOutputTypeCountMaterialesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: MaterialEducativoWhereInput
  }

  /**
   * ProfesorCountOutputType without action
   */
  export type ProfesorCountOutputTypeCountMateriaArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: MateriaWhereInput
  }


  /**
   * Count Type PadreFamiliaCountOutputType
   */

  export type PadreFamiliaCountOutputType = {
    estudiantes: number
  }

  export type PadreFamiliaCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    estudiantes?: boolean | PadreFamiliaCountOutputTypeCountEstudiantesArgs
  }

  // Custom InputTypes
  /**
   * PadreFamiliaCountOutputType without action
   */
  export type PadreFamiliaCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PadreFamiliaCountOutputType
     */
    select?: PadreFamiliaCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * PadreFamiliaCountOutputType without action
   */
  export type PadreFamiliaCountOutputTypeCountEstudiantesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: EstudianteWhereInput
  }


  /**
   * Count Type GrupoCountOutputType
   */

  export type GrupoCountOutputType = {
    estudiantes: number
    inscripciones: number
    materiales: number
  }

  export type GrupoCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    estudiantes?: boolean | GrupoCountOutputTypeCountEstudiantesArgs
    inscripciones?: boolean | GrupoCountOutputTypeCountInscripcionesArgs
    materiales?: boolean | GrupoCountOutputTypeCountMaterialesArgs
  }

  // Custom InputTypes
  /**
   * GrupoCountOutputType without action
   */
  export type GrupoCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the GrupoCountOutputType
     */
    select?: GrupoCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * GrupoCountOutputType without action
   */
  export type GrupoCountOutputTypeCountEstudiantesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: EstudianteWhereInput
  }

  /**
   * GrupoCountOutputType without action
   */
  export type GrupoCountOutputTypeCountInscripcionesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: InscripcionWhereInput
  }

  /**
   * GrupoCountOutputType without action
   */
  export type GrupoCountOutputTypeCountMaterialesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: MaterialEducativoWhereInput
  }


  /**
   * Count Type PagoCountOutputType
   */

  export type PagoCountOutputType = {
    recibos: number
  }

  export type PagoCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    recibos?: boolean | PagoCountOutputTypeCountRecibosArgs
  }

  // Custom InputTypes
  /**
   * PagoCountOutputType without action
   */
  export type PagoCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PagoCountOutputType
     */
    select?: PagoCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * PagoCountOutputType without action
   */
  export type PagoCountOutputTypeCountRecibosArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ReciboWhereInput
  }


  /**
   * Count Type MaterialEducativoCountOutputType
   */

  export type MaterialEducativoCountOutputType = {
    archivo: number
  }

  export type MaterialEducativoCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    archivo?: boolean | MaterialEducativoCountOutputTypeCountArchivoArgs
  }

  // Custom InputTypes
  /**
   * MaterialEducativoCountOutputType without action
   */
  export type MaterialEducativoCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MaterialEducativoCountOutputType
     */
    select?: MaterialEducativoCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * MaterialEducativoCountOutputType without action
   */
  export type MaterialEducativoCountOutputTypeCountArchivoArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ArchivoSubidoWhereInput
  }


  /**
   * Count Type MateriaCountOutputType
   */

  export type MateriaCountOutputType = {
    Calificacion: number
    Asistencia: number
  }

  export type MateriaCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    Calificacion?: boolean | MateriaCountOutputTypeCountCalificacionArgs
    Asistencia?: boolean | MateriaCountOutputTypeCountAsistenciaArgs
  }

  // Custom InputTypes
  /**
   * MateriaCountOutputType without action
   */
  export type MateriaCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MateriaCountOutputType
     */
    select?: MateriaCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * MateriaCountOutputType without action
   */
  export type MateriaCountOutputTypeCountCalificacionArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: CalificacionWhereInput
  }

  /**
   * MateriaCountOutputType without action
   */
  export type MateriaCountOutputTypeCountAsistenciaArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: AsistenciaWhereInput
  }


  /**
   * Models
   */

  /**
   * Model Usuario
   */

  export type AggregateUsuario = {
    _count: UsuarioCountAggregateOutputType | null
    _avg: UsuarioAvgAggregateOutputType | null
    _sum: UsuarioSumAggregateOutputType | null
    _min: UsuarioMinAggregateOutputType | null
    _max: UsuarioMaxAggregateOutputType | null
  }

  export type UsuarioAvgAggregateOutputType = {
    id: number | null
  }

  export type UsuarioSumAggregateOutputType = {
    id: number | null
  }

  export type UsuarioMinAggregateOutputType = {
    id: number | null
    nombre: string | null
    correo: string | null
    telefono: string | null
    contrasena: string | null
    puesto: $Enums.RolUsuario | null
    fechaCreacion: Date | null
  }

  export type UsuarioMaxAggregateOutputType = {
    id: number | null
    nombre: string | null
    correo: string | null
    telefono: string | null
    contrasena: string | null
    puesto: $Enums.RolUsuario | null
    fechaCreacion: Date | null
  }

  export type UsuarioCountAggregateOutputType = {
    id: number
    nombre: number
    correo: number
    telefono: number
    contrasena: number
    puesto: number
    fechaCreacion: number
    _all: number
  }


  export type UsuarioAvgAggregateInputType = {
    id?: true
  }

  export type UsuarioSumAggregateInputType = {
    id?: true
  }

  export type UsuarioMinAggregateInputType = {
    id?: true
    nombre?: true
    correo?: true
    telefono?: true
    contrasena?: true
    puesto?: true
    fechaCreacion?: true
  }

  export type UsuarioMaxAggregateInputType = {
    id?: true
    nombre?: true
    correo?: true
    telefono?: true
    contrasena?: true
    puesto?: true
    fechaCreacion?: true
  }

  export type UsuarioCountAggregateInputType = {
    id?: true
    nombre?: true
    correo?: true
    telefono?: true
    contrasena?: true
    puesto?: true
    fechaCreacion?: true
    _all?: true
  }

  export type UsuarioAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Usuario to aggregate.
     */
    where?: UsuarioWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Usuarios to fetch.
     */
    orderBy?: UsuarioOrderByWithRelationInput | UsuarioOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: UsuarioWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Usuarios from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Usuarios.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Usuarios
    **/
    _count?: true | UsuarioCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: UsuarioAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: UsuarioSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: UsuarioMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: UsuarioMaxAggregateInputType
  }

  export type GetUsuarioAggregateType<T extends UsuarioAggregateArgs> = {
        [P in keyof T & keyof AggregateUsuario]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUsuario[P]>
      : GetScalarType<T[P], AggregateUsuario[P]>
  }




  export type UsuarioGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: UsuarioWhereInput
    orderBy?: UsuarioOrderByWithAggregationInput | UsuarioOrderByWithAggregationInput[]
    by: UsuarioScalarFieldEnum[] | UsuarioScalarFieldEnum
    having?: UsuarioScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: UsuarioCountAggregateInputType | true
    _avg?: UsuarioAvgAggregateInputType
    _sum?: UsuarioSumAggregateInputType
    _min?: UsuarioMinAggregateInputType
    _max?: UsuarioMaxAggregateInputType
  }

  export type UsuarioGroupByOutputType = {
    id: number
    nombre: string
    correo: string
    telefono: string
    contrasena: string
    puesto: $Enums.RolUsuario
    fechaCreacion: Date
    _count: UsuarioCountAggregateOutputType | null
    _avg: UsuarioAvgAggregateOutputType | null
    _sum: UsuarioSumAggregateOutputType | null
    _min: UsuarioMinAggregateOutputType | null
    _max: UsuarioMaxAggregateOutputType | null
  }

  type GetUsuarioGroupByPayload<T extends UsuarioGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<UsuarioGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof UsuarioGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], UsuarioGroupByOutputType[P]>
            : GetScalarType<T[P], UsuarioGroupByOutputType[P]>
        }
      >
    >


  export type UsuarioSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    nombre?: boolean
    correo?: boolean
    telefono?: boolean
    contrasena?: boolean
    puesto?: boolean
    fechaCreacion?: boolean
    Estudiante?: boolean | Usuario$EstudianteArgs<ExtArgs>
    Profesor?: boolean | Usuario$ProfesorArgs<ExtArgs>
    PadreFamilia?: boolean | Usuario$PadreFamiliaArgs<ExtArgs>
    _count?: boolean | UsuarioCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["usuario"]>



  export type UsuarioSelectScalar = {
    id?: boolean
    nombre?: boolean
    correo?: boolean
    telefono?: boolean
    contrasena?: boolean
    puesto?: boolean
    fechaCreacion?: boolean
  }

  export type UsuarioOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "nombre" | "correo" | "telefono" | "contrasena" | "puesto" | "fechaCreacion", ExtArgs["result"]["usuario"]>
  export type UsuarioInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    Estudiante?: boolean | Usuario$EstudianteArgs<ExtArgs>
    Profesor?: boolean | Usuario$ProfesorArgs<ExtArgs>
    PadreFamilia?: boolean | Usuario$PadreFamiliaArgs<ExtArgs>
    _count?: boolean | UsuarioCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $UsuarioPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Usuario"
    objects: {
      Estudiante: Prisma.$EstudiantePayload<ExtArgs> | null
      Profesor: Prisma.$ProfesorPayload<ExtArgs> | null
      PadreFamilia: Prisma.$PadreFamiliaPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      nombre: string
      correo: string
      telefono: string
      contrasena: string
      puesto: $Enums.RolUsuario
      fechaCreacion: Date
    }, ExtArgs["result"]["usuario"]>
    composites: {}
  }

  type UsuarioGetPayload<S extends boolean | null | undefined | UsuarioDefaultArgs> = $Result.GetResult<Prisma.$UsuarioPayload, S>

  type UsuarioCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<UsuarioFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: UsuarioCountAggregateInputType | true
    }

  export interface UsuarioDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Usuario'], meta: { name: 'Usuario' } }
    /**
     * Find zero or one Usuario that matches the filter.
     * @param {UsuarioFindUniqueArgs} args - Arguments to find a Usuario
     * @example
     * // Get one Usuario
     * const usuario = await prisma.usuario.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends UsuarioFindUniqueArgs>(args: SelectSubset<T, UsuarioFindUniqueArgs<ExtArgs>>): Prisma__UsuarioClient<$Result.GetResult<Prisma.$UsuarioPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Usuario that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {UsuarioFindUniqueOrThrowArgs} args - Arguments to find a Usuario
     * @example
     * // Get one Usuario
     * const usuario = await prisma.usuario.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends UsuarioFindUniqueOrThrowArgs>(args: SelectSubset<T, UsuarioFindUniqueOrThrowArgs<ExtArgs>>): Prisma__UsuarioClient<$Result.GetResult<Prisma.$UsuarioPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Usuario that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UsuarioFindFirstArgs} args - Arguments to find a Usuario
     * @example
     * // Get one Usuario
     * const usuario = await prisma.usuario.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends UsuarioFindFirstArgs>(args?: SelectSubset<T, UsuarioFindFirstArgs<ExtArgs>>): Prisma__UsuarioClient<$Result.GetResult<Prisma.$UsuarioPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Usuario that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UsuarioFindFirstOrThrowArgs} args - Arguments to find a Usuario
     * @example
     * // Get one Usuario
     * const usuario = await prisma.usuario.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends UsuarioFindFirstOrThrowArgs>(args?: SelectSubset<T, UsuarioFindFirstOrThrowArgs<ExtArgs>>): Prisma__UsuarioClient<$Result.GetResult<Prisma.$UsuarioPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Usuarios that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UsuarioFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Usuarios
     * const usuarios = await prisma.usuario.findMany()
     * 
     * // Get first 10 Usuarios
     * const usuarios = await prisma.usuario.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const usuarioWithIdOnly = await prisma.usuario.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends UsuarioFindManyArgs>(args?: SelectSubset<T, UsuarioFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UsuarioPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Usuario.
     * @param {UsuarioCreateArgs} args - Arguments to create a Usuario.
     * @example
     * // Create one Usuario
     * const Usuario = await prisma.usuario.create({
     *   data: {
     *     // ... data to create a Usuario
     *   }
     * })
     * 
     */
    create<T extends UsuarioCreateArgs>(args: SelectSubset<T, UsuarioCreateArgs<ExtArgs>>): Prisma__UsuarioClient<$Result.GetResult<Prisma.$UsuarioPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Usuarios.
     * @param {UsuarioCreateManyArgs} args - Arguments to create many Usuarios.
     * @example
     * // Create many Usuarios
     * const usuario = await prisma.usuario.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends UsuarioCreateManyArgs>(args?: SelectSubset<T, UsuarioCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Usuario.
     * @param {UsuarioDeleteArgs} args - Arguments to delete one Usuario.
     * @example
     * // Delete one Usuario
     * const Usuario = await prisma.usuario.delete({
     *   where: {
     *     // ... filter to delete one Usuario
     *   }
     * })
     * 
     */
    delete<T extends UsuarioDeleteArgs>(args: SelectSubset<T, UsuarioDeleteArgs<ExtArgs>>): Prisma__UsuarioClient<$Result.GetResult<Prisma.$UsuarioPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Usuario.
     * @param {UsuarioUpdateArgs} args - Arguments to update one Usuario.
     * @example
     * // Update one Usuario
     * const usuario = await prisma.usuario.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends UsuarioUpdateArgs>(args: SelectSubset<T, UsuarioUpdateArgs<ExtArgs>>): Prisma__UsuarioClient<$Result.GetResult<Prisma.$UsuarioPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Usuarios.
     * @param {UsuarioDeleteManyArgs} args - Arguments to filter Usuarios to delete.
     * @example
     * // Delete a few Usuarios
     * const { count } = await prisma.usuario.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends UsuarioDeleteManyArgs>(args?: SelectSubset<T, UsuarioDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Usuarios.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UsuarioUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Usuarios
     * const usuario = await prisma.usuario.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends UsuarioUpdateManyArgs>(args: SelectSubset<T, UsuarioUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Usuario.
     * @param {UsuarioUpsertArgs} args - Arguments to update or create a Usuario.
     * @example
     * // Update or create a Usuario
     * const usuario = await prisma.usuario.upsert({
     *   create: {
     *     // ... data to create a Usuario
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Usuario we want to update
     *   }
     * })
     */
    upsert<T extends UsuarioUpsertArgs>(args: SelectSubset<T, UsuarioUpsertArgs<ExtArgs>>): Prisma__UsuarioClient<$Result.GetResult<Prisma.$UsuarioPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Usuarios.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UsuarioCountArgs} args - Arguments to filter Usuarios to count.
     * @example
     * // Count the number of Usuarios
     * const count = await prisma.usuario.count({
     *   where: {
     *     // ... the filter for the Usuarios we want to count
     *   }
     * })
    **/
    count<T extends UsuarioCountArgs>(
      args?: Subset<T, UsuarioCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], UsuarioCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Usuario.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UsuarioAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends UsuarioAggregateArgs>(args: Subset<T, UsuarioAggregateArgs>): Prisma.PrismaPromise<GetUsuarioAggregateType<T>>

    /**
     * Group by Usuario.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UsuarioGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends UsuarioGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: UsuarioGroupByArgs['orderBy'] }
        : { orderBy?: UsuarioGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, UsuarioGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUsuarioGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Usuario model
   */
  readonly fields: UsuarioFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Usuario.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__UsuarioClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    Estudiante<T extends Usuario$EstudianteArgs<ExtArgs> = {}>(args?: Subset<T, Usuario$EstudianteArgs<ExtArgs>>): Prisma__EstudianteClient<$Result.GetResult<Prisma.$EstudiantePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    Profesor<T extends Usuario$ProfesorArgs<ExtArgs> = {}>(args?: Subset<T, Usuario$ProfesorArgs<ExtArgs>>): Prisma__ProfesorClient<$Result.GetResult<Prisma.$ProfesorPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    PadreFamilia<T extends Usuario$PadreFamiliaArgs<ExtArgs> = {}>(args?: Subset<T, Usuario$PadreFamiliaArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PadreFamiliaPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Usuario model
   */
  interface UsuarioFieldRefs {
    readonly id: FieldRef<"Usuario", 'Int'>
    readonly nombre: FieldRef<"Usuario", 'String'>
    readonly correo: FieldRef<"Usuario", 'String'>
    readonly telefono: FieldRef<"Usuario", 'String'>
    readonly contrasena: FieldRef<"Usuario", 'String'>
    readonly puesto: FieldRef<"Usuario", 'RolUsuario'>
    readonly fechaCreacion: FieldRef<"Usuario", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Usuario findUnique
   */
  export type UsuarioFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Usuario
     */
    select?: UsuarioSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Usuario
     */
    omit?: UsuarioOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UsuarioInclude<ExtArgs> | null
    /**
     * Filter, which Usuario to fetch.
     */
    where: UsuarioWhereUniqueInput
  }

  /**
   * Usuario findUniqueOrThrow
   */
  export type UsuarioFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Usuario
     */
    select?: UsuarioSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Usuario
     */
    omit?: UsuarioOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UsuarioInclude<ExtArgs> | null
    /**
     * Filter, which Usuario to fetch.
     */
    where: UsuarioWhereUniqueInput
  }

  /**
   * Usuario findFirst
   */
  export type UsuarioFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Usuario
     */
    select?: UsuarioSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Usuario
     */
    omit?: UsuarioOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UsuarioInclude<ExtArgs> | null
    /**
     * Filter, which Usuario to fetch.
     */
    where?: UsuarioWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Usuarios to fetch.
     */
    orderBy?: UsuarioOrderByWithRelationInput | UsuarioOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Usuarios.
     */
    cursor?: UsuarioWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Usuarios from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Usuarios.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Usuarios.
     */
    distinct?: UsuarioScalarFieldEnum | UsuarioScalarFieldEnum[]
  }

  /**
   * Usuario findFirstOrThrow
   */
  export type UsuarioFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Usuario
     */
    select?: UsuarioSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Usuario
     */
    omit?: UsuarioOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UsuarioInclude<ExtArgs> | null
    /**
     * Filter, which Usuario to fetch.
     */
    where?: UsuarioWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Usuarios to fetch.
     */
    orderBy?: UsuarioOrderByWithRelationInput | UsuarioOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Usuarios.
     */
    cursor?: UsuarioWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Usuarios from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Usuarios.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Usuarios.
     */
    distinct?: UsuarioScalarFieldEnum | UsuarioScalarFieldEnum[]
  }

  /**
   * Usuario findMany
   */
  export type UsuarioFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Usuario
     */
    select?: UsuarioSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Usuario
     */
    omit?: UsuarioOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UsuarioInclude<ExtArgs> | null
    /**
     * Filter, which Usuarios to fetch.
     */
    where?: UsuarioWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Usuarios to fetch.
     */
    orderBy?: UsuarioOrderByWithRelationInput | UsuarioOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Usuarios.
     */
    cursor?: UsuarioWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Usuarios from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Usuarios.
     */
    skip?: number
    distinct?: UsuarioScalarFieldEnum | UsuarioScalarFieldEnum[]
  }

  /**
   * Usuario create
   */
  export type UsuarioCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Usuario
     */
    select?: UsuarioSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Usuario
     */
    omit?: UsuarioOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UsuarioInclude<ExtArgs> | null
    /**
     * The data needed to create a Usuario.
     */
    data: XOR<UsuarioCreateInput, UsuarioUncheckedCreateInput>
  }

  /**
   * Usuario createMany
   */
  export type UsuarioCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Usuarios.
     */
    data: UsuarioCreateManyInput | UsuarioCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Usuario update
   */
  export type UsuarioUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Usuario
     */
    select?: UsuarioSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Usuario
     */
    omit?: UsuarioOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UsuarioInclude<ExtArgs> | null
    /**
     * The data needed to update a Usuario.
     */
    data: XOR<UsuarioUpdateInput, UsuarioUncheckedUpdateInput>
    /**
     * Choose, which Usuario to update.
     */
    where: UsuarioWhereUniqueInput
  }

  /**
   * Usuario updateMany
   */
  export type UsuarioUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Usuarios.
     */
    data: XOR<UsuarioUpdateManyMutationInput, UsuarioUncheckedUpdateManyInput>
    /**
     * Filter which Usuarios to update
     */
    where?: UsuarioWhereInput
    /**
     * Limit how many Usuarios to update.
     */
    limit?: number
  }

  /**
   * Usuario upsert
   */
  export type UsuarioUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Usuario
     */
    select?: UsuarioSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Usuario
     */
    omit?: UsuarioOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UsuarioInclude<ExtArgs> | null
    /**
     * The filter to search for the Usuario to update in case it exists.
     */
    where: UsuarioWhereUniqueInput
    /**
     * In case the Usuario found by the `where` argument doesn't exist, create a new Usuario with this data.
     */
    create: XOR<UsuarioCreateInput, UsuarioUncheckedCreateInput>
    /**
     * In case the Usuario was found with the provided `where` argument, update it with this data.
     */
    update: XOR<UsuarioUpdateInput, UsuarioUncheckedUpdateInput>
  }

  /**
   * Usuario delete
   */
  export type UsuarioDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Usuario
     */
    select?: UsuarioSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Usuario
     */
    omit?: UsuarioOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UsuarioInclude<ExtArgs> | null
    /**
     * Filter which Usuario to delete.
     */
    where: UsuarioWhereUniqueInput
  }

  /**
   * Usuario deleteMany
   */
  export type UsuarioDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Usuarios to delete
     */
    where?: UsuarioWhereInput
    /**
     * Limit how many Usuarios to delete.
     */
    limit?: number
  }

  /**
   * Usuario.Estudiante
   */
  export type Usuario$EstudianteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Estudiante
     */
    select?: EstudianteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Estudiante
     */
    omit?: EstudianteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EstudianteInclude<ExtArgs> | null
    where?: EstudianteWhereInput
  }

  /**
   * Usuario.Profesor
   */
  export type Usuario$ProfesorArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Profesor
     */
    select?: ProfesorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Profesor
     */
    omit?: ProfesorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProfesorInclude<ExtArgs> | null
    where?: ProfesorWhereInput
  }

  /**
   * Usuario.PadreFamilia
   */
  export type Usuario$PadreFamiliaArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PadreFamilia
     */
    select?: PadreFamiliaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PadreFamilia
     */
    omit?: PadreFamiliaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PadreFamiliaInclude<ExtArgs> | null
    where?: PadreFamiliaWhereInput
    orderBy?: PadreFamiliaOrderByWithRelationInput | PadreFamiliaOrderByWithRelationInput[]
    cursor?: PadreFamiliaWhereUniqueInput
    take?: number
    skip?: number
    distinct?: PadreFamiliaScalarFieldEnum | PadreFamiliaScalarFieldEnum[]
  }

  /**
   * Usuario without action
   */
  export type UsuarioDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Usuario
     */
    select?: UsuarioSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Usuario
     */
    omit?: UsuarioOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UsuarioInclude<ExtArgs> | null
  }


  /**
   * Model Estudiante
   */

  export type AggregateEstudiante = {
    _count: EstudianteCountAggregateOutputType | null
    _avg: EstudianteAvgAggregateOutputType | null
    _sum: EstudianteSumAggregateOutputType | null
    _min: EstudianteMinAggregateOutputType | null
    _max: EstudianteMaxAggregateOutputType | null
  }

  export type EstudianteAvgAggregateOutputType = {
    usuarioId: number | null
    grupoId: number | null
    padreFamiliaId: number | null
  }

  export type EstudianteSumAggregateOutputType = {
    usuarioId: number | null
    grupoId: number | null
    padreFamiliaId: number | null
  }

  export type EstudianteMinAggregateOutputType = {
    usuarioId: number | null
    grupoId: number | null
    padreFamiliaId: number | null
    estado: $Enums.EstadoEstudiante | null
  }

  export type EstudianteMaxAggregateOutputType = {
    usuarioId: number | null
    grupoId: number | null
    padreFamiliaId: number | null
    estado: $Enums.EstadoEstudiante | null
  }

  export type EstudianteCountAggregateOutputType = {
    usuarioId: number
    grupoId: number
    padreFamiliaId: number
    estado: number
    _all: number
  }


  export type EstudianteAvgAggregateInputType = {
    usuarioId?: true
    grupoId?: true
    padreFamiliaId?: true
  }

  export type EstudianteSumAggregateInputType = {
    usuarioId?: true
    grupoId?: true
    padreFamiliaId?: true
  }

  export type EstudianteMinAggregateInputType = {
    usuarioId?: true
    grupoId?: true
    padreFamiliaId?: true
    estado?: true
  }

  export type EstudianteMaxAggregateInputType = {
    usuarioId?: true
    grupoId?: true
    padreFamiliaId?: true
    estado?: true
  }

  export type EstudianteCountAggregateInputType = {
    usuarioId?: true
    grupoId?: true
    padreFamiliaId?: true
    estado?: true
    _all?: true
  }

  export type EstudianteAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Estudiante to aggregate.
     */
    where?: EstudianteWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Estudiantes to fetch.
     */
    orderBy?: EstudianteOrderByWithRelationInput | EstudianteOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: EstudianteWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Estudiantes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Estudiantes.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Estudiantes
    **/
    _count?: true | EstudianteCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: EstudianteAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: EstudianteSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: EstudianteMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: EstudianteMaxAggregateInputType
  }

  export type GetEstudianteAggregateType<T extends EstudianteAggregateArgs> = {
        [P in keyof T & keyof AggregateEstudiante]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateEstudiante[P]>
      : GetScalarType<T[P], AggregateEstudiante[P]>
  }




  export type EstudianteGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: EstudianteWhereInput
    orderBy?: EstudianteOrderByWithAggregationInput | EstudianteOrderByWithAggregationInput[]
    by: EstudianteScalarFieldEnum[] | EstudianteScalarFieldEnum
    having?: EstudianteScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: EstudianteCountAggregateInputType | true
    _avg?: EstudianteAvgAggregateInputType
    _sum?: EstudianteSumAggregateInputType
    _min?: EstudianteMinAggregateInputType
    _max?: EstudianteMaxAggregateInputType
  }

  export type EstudianteGroupByOutputType = {
    usuarioId: number
    grupoId: number | null
    padreFamiliaId: number | null
    estado: $Enums.EstadoEstudiante
    _count: EstudianteCountAggregateOutputType | null
    _avg: EstudianteAvgAggregateOutputType | null
    _sum: EstudianteSumAggregateOutputType | null
    _min: EstudianteMinAggregateOutputType | null
    _max: EstudianteMaxAggregateOutputType | null
  }

  type GetEstudianteGroupByPayload<T extends EstudianteGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<EstudianteGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof EstudianteGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], EstudianteGroupByOutputType[P]>
            : GetScalarType<T[P], EstudianteGroupByOutputType[P]>
        }
      >
    >


  export type EstudianteSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    usuarioId?: boolean
    grupoId?: boolean
    padreFamiliaId?: boolean
    estado?: boolean
    tramites?: boolean | Estudiante$tramitesArgs<ExtArgs>
    grupo?: boolean | Estudiante$grupoArgs<ExtArgs>
    usuario?: boolean | UsuarioDefaultArgs<ExtArgs>
    PadreFamilia?: boolean | Estudiante$PadreFamiliaArgs<ExtArgs>
    Calificacion?: boolean | Estudiante$CalificacionArgs<ExtArgs>
    Asistencia?: boolean | Estudiante$AsistenciaArgs<ExtArgs>
    _count?: boolean | EstudianteCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["estudiante"]>



  export type EstudianteSelectScalar = {
    usuarioId?: boolean
    grupoId?: boolean
    padreFamiliaId?: boolean
    estado?: boolean
  }

  export type EstudianteOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"usuarioId" | "grupoId" | "padreFamiliaId" | "estado", ExtArgs["result"]["estudiante"]>
  export type EstudianteInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    tramites?: boolean | Estudiante$tramitesArgs<ExtArgs>
    grupo?: boolean | Estudiante$grupoArgs<ExtArgs>
    usuario?: boolean | UsuarioDefaultArgs<ExtArgs>
    PadreFamilia?: boolean | Estudiante$PadreFamiliaArgs<ExtArgs>
    Calificacion?: boolean | Estudiante$CalificacionArgs<ExtArgs>
    Asistencia?: boolean | Estudiante$AsistenciaArgs<ExtArgs>
    _count?: boolean | EstudianteCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $EstudiantePayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Estudiante"
    objects: {
      tramites: Prisma.$TramitePayload<ExtArgs>[]
      grupo: Prisma.$GrupoPayload<ExtArgs> | null
      usuario: Prisma.$UsuarioPayload<ExtArgs>
      PadreFamilia: Prisma.$PadreFamiliaPayload<ExtArgs> | null
      Calificacion: Prisma.$CalificacionPayload<ExtArgs>[]
      Asistencia: Prisma.$AsistenciaPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      usuarioId: number
      grupoId: number | null
      padreFamiliaId: number | null
      estado: $Enums.EstadoEstudiante
    }, ExtArgs["result"]["estudiante"]>
    composites: {}
  }

  type EstudianteGetPayload<S extends boolean | null | undefined | EstudianteDefaultArgs> = $Result.GetResult<Prisma.$EstudiantePayload, S>

  type EstudianteCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<EstudianteFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: EstudianteCountAggregateInputType | true
    }

  export interface EstudianteDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Estudiante'], meta: { name: 'Estudiante' } }
    /**
     * Find zero or one Estudiante that matches the filter.
     * @param {EstudianteFindUniqueArgs} args - Arguments to find a Estudiante
     * @example
     * // Get one Estudiante
     * const estudiante = await prisma.estudiante.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends EstudianteFindUniqueArgs>(args: SelectSubset<T, EstudianteFindUniqueArgs<ExtArgs>>): Prisma__EstudianteClient<$Result.GetResult<Prisma.$EstudiantePayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Estudiante that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {EstudianteFindUniqueOrThrowArgs} args - Arguments to find a Estudiante
     * @example
     * // Get one Estudiante
     * const estudiante = await prisma.estudiante.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends EstudianteFindUniqueOrThrowArgs>(args: SelectSubset<T, EstudianteFindUniqueOrThrowArgs<ExtArgs>>): Prisma__EstudianteClient<$Result.GetResult<Prisma.$EstudiantePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Estudiante that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EstudianteFindFirstArgs} args - Arguments to find a Estudiante
     * @example
     * // Get one Estudiante
     * const estudiante = await prisma.estudiante.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends EstudianteFindFirstArgs>(args?: SelectSubset<T, EstudianteFindFirstArgs<ExtArgs>>): Prisma__EstudianteClient<$Result.GetResult<Prisma.$EstudiantePayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Estudiante that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EstudianteFindFirstOrThrowArgs} args - Arguments to find a Estudiante
     * @example
     * // Get one Estudiante
     * const estudiante = await prisma.estudiante.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends EstudianteFindFirstOrThrowArgs>(args?: SelectSubset<T, EstudianteFindFirstOrThrowArgs<ExtArgs>>): Prisma__EstudianteClient<$Result.GetResult<Prisma.$EstudiantePayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Estudiantes that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EstudianteFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Estudiantes
     * const estudiantes = await prisma.estudiante.findMany()
     * 
     * // Get first 10 Estudiantes
     * const estudiantes = await prisma.estudiante.findMany({ take: 10 })
     * 
     * // Only select the `usuarioId`
     * const estudianteWithUsuarioIdOnly = await prisma.estudiante.findMany({ select: { usuarioId: true } })
     * 
     */
    findMany<T extends EstudianteFindManyArgs>(args?: SelectSubset<T, EstudianteFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$EstudiantePayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Estudiante.
     * @param {EstudianteCreateArgs} args - Arguments to create a Estudiante.
     * @example
     * // Create one Estudiante
     * const Estudiante = await prisma.estudiante.create({
     *   data: {
     *     // ... data to create a Estudiante
     *   }
     * })
     * 
     */
    create<T extends EstudianteCreateArgs>(args: SelectSubset<T, EstudianteCreateArgs<ExtArgs>>): Prisma__EstudianteClient<$Result.GetResult<Prisma.$EstudiantePayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Estudiantes.
     * @param {EstudianteCreateManyArgs} args - Arguments to create many Estudiantes.
     * @example
     * // Create many Estudiantes
     * const estudiante = await prisma.estudiante.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends EstudianteCreateManyArgs>(args?: SelectSubset<T, EstudianteCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Estudiante.
     * @param {EstudianteDeleteArgs} args - Arguments to delete one Estudiante.
     * @example
     * // Delete one Estudiante
     * const Estudiante = await prisma.estudiante.delete({
     *   where: {
     *     // ... filter to delete one Estudiante
     *   }
     * })
     * 
     */
    delete<T extends EstudianteDeleteArgs>(args: SelectSubset<T, EstudianteDeleteArgs<ExtArgs>>): Prisma__EstudianteClient<$Result.GetResult<Prisma.$EstudiantePayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Estudiante.
     * @param {EstudianteUpdateArgs} args - Arguments to update one Estudiante.
     * @example
     * // Update one Estudiante
     * const estudiante = await prisma.estudiante.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends EstudianteUpdateArgs>(args: SelectSubset<T, EstudianteUpdateArgs<ExtArgs>>): Prisma__EstudianteClient<$Result.GetResult<Prisma.$EstudiantePayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Estudiantes.
     * @param {EstudianteDeleteManyArgs} args - Arguments to filter Estudiantes to delete.
     * @example
     * // Delete a few Estudiantes
     * const { count } = await prisma.estudiante.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends EstudianteDeleteManyArgs>(args?: SelectSubset<T, EstudianteDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Estudiantes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EstudianteUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Estudiantes
     * const estudiante = await prisma.estudiante.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends EstudianteUpdateManyArgs>(args: SelectSubset<T, EstudianteUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Estudiante.
     * @param {EstudianteUpsertArgs} args - Arguments to update or create a Estudiante.
     * @example
     * // Update or create a Estudiante
     * const estudiante = await prisma.estudiante.upsert({
     *   create: {
     *     // ... data to create a Estudiante
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Estudiante we want to update
     *   }
     * })
     */
    upsert<T extends EstudianteUpsertArgs>(args: SelectSubset<T, EstudianteUpsertArgs<ExtArgs>>): Prisma__EstudianteClient<$Result.GetResult<Prisma.$EstudiantePayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Estudiantes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EstudianteCountArgs} args - Arguments to filter Estudiantes to count.
     * @example
     * // Count the number of Estudiantes
     * const count = await prisma.estudiante.count({
     *   where: {
     *     // ... the filter for the Estudiantes we want to count
     *   }
     * })
    **/
    count<T extends EstudianteCountArgs>(
      args?: Subset<T, EstudianteCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], EstudianteCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Estudiante.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EstudianteAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends EstudianteAggregateArgs>(args: Subset<T, EstudianteAggregateArgs>): Prisma.PrismaPromise<GetEstudianteAggregateType<T>>

    /**
     * Group by Estudiante.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EstudianteGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends EstudianteGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: EstudianteGroupByArgs['orderBy'] }
        : { orderBy?: EstudianteGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, EstudianteGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetEstudianteGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Estudiante model
   */
  readonly fields: EstudianteFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Estudiante.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__EstudianteClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    tramites<T extends Estudiante$tramitesArgs<ExtArgs> = {}>(args?: Subset<T, Estudiante$tramitesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TramitePayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    grupo<T extends Estudiante$grupoArgs<ExtArgs> = {}>(args?: Subset<T, Estudiante$grupoArgs<ExtArgs>>): Prisma__GrupoClient<$Result.GetResult<Prisma.$GrupoPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    usuario<T extends UsuarioDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UsuarioDefaultArgs<ExtArgs>>): Prisma__UsuarioClient<$Result.GetResult<Prisma.$UsuarioPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    PadreFamilia<T extends Estudiante$PadreFamiliaArgs<ExtArgs> = {}>(args?: Subset<T, Estudiante$PadreFamiliaArgs<ExtArgs>>): Prisma__PadreFamiliaClient<$Result.GetResult<Prisma.$PadreFamiliaPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    Calificacion<T extends Estudiante$CalificacionArgs<ExtArgs> = {}>(args?: Subset<T, Estudiante$CalificacionArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CalificacionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    Asistencia<T extends Estudiante$AsistenciaArgs<ExtArgs> = {}>(args?: Subset<T, Estudiante$AsistenciaArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AsistenciaPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Estudiante model
   */
  interface EstudianteFieldRefs {
    readonly usuarioId: FieldRef<"Estudiante", 'Int'>
    readonly grupoId: FieldRef<"Estudiante", 'Int'>
    readonly padreFamiliaId: FieldRef<"Estudiante", 'Int'>
    readonly estado: FieldRef<"Estudiante", 'EstadoEstudiante'>
  }
    

  // Custom InputTypes
  /**
   * Estudiante findUnique
   */
  export type EstudianteFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Estudiante
     */
    select?: EstudianteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Estudiante
     */
    omit?: EstudianteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EstudianteInclude<ExtArgs> | null
    /**
     * Filter, which Estudiante to fetch.
     */
    where: EstudianteWhereUniqueInput
  }

  /**
   * Estudiante findUniqueOrThrow
   */
  export type EstudianteFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Estudiante
     */
    select?: EstudianteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Estudiante
     */
    omit?: EstudianteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EstudianteInclude<ExtArgs> | null
    /**
     * Filter, which Estudiante to fetch.
     */
    where: EstudianteWhereUniqueInput
  }

  /**
   * Estudiante findFirst
   */
  export type EstudianteFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Estudiante
     */
    select?: EstudianteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Estudiante
     */
    omit?: EstudianteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EstudianteInclude<ExtArgs> | null
    /**
     * Filter, which Estudiante to fetch.
     */
    where?: EstudianteWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Estudiantes to fetch.
     */
    orderBy?: EstudianteOrderByWithRelationInput | EstudianteOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Estudiantes.
     */
    cursor?: EstudianteWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Estudiantes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Estudiantes.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Estudiantes.
     */
    distinct?: EstudianteScalarFieldEnum | EstudianteScalarFieldEnum[]
  }

  /**
   * Estudiante findFirstOrThrow
   */
  export type EstudianteFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Estudiante
     */
    select?: EstudianteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Estudiante
     */
    omit?: EstudianteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EstudianteInclude<ExtArgs> | null
    /**
     * Filter, which Estudiante to fetch.
     */
    where?: EstudianteWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Estudiantes to fetch.
     */
    orderBy?: EstudianteOrderByWithRelationInput | EstudianteOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Estudiantes.
     */
    cursor?: EstudianteWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Estudiantes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Estudiantes.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Estudiantes.
     */
    distinct?: EstudianteScalarFieldEnum | EstudianteScalarFieldEnum[]
  }

  /**
   * Estudiante findMany
   */
  export type EstudianteFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Estudiante
     */
    select?: EstudianteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Estudiante
     */
    omit?: EstudianteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EstudianteInclude<ExtArgs> | null
    /**
     * Filter, which Estudiantes to fetch.
     */
    where?: EstudianteWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Estudiantes to fetch.
     */
    orderBy?: EstudianteOrderByWithRelationInput | EstudianteOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Estudiantes.
     */
    cursor?: EstudianteWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Estudiantes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Estudiantes.
     */
    skip?: number
    distinct?: EstudianteScalarFieldEnum | EstudianteScalarFieldEnum[]
  }

  /**
   * Estudiante create
   */
  export type EstudianteCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Estudiante
     */
    select?: EstudianteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Estudiante
     */
    omit?: EstudianteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EstudianteInclude<ExtArgs> | null
    /**
     * The data needed to create a Estudiante.
     */
    data: XOR<EstudianteCreateInput, EstudianteUncheckedCreateInput>
  }

  /**
   * Estudiante createMany
   */
  export type EstudianteCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Estudiantes.
     */
    data: EstudianteCreateManyInput | EstudianteCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Estudiante update
   */
  export type EstudianteUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Estudiante
     */
    select?: EstudianteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Estudiante
     */
    omit?: EstudianteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EstudianteInclude<ExtArgs> | null
    /**
     * The data needed to update a Estudiante.
     */
    data: XOR<EstudianteUpdateInput, EstudianteUncheckedUpdateInput>
    /**
     * Choose, which Estudiante to update.
     */
    where: EstudianteWhereUniqueInput
  }

  /**
   * Estudiante updateMany
   */
  export type EstudianteUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Estudiantes.
     */
    data: XOR<EstudianteUpdateManyMutationInput, EstudianteUncheckedUpdateManyInput>
    /**
     * Filter which Estudiantes to update
     */
    where?: EstudianteWhereInput
    /**
     * Limit how many Estudiantes to update.
     */
    limit?: number
  }

  /**
   * Estudiante upsert
   */
  export type EstudianteUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Estudiante
     */
    select?: EstudianteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Estudiante
     */
    omit?: EstudianteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EstudianteInclude<ExtArgs> | null
    /**
     * The filter to search for the Estudiante to update in case it exists.
     */
    where: EstudianteWhereUniqueInput
    /**
     * In case the Estudiante found by the `where` argument doesn't exist, create a new Estudiante with this data.
     */
    create: XOR<EstudianteCreateInput, EstudianteUncheckedCreateInput>
    /**
     * In case the Estudiante was found with the provided `where` argument, update it with this data.
     */
    update: XOR<EstudianteUpdateInput, EstudianteUncheckedUpdateInput>
  }

  /**
   * Estudiante delete
   */
  export type EstudianteDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Estudiante
     */
    select?: EstudianteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Estudiante
     */
    omit?: EstudianteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EstudianteInclude<ExtArgs> | null
    /**
     * Filter which Estudiante to delete.
     */
    where: EstudianteWhereUniqueInput
  }

  /**
   * Estudiante deleteMany
   */
  export type EstudianteDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Estudiantes to delete
     */
    where?: EstudianteWhereInput
    /**
     * Limit how many Estudiantes to delete.
     */
    limit?: number
  }

  /**
   * Estudiante.tramites
   */
  export type Estudiante$tramitesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Tramite
     */
    select?: TramiteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Tramite
     */
    omit?: TramiteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TramiteInclude<ExtArgs> | null
    where?: TramiteWhereInput
    orderBy?: TramiteOrderByWithRelationInput | TramiteOrderByWithRelationInput[]
    cursor?: TramiteWhereUniqueInput
    take?: number
    skip?: number
    distinct?: TramiteScalarFieldEnum | TramiteScalarFieldEnum[]
  }

  /**
   * Estudiante.grupo
   */
  export type Estudiante$grupoArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Grupo
     */
    select?: GrupoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Grupo
     */
    omit?: GrupoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: GrupoInclude<ExtArgs> | null
    where?: GrupoWhereInput
  }

  /**
   * Estudiante.PadreFamilia
   */
  export type Estudiante$PadreFamiliaArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PadreFamilia
     */
    select?: PadreFamiliaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PadreFamilia
     */
    omit?: PadreFamiliaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PadreFamiliaInclude<ExtArgs> | null
    where?: PadreFamiliaWhereInput
  }

  /**
   * Estudiante.Calificacion
   */
  export type Estudiante$CalificacionArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Calificacion
     */
    select?: CalificacionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Calificacion
     */
    omit?: CalificacionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CalificacionInclude<ExtArgs> | null
    where?: CalificacionWhereInput
    orderBy?: CalificacionOrderByWithRelationInput | CalificacionOrderByWithRelationInput[]
    cursor?: CalificacionWhereUniqueInput
    take?: number
    skip?: number
    distinct?: CalificacionScalarFieldEnum | CalificacionScalarFieldEnum[]
  }

  /**
   * Estudiante.Asistencia
   */
  export type Estudiante$AsistenciaArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Asistencia
     */
    select?: AsistenciaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Asistencia
     */
    omit?: AsistenciaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AsistenciaInclude<ExtArgs> | null
    where?: AsistenciaWhereInput
    orderBy?: AsistenciaOrderByWithRelationInput | AsistenciaOrderByWithRelationInput[]
    cursor?: AsistenciaWhereUniqueInput
    take?: number
    skip?: number
    distinct?: AsistenciaScalarFieldEnum | AsistenciaScalarFieldEnum[]
  }

  /**
   * Estudiante without action
   */
  export type EstudianteDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Estudiante
     */
    select?: EstudianteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Estudiante
     */
    omit?: EstudianteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EstudianteInclude<ExtArgs> | null
  }


  /**
   * Model Profesor
   */

  export type AggregateProfesor = {
    _count: ProfesorCountAggregateOutputType | null
    _avg: ProfesorAvgAggregateOutputType | null
    _sum: ProfesorSumAggregateOutputType | null
    _min: ProfesorMinAggregateOutputType | null
    _max: ProfesorMaxAggregateOutputType | null
  }

  export type ProfesorAvgAggregateOutputType = {
    usuarioId: number | null
  }

  export type ProfesorSumAggregateOutputType = {
    usuarioId: number | null
  }

  export type ProfesorMinAggregateOutputType = {
    usuarioId: number | null
  }

  export type ProfesorMaxAggregateOutputType = {
    usuarioId: number | null
  }

  export type ProfesorCountAggregateOutputType = {
    usuarioId: number
    _all: number
  }


  export type ProfesorAvgAggregateInputType = {
    usuarioId?: true
  }

  export type ProfesorSumAggregateInputType = {
    usuarioId?: true
  }

  export type ProfesorMinAggregateInputType = {
    usuarioId?: true
  }

  export type ProfesorMaxAggregateInputType = {
    usuarioId?: true
  }

  export type ProfesorCountAggregateInputType = {
    usuarioId?: true
    _all?: true
  }

  export type ProfesorAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Profesor to aggregate.
     */
    where?: ProfesorWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Profesors to fetch.
     */
    orderBy?: ProfesorOrderByWithRelationInput | ProfesorOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ProfesorWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Profesors from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Profesors.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Profesors
    **/
    _count?: true | ProfesorCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: ProfesorAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: ProfesorSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ProfesorMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ProfesorMaxAggregateInputType
  }

  export type GetProfesorAggregateType<T extends ProfesorAggregateArgs> = {
        [P in keyof T & keyof AggregateProfesor]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateProfesor[P]>
      : GetScalarType<T[P], AggregateProfesor[P]>
  }




  export type ProfesorGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ProfesorWhereInput
    orderBy?: ProfesorOrderByWithAggregationInput | ProfesorOrderByWithAggregationInput[]
    by: ProfesorScalarFieldEnum[] | ProfesorScalarFieldEnum
    having?: ProfesorScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ProfesorCountAggregateInputType | true
    _avg?: ProfesorAvgAggregateInputType
    _sum?: ProfesorSumAggregateInputType
    _min?: ProfesorMinAggregateInputType
    _max?: ProfesorMaxAggregateInputType
  }

  export type ProfesorGroupByOutputType = {
    usuarioId: number
    _count: ProfesorCountAggregateOutputType | null
    _avg: ProfesorAvgAggregateOutputType | null
    _sum: ProfesorSumAggregateOutputType | null
    _min: ProfesorMinAggregateOutputType | null
    _max: ProfesorMaxAggregateOutputType | null
  }

  type GetProfesorGroupByPayload<T extends ProfesorGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ProfesorGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ProfesorGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ProfesorGroupByOutputType[P]>
            : GetScalarType<T[P], ProfesorGroupByOutputType[P]>
        }
      >
    >


  export type ProfesorSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    usuarioId?: boolean
    usuario?: boolean | UsuarioDefaultArgs<ExtArgs>
    materiales?: boolean | Profesor$materialesArgs<ExtArgs>
    Materia?: boolean | Profesor$MateriaArgs<ExtArgs>
    _count?: boolean | ProfesorCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["profesor"]>



  export type ProfesorSelectScalar = {
    usuarioId?: boolean
  }

  export type ProfesorOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"usuarioId", ExtArgs["result"]["profesor"]>
  export type ProfesorInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    usuario?: boolean | UsuarioDefaultArgs<ExtArgs>
    materiales?: boolean | Profesor$materialesArgs<ExtArgs>
    Materia?: boolean | Profesor$MateriaArgs<ExtArgs>
    _count?: boolean | ProfesorCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $ProfesorPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Profesor"
    objects: {
      usuario: Prisma.$UsuarioPayload<ExtArgs>
      materiales: Prisma.$MaterialEducativoPayload<ExtArgs>[]
      Materia: Prisma.$MateriaPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      usuarioId: number
    }, ExtArgs["result"]["profesor"]>
    composites: {}
  }

  type ProfesorGetPayload<S extends boolean | null | undefined | ProfesorDefaultArgs> = $Result.GetResult<Prisma.$ProfesorPayload, S>

  type ProfesorCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<ProfesorFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: ProfesorCountAggregateInputType | true
    }

  export interface ProfesorDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Profesor'], meta: { name: 'Profesor' } }
    /**
     * Find zero or one Profesor that matches the filter.
     * @param {ProfesorFindUniqueArgs} args - Arguments to find a Profesor
     * @example
     * // Get one Profesor
     * const profesor = await prisma.profesor.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends ProfesorFindUniqueArgs>(args: SelectSubset<T, ProfesorFindUniqueArgs<ExtArgs>>): Prisma__ProfesorClient<$Result.GetResult<Prisma.$ProfesorPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Profesor that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {ProfesorFindUniqueOrThrowArgs} args - Arguments to find a Profesor
     * @example
     * // Get one Profesor
     * const profesor = await prisma.profesor.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends ProfesorFindUniqueOrThrowArgs>(args: SelectSubset<T, ProfesorFindUniqueOrThrowArgs<ExtArgs>>): Prisma__ProfesorClient<$Result.GetResult<Prisma.$ProfesorPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Profesor that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProfesorFindFirstArgs} args - Arguments to find a Profesor
     * @example
     * // Get one Profesor
     * const profesor = await prisma.profesor.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends ProfesorFindFirstArgs>(args?: SelectSubset<T, ProfesorFindFirstArgs<ExtArgs>>): Prisma__ProfesorClient<$Result.GetResult<Prisma.$ProfesorPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Profesor that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProfesorFindFirstOrThrowArgs} args - Arguments to find a Profesor
     * @example
     * // Get one Profesor
     * const profesor = await prisma.profesor.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends ProfesorFindFirstOrThrowArgs>(args?: SelectSubset<T, ProfesorFindFirstOrThrowArgs<ExtArgs>>): Prisma__ProfesorClient<$Result.GetResult<Prisma.$ProfesorPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Profesors that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProfesorFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Profesors
     * const profesors = await prisma.profesor.findMany()
     * 
     * // Get first 10 Profesors
     * const profesors = await prisma.profesor.findMany({ take: 10 })
     * 
     * // Only select the `usuarioId`
     * const profesorWithUsuarioIdOnly = await prisma.profesor.findMany({ select: { usuarioId: true } })
     * 
     */
    findMany<T extends ProfesorFindManyArgs>(args?: SelectSubset<T, ProfesorFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ProfesorPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Profesor.
     * @param {ProfesorCreateArgs} args - Arguments to create a Profesor.
     * @example
     * // Create one Profesor
     * const Profesor = await prisma.profesor.create({
     *   data: {
     *     // ... data to create a Profesor
     *   }
     * })
     * 
     */
    create<T extends ProfesorCreateArgs>(args: SelectSubset<T, ProfesorCreateArgs<ExtArgs>>): Prisma__ProfesorClient<$Result.GetResult<Prisma.$ProfesorPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Profesors.
     * @param {ProfesorCreateManyArgs} args - Arguments to create many Profesors.
     * @example
     * // Create many Profesors
     * const profesor = await prisma.profesor.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends ProfesorCreateManyArgs>(args?: SelectSubset<T, ProfesorCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Profesor.
     * @param {ProfesorDeleteArgs} args - Arguments to delete one Profesor.
     * @example
     * // Delete one Profesor
     * const Profesor = await prisma.profesor.delete({
     *   where: {
     *     // ... filter to delete one Profesor
     *   }
     * })
     * 
     */
    delete<T extends ProfesorDeleteArgs>(args: SelectSubset<T, ProfesorDeleteArgs<ExtArgs>>): Prisma__ProfesorClient<$Result.GetResult<Prisma.$ProfesorPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Profesor.
     * @param {ProfesorUpdateArgs} args - Arguments to update one Profesor.
     * @example
     * // Update one Profesor
     * const profesor = await prisma.profesor.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends ProfesorUpdateArgs>(args: SelectSubset<T, ProfesorUpdateArgs<ExtArgs>>): Prisma__ProfesorClient<$Result.GetResult<Prisma.$ProfesorPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Profesors.
     * @param {ProfesorDeleteManyArgs} args - Arguments to filter Profesors to delete.
     * @example
     * // Delete a few Profesors
     * const { count } = await prisma.profesor.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends ProfesorDeleteManyArgs>(args?: SelectSubset<T, ProfesorDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Profesors.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProfesorUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Profesors
     * const profesor = await prisma.profesor.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends ProfesorUpdateManyArgs>(args: SelectSubset<T, ProfesorUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Profesor.
     * @param {ProfesorUpsertArgs} args - Arguments to update or create a Profesor.
     * @example
     * // Update or create a Profesor
     * const profesor = await prisma.profesor.upsert({
     *   create: {
     *     // ... data to create a Profesor
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Profesor we want to update
     *   }
     * })
     */
    upsert<T extends ProfesorUpsertArgs>(args: SelectSubset<T, ProfesorUpsertArgs<ExtArgs>>): Prisma__ProfesorClient<$Result.GetResult<Prisma.$ProfesorPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Profesors.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProfesorCountArgs} args - Arguments to filter Profesors to count.
     * @example
     * // Count the number of Profesors
     * const count = await prisma.profesor.count({
     *   where: {
     *     // ... the filter for the Profesors we want to count
     *   }
     * })
    **/
    count<T extends ProfesorCountArgs>(
      args?: Subset<T, ProfesorCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ProfesorCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Profesor.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProfesorAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ProfesorAggregateArgs>(args: Subset<T, ProfesorAggregateArgs>): Prisma.PrismaPromise<GetProfesorAggregateType<T>>

    /**
     * Group by Profesor.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ProfesorGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ProfesorGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ProfesorGroupByArgs['orderBy'] }
        : { orderBy?: ProfesorGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ProfesorGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetProfesorGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Profesor model
   */
  readonly fields: ProfesorFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Profesor.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__ProfesorClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    usuario<T extends UsuarioDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UsuarioDefaultArgs<ExtArgs>>): Prisma__UsuarioClient<$Result.GetResult<Prisma.$UsuarioPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    materiales<T extends Profesor$materialesArgs<ExtArgs> = {}>(args?: Subset<T, Profesor$materialesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MaterialEducativoPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    Materia<T extends Profesor$MateriaArgs<ExtArgs> = {}>(args?: Subset<T, Profesor$MateriaArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MateriaPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Profesor model
   */
  interface ProfesorFieldRefs {
    readonly usuarioId: FieldRef<"Profesor", 'Int'>
  }
    

  // Custom InputTypes
  /**
   * Profesor findUnique
   */
  export type ProfesorFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Profesor
     */
    select?: ProfesorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Profesor
     */
    omit?: ProfesorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProfesorInclude<ExtArgs> | null
    /**
     * Filter, which Profesor to fetch.
     */
    where: ProfesorWhereUniqueInput
  }

  /**
   * Profesor findUniqueOrThrow
   */
  export type ProfesorFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Profesor
     */
    select?: ProfesorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Profesor
     */
    omit?: ProfesorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProfesorInclude<ExtArgs> | null
    /**
     * Filter, which Profesor to fetch.
     */
    where: ProfesorWhereUniqueInput
  }

  /**
   * Profesor findFirst
   */
  export type ProfesorFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Profesor
     */
    select?: ProfesorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Profesor
     */
    omit?: ProfesorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProfesorInclude<ExtArgs> | null
    /**
     * Filter, which Profesor to fetch.
     */
    where?: ProfesorWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Profesors to fetch.
     */
    orderBy?: ProfesorOrderByWithRelationInput | ProfesorOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Profesors.
     */
    cursor?: ProfesorWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Profesors from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Profesors.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Profesors.
     */
    distinct?: ProfesorScalarFieldEnum | ProfesorScalarFieldEnum[]
  }

  /**
   * Profesor findFirstOrThrow
   */
  export type ProfesorFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Profesor
     */
    select?: ProfesorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Profesor
     */
    omit?: ProfesorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProfesorInclude<ExtArgs> | null
    /**
     * Filter, which Profesor to fetch.
     */
    where?: ProfesorWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Profesors to fetch.
     */
    orderBy?: ProfesorOrderByWithRelationInput | ProfesorOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Profesors.
     */
    cursor?: ProfesorWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Profesors from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Profesors.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Profesors.
     */
    distinct?: ProfesorScalarFieldEnum | ProfesorScalarFieldEnum[]
  }

  /**
   * Profesor findMany
   */
  export type ProfesorFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Profesor
     */
    select?: ProfesorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Profesor
     */
    omit?: ProfesorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProfesorInclude<ExtArgs> | null
    /**
     * Filter, which Profesors to fetch.
     */
    where?: ProfesorWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Profesors to fetch.
     */
    orderBy?: ProfesorOrderByWithRelationInput | ProfesorOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Profesors.
     */
    cursor?: ProfesorWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Profesors from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Profesors.
     */
    skip?: number
    distinct?: ProfesorScalarFieldEnum | ProfesorScalarFieldEnum[]
  }

  /**
   * Profesor create
   */
  export type ProfesorCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Profesor
     */
    select?: ProfesorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Profesor
     */
    omit?: ProfesorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProfesorInclude<ExtArgs> | null
    /**
     * The data needed to create a Profesor.
     */
    data: XOR<ProfesorCreateInput, ProfesorUncheckedCreateInput>
  }

  /**
   * Profesor createMany
   */
  export type ProfesorCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Profesors.
     */
    data: ProfesorCreateManyInput | ProfesorCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Profesor update
   */
  export type ProfesorUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Profesor
     */
    select?: ProfesorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Profesor
     */
    omit?: ProfesorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProfesorInclude<ExtArgs> | null
    /**
     * The data needed to update a Profesor.
     */
    data: XOR<ProfesorUpdateInput, ProfesorUncheckedUpdateInput>
    /**
     * Choose, which Profesor to update.
     */
    where: ProfesorWhereUniqueInput
  }

  /**
   * Profesor updateMany
   */
  export type ProfesorUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Profesors.
     */
    data: XOR<ProfesorUpdateManyMutationInput, ProfesorUncheckedUpdateManyInput>
    /**
     * Filter which Profesors to update
     */
    where?: ProfesorWhereInput
    /**
     * Limit how many Profesors to update.
     */
    limit?: number
  }

  /**
   * Profesor upsert
   */
  export type ProfesorUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Profesor
     */
    select?: ProfesorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Profesor
     */
    omit?: ProfesorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProfesorInclude<ExtArgs> | null
    /**
     * The filter to search for the Profesor to update in case it exists.
     */
    where: ProfesorWhereUniqueInput
    /**
     * In case the Profesor found by the `where` argument doesn't exist, create a new Profesor with this data.
     */
    create: XOR<ProfesorCreateInput, ProfesorUncheckedCreateInput>
    /**
     * In case the Profesor was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ProfesorUpdateInput, ProfesorUncheckedUpdateInput>
  }

  /**
   * Profesor delete
   */
  export type ProfesorDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Profesor
     */
    select?: ProfesorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Profesor
     */
    omit?: ProfesorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProfesorInclude<ExtArgs> | null
    /**
     * Filter which Profesor to delete.
     */
    where: ProfesorWhereUniqueInput
  }

  /**
   * Profesor deleteMany
   */
  export type ProfesorDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Profesors to delete
     */
    where?: ProfesorWhereInput
    /**
     * Limit how many Profesors to delete.
     */
    limit?: number
  }

  /**
   * Profesor.materiales
   */
  export type Profesor$materialesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MaterialEducativo
     */
    select?: MaterialEducativoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MaterialEducativo
     */
    omit?: MaterialEducativoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MaterialEducativoInclude<ExtArgs> | null
    where?: MaterialEducativoWhereInput
    orderBy?: MaterialEducativoOrderByWithRelationInput | MaterialEducativoOrderByWithRelationInput[]
    cursor?: MaterialEducativoWhereUniqueInput
    take?: number
    skip?: number
    distinct?: MaterialEducativoScalarFieldEnum | MaterialEducativoScalarFieldEnum[]
  }

  /**
   * Profesor.Materia
   */
  export type Profesor$MateriaArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Materia
     */
    select?: MateriaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Materia
     */
    omit?: MateriaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MateriaInclude<ExtArgs> | null
    where?: MateriaWhereInput
    orderBy?: MateriaOrderByWithRelationInput | MateriaOrderByWithRelationInput[]
    cursor?: MateriaWhereUniqueInput
    take?: number
    skip?: number
    distinct?: MateriaScalarFieldEnum | MateriaScalarFieldEnum[]
  }

  /**
   * Profesor without action
   */
  export type ProfesorDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Profesor
     */
    select?: ProfesorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Profesor
     */
    omit?: ProfesorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ProfesorInclude<ExtArgs> | null
  }


  /**
   * Model PadreFamilia
   */

  export type AggregatePadreFamilia = {
    _count: PadreFamiliaCountAggregateOutputType | null
    _avg: PadreFamiliaAvgAggregateOutputType | null
    _sum: PadreFamiliaSumAggregateOutputType | null
    _min: PadreFamiliaMinAggregateOutputType | null
    _max: PadreFamiliaMaxAggregateOutputType | null
  }

  export type PadreFamiliaAvgAggregateOutputType = {
    usuarioId: number | null
  }

  export type PadreFamiliaSumAggregateOutputType = {
    usuarioId: number | null
  }

  export type PadreFamiliaMinAggregateOutputType = {
    usuarioId: number | null
    domicilio: string | null
  }

  export type PadreFamiliaMaxAggregateOutputType = {
    usuarioId: number | null
    domicilio: string | null
  }

  export type PadreFamiliaCountAggregateOutputType = {
    usuarioId: number
    domicilio: number
    _all: number
  }


  export type PadreFamiliaAvgAggregateInputType = {
    usuarioId?: true
  }

  export type PadreFamiliaSumAggregateInputType = {
    usuarioId?: true
  }

  export type PadreFamiliaMinAggregateInputType = {
    usuarioId?: true
    domicilio?: true
  }

  export type PadreFamiliaMaxAggregateInputType = {
    usuarioId?: true
    domicilio?: true
  }

  export type PadreFamiliaCountAggregateInputType = {
    usuarioId?: true
    domicilio?: true
    _all?: true
  }

  export type PadreFamiliaAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which PadreFamilia to aggregate.
     */
    where?: PadreFamiliaWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PadreFamilias to fetch.
     */
    orderBy?: PadreFamiliaOrderByWithRelationInput | PadreFamiliaOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: PadreFamiliaWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PadreFamilias from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PadreFamilias.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned PadreFamilias
    **/
    _count?: true | PadreFamiliaCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: PadreFamiliaAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: PadreFamiliaSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: PadreFamiliaMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: PadreFamiliaMaxAggregateInputType
  }

  export type GetPadreFamiliaAggregateType<T extends PadreFamiliaAggregateArgs> = {
        [P in keyof T & keyof AggregatePadreFamilia]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregatePadreFamilia[P]>
      : GetScalarType<T[P], AggregatePadreFamilia[P]>
  }




  export type PadreFamiliaGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PadreFamiliaWhereInput
    orderBy?: PadreFamiliaOrderByWithAggregationInput | PadreFamiliaOrderByWithAggregationInput[]
    by: PadreFamiliaScalarFieldEnum[] | PadreFamiliaScalarFieldEnum
    having?: PadreFamiliaScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: PadreFamiliaCountAggregateInputType | true
    _avg?: PadreFamiliaAvgAggregateInputType
    _sum?: PadreFamiliaSumAggregateInputType
    _min?: PadreFamiliaMinAggregateInputType
    _max?: PadreFamiliaMaxAggregateInputType
  }

  export type PadreFamiliaGroupByOutputType = {
    usuarioId: number
    domicilio: string
    _count: PadreFamiliaCountAggregateOutputType | null
    _avg: PadreFamiliaAvgAggregateOutputType | null
    _sum: PadreFamiliaSumAggregateOutputType | null
    _min: PadreFamiliaMinAggregateOutputType | null
    _max: PadreFamiliaMaxAggregateOutputType | null
  }

  type GetPadreFamiliaGroupByPayload<T extends PadreFamiliaGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<PadreFamiliaGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof PadreFamiliaGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], PadreFamiliaGroupByOutputType[P]>
            : GetScalarType<T[P], PadreFamiliaGroupByOutputType[P]>
        }
      >
    >


  export type PadreFamiliaSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    usuarioId?: boolean
    domicilio?: boolean
    usuario?: boolean | UsuarioDefaultArgs<ExtArgs>
    estudiantes?: boolean | PadreFamilia$estudiantesArgs<ExtArgs>
    _count?: boolean | PadreFamiliaCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["padreFamilia"]>



  export type PadreFamiliaSelectScalar = {
    usuarioId?: boolean
    domicilio?: boolean
  }

  export type PadreFamiliaOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"usuarioId" | "domicilio", ExtArgs["result"]["padreFamilia"]>
  export type PadreFamiliaInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    usuario?: boolean | UsuarioDefaultArgs<ExtArgs>
    estudiantes?: boolean | PadreFamilia$estudiantesArgs<ExtArgs>
    _count?: boolean | PadreFamiliaCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $PadreFamiliaPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "PadreFamilia"
    objects: {
      usuario: Prisma.$UsuarioPayload<ExtArgs>
      estudiantes: Prisma.$EstudiantePayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      usuarioId: number
      domicilio: string
    }, ExtArgs["result"]["padreFamilia"]>
    composites: {}
  }

  type PadreFamiliaGetPayload<S extends boolean | null | undefined | PadreFamiliaDefaultArgs> = $Result.GetResult<Prisma.$PadreFamiliaPayload, S>

  type PadreFamiliaCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<PadreFamiliaFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: PadreFamiliaCountAggregateInputType | true
    }

  export interface PadreFamiliaDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['PadreFamilia'], meta: { name: 'PadreFamilia' } }
    /**
     * Find zero or one PadreFamilia that matches the filter.
     * @param {PadreFamiliaFindUniqueArgs} args - Arguments to find a PadreFamilia
     * @example
     * // Get one PadreFamilia
     * const padreFamilia = await prisma.padreFamilia.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends PadreFamiliaFindUniqueArgs>(args: SelectSubset<T, PadreFamiliaFindUniqueArgs<ExtArgs>>): Prisma__PadreFamiliaClient<$Result.GetResult<Prisma.$PadreFamiliaPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one PadreFamilia that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {PadreFamiliaFindUniqueOrThrowArgs} args - Arguments to find a PadreFamilia
     * @example
     * // Get one PadreFamilia
     * const padreFamilia = await prisma.padreFamilia.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends PadreFamiliaFindUniqueOrThrowArgs>(args: SelectSubset<T, PadreFamiliaFindUniqueOrThrowArgs<ExtArgs>>): Prisma__PadreFamiliaClient<$Result.GetResult<Prisma.$PadreFamiliaPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first PadreFamilia that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PadreFamiliaFindFirstArgs} args - Arguments to find a PadreFamilia
     * @example
     * // Get one PadreFamilia
     * const padreFamilia = await prisma.padreFamilia.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends PadreFamiliaFindFirstArgs>(args?: SelectSubset<T, PadreFamiliaFindFirstArgs<ExtArgs>>): Prisma__PadreFamiliaClient<$Result.GetResult<Prisma.$PadreFamiliaPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first PadreFamilia that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PadreFamiliaFindFirstOrThrowArgs} args - Arguments to find a PadreFamilia
     * @example
     * // Get one PadreFamilia
     * const padreFamilia = await prisma.padreFamilia.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends PadreFamiliaFindFirstOrThrowArgs>(args?: SelectSubset<T, PadreFamiliaFindFirstOrThrowArgs<ExtArgs>>): Prisma__PadreFamiliaClient<$Result.GetResult<Prisma.$PadreFamiliaPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more PadreFamilias that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PadreFamiliaFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all PadreFamilias
     * const padreFamilias = await prisma.padreFamilia.findMany()
     * 
     * // Get first 10 PadreFamilias
     * const padreFamilias = await prisma.padreFamilia.findMany({ take: 10 })
     * 
     * // Only select the `usuarioId`
     * const padreFamiliaWithUsuarioIdOnly = await prisma.padreFamilia.findMany({ select: { usuarioId: true } })
     * 
     */
    findMany<T extends PadreFamiliaFindManyArgs>(args?: SelectSubset<T, PadreFamiliaFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PadreFamiliaPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a PadreFamilia.
     * @param {PadreFamiliaCreateArgs} args - Arguments to create a PadreFamilia.
     * @example
     * // Create one PadreFamilia
     * const PadreFamilia = await prisma.padreFamilia.create({
     *   data: {
     *     // ... data to create a PadreFamilia
     *   }
     * })
     * 
     */
    create<T extends PadreFamiliaCreateArgs>(args: SelectSubset<T, PadreFamiliaCreateArgs<ExtArgs>>): Prisma__PadreFamiliaClient<$Result.GetResult<Prisma.$PadreFamiliaPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many PadreFamilias.
     * @param {PadreFamiliaCreateManyArgs} args - Arguments to create many PadreFamilias.
     * @example
     * // Create many PadreFamilias
     * const padreFamilia = await prisma.padreFamilia.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends PadreFamiliaCreateManyArgs>(args?: SelectSubset<T, PadreFamiliaCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a PadreFamilia.
     * @param {PadreFamiliaDeleteArgs} args - Arguments to delete one PadreFamilia.
     * @example
     * // Delete one PadreFamilia
     * const PadreFamilia = await prisma.padreFamilia.delete({
     *   where: {
     *     // ... filter to delete one PadreFamilia
     *   }
     * })
     * 
     */
    delete<T extends PadreFamiliaDeleteArgs>(args: SelectSubset<T, PadreFamiliaDeleteArgs<ExtArgs>>): Prisma__PadreFamiliaClient<$Result.GetResult<Prisma.$PadreFamiliaPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one PadreFamilia.
     * @param {PadreFamiliaUpdateArgs} args - Arguments to update one PadreFamilia.
     * @example
     * // Update one PadreFamilia
     * const padreFamilia = await prisma.padreFamilia.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends PadreFamiliaUpdateArgs>(args: SelectSubset<T, PadreFamiliaUpdateArgs<ExtArgs>>): Prisma__PadreFamiliaClient<$Result.GetResult<Prisma.$PadreFamiliaPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more PadreFamilias.
     * @param {PadreFamiliaDeleteManyArgs} args - Arguments to filter PadreFamilias to delete.
     * @example
     * // Delete a few PadreFamilias
     * const { count } = await prisma.padreFamilia.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends PadreFamiliaDeleteManyArgs>(args?: SelectSubset<T, PadreFamiliaDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more PadreFamilias.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PadreFamiliaUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many PadreFamilias
     * const padreFamilia = await prisma.padreFamilia.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends PadreFamiliaUpdateManyArgs>(args: SelectSubset<T, PadreFamiliaUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one PadreFamilia.
     * @param {PadreFamiliaUpsertArgs} args - Arguments to update or create a PadreFamilia.
     * @example
     * // Update or create a PadreFamilia
     * const padreFamilia = await prisma.padreFamilia.upsert({
     *   create: {
     *     // ... data to create a PadreFamilia
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the PadreFamilia we want to update
     *   }
     * })
     */
    upsert<T extends PadreFamiliaUpsertArgs>(args: SelectSubset<T, PadreFamiliaUpsertArgs<ExtArgs>>): Prisma__PadreFamiliaClient<$Result.GetResult<Prisma.$PadreFamiliaPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of PadreFamilias.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PadreFamiliaCountArgs} args - Arguments to filter PadreFamilias to count.
     * @example
     * // Count the number of PadreFamilias
     * const count = await prisma.padreFamilia.count({
     *   where: {
     *     // ... the filter for the PadreFamilias we want to count
     *   }
     * })
    **/
    count<T extends PadreFamiliaCountArgs>(
      args?: Subset<T, PadreFamiliaCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], PadreFamiliaCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a PadreFamilia.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PadreFamiliaAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends PadreFamiliaAggregateArgs>(args: Subset<T, PadreFamiliaAggregateArgs>): Prisma.PrismaPromise<GetPadreFamiliaAggregateType<T>>

    /**
     * Group by PadreFamilia.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PadreFamiliaGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends PadreFamiliaGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: PadreFamiliaGroupByArgs['orderBy'] }
        : { orderBy?: PadreFamiliaGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, PadreFamiliaGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetPadreFamiliaGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the PadreFamilia model
   */
  readonly fields: PadreFamiliaFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for PadreFamilia.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__PadreFamiliaClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    usuario<T extends UsuarioDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UsuarioDefaultArgs<ExtArgs>>): Prisma__UsuarioClient<$Result.GetResult<Prisma.$UsuarioPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    estudiantes<T extends PadreFamilia$estudiantesArgs<ExtArgs> = {}>(args?: Subset<T, PadreFamilia$estudiantesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$EstudiantePayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the PadreFamilia model
   */
  interface PadreFamiliaFieldRefs {
    readonly usuarioId: FieldRef<"PadreFamilia", 'Int'>
    readonly domicilio: FieldRef<"PadreFamilia", 'String'>
  }
    

  // Custom InputTypes
  /**
   * PadreFamilia findUnique
   */
  export type PadreFamiliaFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PadreFamilia
     */
    select?: PadreFamiliaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PadreFamilia
     */
    omit?: PadreFamiliaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PadreFamiliaInclude<ExtArgs> | null
    /**
     * Filter, which PadreFamilia to fetch.
     */
    where: PadreFamiliaWhereUniqueInput
  }

  /**
   * PadreFamilia findUniqueOrThrow
   */
  export type PadreFamiliaFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PadreFamilia
     */
    select?: PadreFamiliaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PadreFamilia
     */
    omit?: PadreFamiliaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PadreFamiliaInclude<ExtArgs> | null
    /**
     * Filter, which PadreFamilia to fetch.
     */
    where: PadreFamiliaWhereUniqueInput
  }

  /**
   * PadreFamilia findFirst
   */
  export type PadreFamiliaFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PadreFamilia
     */
    select?: PadreFamiliaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PadreFamilia
     */
    omit?: PadreFamiliaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PadreFamiliaInclude<ExtArgs> | null
    /**
     * Filter, which PadreFamilia to fetch.
     */
    where?: PadreFamiliaWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PadreFamilias to fetch.
     */
    orderBy?: PadreFamiliaOrderByWithRelationInput | PadreFamiliaOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for PadreFamilias.
     */
    cursor?: PadreFamiliaWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PadreFamilias from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PadreFamilias.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PadreFamilias.
     */
    distinct?: PadreFamiliaScalarFieldEnum | PadreFamiliaScalarFieldEnum[]
  }

  /**
   * PadreFamilia findFirstOrThrow
   */
  export type PadreFamiliaFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PadreFamilia
     */
    select?: PadreFamiliaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PadreFamilia
     */
    omit?: PadreFamiliaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PadreFamiliaInclude<ExtArgs> | null
    /**
     * Filter, which PadreFamilia to fetch.
     */
    where?: PadreFamiliaWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PadreFamilias to fetch.
     */
    orderBy?: PadreFamiliaOrderByWithRelationInput | PadreFamiliaOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for PadreFamilias.
     */
    cursor?: PadreFamiliaWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PadreFamilias from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PadreFamilias.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PadreFamilias.
     */
    distinct?: PadreFamiliaScalarFieldEnum | PadreFamiliaScalarFieldEnum[]
  }

  /**
   * PadreFamilia findMany
   */
  export type PadreFamiliaFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PadreFamilia
     */
    select?: PadreFamiliaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PadreFamilia
     */
    omit?: PadreFamiliaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PadreFamiliaInclude<ExtArgs> | null
    /**
     * Filter, which PadreFamilias to fetch.
     */
    where?: PadreFamiliaWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PadreFamilias to fetch.
     */
    orderBy?: PadreFamiliaOrderByWithRelationInput | PadreFamiliaOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing PadreFamilias.
     */
    cursor?: PadreFamiliaWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PadreFamilias from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PadreFamilias.
     */
    skip?: number
    distinct?: PadreFamiliaScalarFieldEnum | PadreFamiliaScalarFieldEnum[]
  }

  /**
   * PadreFamilia create
   */
  export type PadreFamiliaCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PadreFamilia
     */
    select?: PadreFamiliaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PadreFamilia
     */
    omit?: PadreFamiliaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PadreFamiliaInclude<ExtArgs> | null
    /**
     * The data needed to create a PadreFamilia.
     */
    data: XOR<PadreFamiliaCreateInput, PadreFamiliaUncheckedCreateInput>
  }

  /**
   * PadreFamilia createMany
   */
  export type PadreFamiliaCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many PadreFamilias.
     */
    data: PadreFamiliaCreateManyInput | PadreFamiliaCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * PadreFamilia update
   */
  export type PadreFamiliaUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PadreFamilia
     */
    select?: PadreFamiliaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PadreFamilia
     */
    omit?: PadreFamiliaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PadreFamiliaInclude<ExtArgs> | null
    /**
     * The data needed to update a PadreFamilia.
     */
    data: XOR<PadreFamiliaUpdateInput, PadreFamiliaUncheckedUpdateInput>
    /**
     * Choose, which PadreFamilia to update.
     */
    where: PadreFamiliaWhereUniqueInput
  }

  /**
   * PadreFamilia updateMany
   */
  export type PadreFamiliaUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update PadreFamilias.
     */
    data: XOR<PadreFamiliaUpdateManyMutationInput, PadreFamiliaUncheckedUpdateManyInput>
    /**
     * Filter which PadreFamilias to update
     */
    where?: PadreFamiliaWhereInput
    /**
     * Limit how many PadreFamilias to update.
     */
    limit?: number
  }

  /**
   * PadreFamilia upsert
   */
  export type PadreFamiliaUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PadreFamilia
     */
    select?: PadreFamiliaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PadreFamilia
     */
    omit?: PadreFamiliaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PadreFamiliaInclude<ExtArgs> | null
    /**
     * The filter to search for the PadreFamilia to update in case it exists.
     */
    where: PadreFamiliaWhereUniqueInput
    /**
     * In case the PadreFamilia found by the `where` argument doesn't exist, create a new PadreFamilia with this data.
     */
    create: XOR<PadreFamiliaCreateInput, PadreFamiliaUncheckedCreateInput>
    /**
     * In case the PadreFamilia was found with the provided `where` argument, update it with this data.
     */
    update: XOR<PadreFamiliaUpdateInput, PadreFamiliaUncheckedUpdateInput>
  }

  /**
   * PadreFamilia delete
   */
  export type PadreFamiliaDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PadreFamilia
     */
    select?: PadreFamiliaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PadreFamilia
     */
    omit?: PadreFamiliaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PadreFamiliaInclude<ExtArgs> | null
    /**
     * Filter which PadreFamilia to delete.
     */
    where: PadreFamiliaWhereUniqueInput
  }

  /**
   * PadreFamilia deleteMany
   */
  export type PadreFamiliaDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which PadreFamilias to delete
     */
    where?: PadreFamiliaWhereInput
    /**
     * Limit how many PadreFamilias to delete.
     */
    limit?: number
  }

  /**
   * PadreFamilia.estudiantes
   */
  export type PadreFamilia$estudiantesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Estudiante
     */
    select?: EstudianteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Estudiante
     */
    omit?: EstudianteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EstudianteInclude<ExtArgs> | null
    where?: EstudianteWhereInput
    orderBy?: EstudianteOrderByWithRelationInput | EstudianteOrderByWithRelationInput[]
    cursor?: EstudianteWhereUniqueInput
    take?: number
    skip?: number
    distinct?: EstudianteScalarFieldEnum | EstudianteScalarFieldEnum[]
  }

  /**
   * PadreFamilia without action
   */
  export type PadreFamiliaDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PadreFamilia
     */
    select?: PadreFamiliaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PadreFamilia
     */
    omit?: PadreFamiliaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PadreFamiliaInclude<ExtArgs> | null
  }


  /**
   * Model Grupo
   */

  export type AggregateGrupo = {
    _count: GrupoCountAggregateOutputType | null
    _avg: GrupoAvgAggregateOutputType | null
    _sum: GrupoSumAggregateOutputType | null
    _min: GrupoMinAggregateOutputType | null
    _max: GrupoMaxAggregateOutputType | null
  }

  export type GrupoAvgAggregateOutputType = {
    id: number | null
    grado: number | null
  }

  export type GrupoSumAggregateOutputType = {
    id: number | null
    grado: number | null
  }

  export type GrupoMinAggregateOutputType = {
    id: number | null
    nombre: string | null
    grado: number | null
  }

  export type GrupoMaxAggregateOutputType = {
    id: number | null
    nombre: string | null
    grado: number | null
  }

  export type GrupoCountAggregateOutputType = {
    id: number
    nombre: number
    grado: number
    _all: number
  }


  export type GrupoAvgAggregateInputType = {
    id?: true
    grado?: true
  }

  export type GrupoSumAggregateInputType = {
    id?: true
    grado?: true
  }

  export type GrupoMinAggregateInputType = {
    id?: true
    nombre?: true
    grado?: true
  }

  export type GrupoMaxAggregateInputType = {
    id?: true
    nombre?: true
    grado?: true
  }

  export type GrupoCountAggregateInputType = {
    id?: true
    nombre?: true
    grado?: true
    _all?: true
  }

  export type GrupoAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Grupo to aggregate.
     */
    where?: GrupoWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Grupos to fetch.
     */
    orderBy?: GrupoOrderByWithRelationInput | GrupoOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: GrupoWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Grupos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Grupos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Grupos
    **/
    _count?: true | GrupoCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: GrupoAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: GrupoSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: GrupoMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: GrupoMaxAggregateInputType
  }

  export type GetGrupoAggregateType<T extends GrupoAggregateArgs> = {
        [P in keyof T & keyof AggregateGrupo]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateGrupo[P]>
      : GetScalarType<T[P], AggregateGrupo[P]>
  }




  export type GrupoGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: GrupoWhereInput
    orderBy?: GrupoOrderByWithAggregationInput | GrupoOrderByWithAggregationInput[]
    by: GrupoScalarFieldEnum[] | GrupoScalarFieldEnum
    having?: GrupoScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: GrupoCountAggregateInputType | true
    _avg?: GrupoAvgAggregateInputType
    _sum?: GrupoSumAggregateInputType
    _min?: GrupoMinAggregateInputType
    _max?: GrupoMaxAggregateInputType
  }

  export type GrupoGroupByOutputType = {
    id: number
    nombre: string
    grado: number
    _count: GrupoCountAggregateOutputType | null
    _avg: GrupoAvgAggregateOutputType | null
    _sum: GrupoSumAggregateOutputType | null
    _min: GrupoMinAggregateOutputType | null
    _max: GrupoMaxAggregateOutputType | null
  }

  type GetGrupoGroupByPayload<T extends GrupoGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<GrupoGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof GrupoGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], GrupoGroupByOutputType[P]>
            : GetScalarType<T[P], GrupoGroupByOutputType[P]>
        }
      >
    >


  export type GrupoSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    nombre?: boolean
    grado?: boolean
    estudiantes?: boolean | Grupo$estudiantesArgs<ExtArgs>
    inscripciones?: boolean | Grupo$inscripcionesArgs<ExtArgs>
    materiales?: boolean | Grupo$materialesArgs<ExtArgs>
    _count?: boolean | GrupoCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["grupo"]>



  export type GrupoSelectScalar = {
    id?: boolean
    nombre?: boolean
    grado?: boolean
  }

  export type GrupoOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "nombre" | "grado", ExtArgs["result"]["grupo"]>
  export type GrupoInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    estudiantes?: boolean | Grupo$estudiantesArgs<ExtArgs>
    inscripciones?: boolean | Grupo$inscripcionesArgs<ExtArgs>
    materiales?: boolean | Grupo$materialesArgs<ExtArgs>
    _count?: boolean | GrupoCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $GrupoPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Grupo"
    objects: {
      estudiantes: Prisma.$EstudiantePayload<ExtArgs>[]
      inscripciones: Prisma.$InscripcionPayload<ExtArgs>[]
      materiales: Prisma.$MaterialEducativoPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      nombre: string
      grado: number
    }, ExtArgs["result"]["grupo"]>
    composites: {}
  }

  type GrupoGetPayload<S extends boolean | null | undefined | GrupoDefaultArgs> = $Result.GetResult<Prisma.$GrupoPayload, S>

  type GrupoCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<GrupoFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: GrupoCountAggregateInputType | true
    }

  export interface GrupoDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Grupo'], meta: { name: 'Grupo' } }
    /**
     * Find zero or one Grupo that matches the filter.
     * @param {GrupoFindUniqueArgs} args - Arguments to find a Grupo
     * @example
     * // Get one Grupo
     * const grupo = await prisma.grupo.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends GrupoFindUniqueArgs>(args: SelectSubset<T, GrupoFindUniqueArgs<ExtArgs>>): Prisma__GrupoClient<$Result.GetResult<Prisma.$GrupoPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Grupo that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {GrupoFindUniqueOrThrowArgs} args - Arguments to find a Grupo
     * @example
     * // Get one Grupo
     * const grupo = await prisma.grupo.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends GrupoFindUniqueOrThrowArgs>(args: SelectSubset<T, GrupoFindUniqueOrThrowArgs<ExtArgs>>): Prisma__GrupoClient<$Result.GetResult<Prisma.$GrupoPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Grupo that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {GrupoFindFirstArgs} args - Arguments to find a Grupo
     * @example
     * // Get one Grupo
     * const grupo = await prisma.grupo.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends GrupoFindFirstArgs>(args?: SelectSubset<T, GrupoFindFirstArgs<ExtArgs>>): Prisma__GrupoClient<$Result.GetResult<Prisma.$GrupoPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Grupo that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {GrupoFindFirstOrThrowArgs} args - Arguments to find a Grupo
     * @example
     * // Get one Grupo
     * const grupo = await prisma.grupo.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends GrupoFindFirstOrThrowArgs>(args?: SelectSubset<T, GrupoFindFirstOrThrowArgs<ExtArgs>>): Prisma__GrupoClient<$Result.GetResult<Prisma.$GrupoPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Grupos that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {GrupoFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Grupos
     * const grupos = await prisma.grupo.findMany()
     * 
     * // Get first 10 Grupos
     * const grupos = await prisma.grupo.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const grupoWithIdOnly = await prisma.grupo.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends GrupoFindManyArgs>(args?: SelectSubset<T, GrupoFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$GrupoPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Grupo.
     * @param {GrupoCreateArgs} args - Arguments to create a Grupo.
     * @example
     * // Create one Grupo
     * const Grupo = await prisma.grupo.create({
     *   data: {
     *     // ... data to create a Grupo
     *   }
     * })
     * 
     */
    create<T extends GrupoCreateArgs>(args: SelectSubset<T, GrupoCreateArgs<ExtArgs>>): Prisma__GrupoClient<$Result.GetResult<Prisma.$GrupoPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Grupos.
     * @param {GrupoCreateManyArgs} args - Arguments to create many Grupos.
     * @example
     * // Create many Grupos
     * const grupo = await prisma.grupo.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends GrupoCreateManyArgs>(args?: SelectSubset<T, GrupoCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Grupo.
     * @param {GrupoDeleteArgs} args - Arguments to delete one Grupo.
     * @example
     * // Delete one Grupo
     * const Grupo = await prisma.grupo.delete({
     *   where: {
     *     // ... filter to delete one Grupo
     *   }
     * })
     * 
     */
    delete<T extends GrupoDeleteArgs>(args: SelectSubset<T, GrupoDeleteArgs<ExtArgs>>): Prisma__GrupoClient<$Result.GetResult<Prisma.$GrupoPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Grupo.
     * @param {GrupoUpdateArgs} args - Arguments to update one Grupo.
     * @example
     * // Update one Grupo
     * const grupo = await prisma.grupo.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends GrupoUpdateArgs>(args: SelectSubset<T, GrupoUpdateArgs<ExtArgs>>): Prisma__GrupoClient<$Result.GetResult<Prisma.$GrupoPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Grupos.
     * @param {GrupoDeleteManyArgs} args - Arguments to filter Grupos to delete.
     * @example
     * // Delete a few Grupos
     * const { count } = await prisma.grupo.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends GrupoDeleteManyArgs>(args?: SelectSubset<T, GrupoDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Grupos.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {GrupoUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Grupos
     * const grupo = await prisma.grupo.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends GrupoUpdateManyArgs>(args: SelectSubset<T, GrupoUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Grupo.
     * @param {GrupoUpsertArgs} args - Arguments to update or create a Grupo.
     * @example
     * // Update or create a Grupo
     * const grupo = await prisma.grupo.upsert({
     *   create: {
     *     // ... data to create a Grupo
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Grupo we want to update
     *   }
     * })
     */
    upsert<T extends GrupoUpsertArgs>(args: SelectSubset<T, GrupoUpsertArgs<ExtArgs>>): Prisma__GrupoClient<$Result.GetResult<Prisma.$GrupoPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Grupos.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {GrupoCountArgs} args - Arguments to filter Grupos to count.
     * @example
     * // Count the number of Grupos
     * const count = await prisma.grupo.count({
     *   where: {
     *     // ... the filter for the Grupos we want to count
     *   }
     * })
    **/
    count<T extends GrupoCountArgs>(
      args?: Subset<T, GrupoCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], GrupoCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Grupo.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {GrupoAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends GrupoAggregateArgs>(args: Subset<T, GrupoAggregateArgs>): Prisma.PrismaPromise<GetGrupoAggregateType<T>>

    /**
     * Group by Grupo.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {GrupoGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends GrupoGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: GrupoGroupByArgs['orderBy'] }
        : { orderBy?: GrupoGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, GrupoGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetGrupoGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Grupo model
   */
  readonly fields: GrupoFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Grupo.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__GrupoClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    estudiantes<T extends Grupo$estudiantesArgs<ExtArgs> = {}>(args?: Subset<T, Grupo$estudiantesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$EstudiantePayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    inscripciones<T extends Grupo$inscripcionesArgs<ExtArgs> = {}>(args?: Subset<T, Grupo$inscripcionesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$InscripcionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    materiales<T extends Grupo$materialesArgs<ExtArgs> = {}>(args?: Subset<T, Grupo$materialesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MaterialEducativoPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Grupo model
   */
  interface GrupoFieldRefs {
    readonly id: FieldRef<"Grupo", 'Int'>
    readonly nombre: FieldRef<"Grupo", 'String'>
    readonly grado: FieldRef<"Grupo", 'Int'>
  }
    

  // Custom InputTypes
  /**
   * Grupo findUnique
   */
  export type GrupoFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Grupo
     */
    select?: GrupoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Grupo
     */
    omit?: GrupoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: GrupoInclude<ExtArgs> | null
    /**
     * Filter, which Grupo to fetch.
     */
    where: GrupoWhereUniqueInput
  }

  /**
   * Grupo findUniqueOrThrow
   */
  export type GrupoFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Grupo
     */
    select?: GrupoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Grupo
     */
    omit?: GrupoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: GrupoInclude<ExtArgs> | null
    /**
     * Filter, which Grupo to fetch.
     */
    where: GrupoWhereUniqueInput
  }

  /**
   * Grupo findFirst
   */
  export type GrupoFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Grupo
     */
    select?: GrupoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Grupo
     */
    omit?: GrupoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: GrupoInclude<ExtArgs> | null
    /**
     * Filter, which Grupo to fetch.
     */
    where?: GrupoWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Grupos to fetch.
     */
    orderBy?: GrupoOrderByWithRelationInput | GrupoOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Grupos.
     */
    cursor?: GrupoWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Grupos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Grupos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Grupos.
     */
    distinct?: GrupoScalarFieldEnum | GrupoScalarFieldEnum[]
  }

  /**
   * Grupo findFirstOrThrow
   */
  export type GrupoFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Grupo
     */
    select?: GrupoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Grupo
     */
    omit?: GrupoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: GrupoInclude<ExtArgs> | null
    /**
     * Filter, which Grupo to fetch.
     */
    where?: GrupoWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Grupos to fetch.
     */
    orderBy?: GrupoOrderByWithRelationInput | GrupoOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Grupos.
     */
    cursor?: GrupoWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Grupos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Grupos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Grupos.
     */
    distinct?: GrupoScalarFieldEnum | GrupoScalarFieldEnum[]
  }

  /**
   * Grupo findMany
   */
  export type GrupoFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Grupo
     */
    select?: GrupoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Grupo
     */
    omit?: GrupoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: GrupoInclude<ExtArgs> | null
    /**
     * Filter, which Grupos to fetch.
     */
    where?: GrupoWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Grupos to fetch.
     */
    orderBy?: GrupoOrderByWithRelationInput | GrupoOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Grupos.
     */
    cursor?: GrupoWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Grupos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Grupos.
     */
    skip?: number
    distinct?: GrupoScalarFieldEnum | GrupoScalarFieldEnum[]
  }

  /**
   * Grupo create
   */
  export type GrupoCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Grupo
     */
    select?: GrupoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Grupo
     */
    omit?: GrupoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: GrupoInclude<ExtArgs> | null
    /**
     * The data needed to create a Grupo.
     */
    data: XOR<GrupoCreateInput, GrupoUncheckedCreateInput>
  }

  /**
   * Grupo createMany
   */
  export type GrupoCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Grupos.
     */
    data: GrupoCreateManyInput | GrupoCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Grupo update
   */
  export type GrupoUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Grupo
     */
    select?: GrupoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Grupo
     */
    omit?: GrupoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: GrupoInclude<ExtArgs> | null
    /**
     * The data needed to update a Grupo.
     */
    data: XOR<GrupoUpdateInput, GrupoUncheckedUpdateInput>
    /**
     * Choose, which Grupo to update.
     */
    where: GrupoWhereUniqueInput
  }

  /**
   * Grupo updateMany
   */
  export type GrupoUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Grupos.
     */
    data: XOR<GrupoUpdateManyMutationInput, GrupoUncheckedUpdateManyInput>
    /**
     * Filter which Grupos to update
     */
    where?: GrupoWhereInput
    /**
     * Limit how many Grupos to update.
     */
    limit?: number
  }

  /**
   * Grupo upsert
   */
  export type GrupoUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Grupo
     */
    select?: GrupoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Grupo
     */
    omit?: GrupoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: GrupoInclude<ExtArgs> | null
    /**
     * The filter to search for the Grupo to update in case it exists.
     */
    where: GrupoWhereUniqueInput
    /**
     * In case the Grupo found by the `where` argument doesn't exist, create a new Grupo with this data.
     */
    create: XOR<GrupoCreateInput, GrupoUncheckedCreateInput>
    /**
     * In case the Grupo was found with the provided `where` argument, update it with this data.
     */
    update: XOR<GrupoUpdateInput, GrupoUncheckedUpdateInput>
  }

  /**
   * Grupo delete
   */
  export type GrupoDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Grupo
     */
    select?: GrupoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Grupo
     */
    omit?: GrupoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: GrupoInclude<ExtArgs> | null
    /**
     * Filter which Grupo to delete.
     */
    where: GrupoWhereUniqueInput
  }

  /**
   * Grupo deleteMany
   */
  export type GrupoDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Grupos to delete
     */
    where?: GrupoWhereInput
    /**
     * Limit how many Grupos to delete.
     */
    limit?: number
  }

  /**
   * Grupo.estudiantes
   */
  export type Grupo$estudiantesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Estudiante
     */
    select?: EstudianteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Estudiante
     */
    omit?: EstudianteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EstudianteInclude<ExtArgs> | null
    where?: EstudianteWhereInput
    orderBy?: EstudianteOrderByWithRelationInput | EstudianteOrderByWithRelationInput[]
    cursor?: EstudianteWhereUniqueInput
    take?: number
    skip?: number
    distinct?: EstudianteScalarFieldEnum | EstudianteScalarFieldEnum[]
  }

  /**
   * Grupo.inscripciones
   */
  export type Grupo$inscripcionesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Inscripcion
     */
    select?: InscripcionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Inscripcion
     */
    omit?: InscripcionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InscripcionInclude<ExtArgs> | null
    where?: InscripcionWhereInput
    orderBy?: InscripcionOrderByWithRelationInput | InscripcionOrderByWithRelationInput[]
    cursor?: InscripcionWhereUniqueInput
    take?: number
    skip?: number
    distinct?: InscripcionScalarFieldEnum | InscripcionScalarFieldEnum[]
  }

  /**
   * Grupo.materiales
   */
  export type Grupo$materialesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MaterialEducativo
     */
    select?: MaterialEducativoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MaterialEducativo
     */
    omit?: MaterialEducativoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MaterialEducativoInclude<ExtArgs> | null
    where?: MaterialEducativoWhereInput
    orderBy?: MaterialEducativoOrderByWithRelationInput | MaterialEducativoOrderByWithRelationInput[]
    cursor?: MaterialEducativoWhereUniqueInput
    take?: number
    skip?: number
    distinct?: MaterialEducativoScalarFieldEnum | MaterialEducativoScalarFieldEnum[]
  }

  /**
   * Grupo without action
   */
  export type GrupoDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Grupo
     */
    select?: GrupoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Grupo
     */
    omit?: GrupoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: GrupoInclude<ExtArgs> | null
  }


  /**
   * Model Tramite
   */

  export type AggregateTramite = {
    _count: TramiteCountAggregateOutputType | null
    _avg: TramiteAvgAggregateOutputType | null
    _sum: TramiteSumAggregateOutputType | null
    _min: TramiteMinAggregateOutputType | null
    _max: TramiteMaxAggregateOutputType | null
  }

  export type TramiteAvgAggregateOutputType = {
    id: number | null
    estudianteId: number | null
  }

  export type TramiteSumAggregateOutputType = {
    id: number | null
    estudianteId: number | null
  }

  export type TramiteMinAggregateOutputType = {
    id: number | null
    estudianteId: number | null
    tipo: $Enums.TipoTramite | null
    estado: $Enums.EstadoTramite | null
    fecha: Date | null
  }

  export type TramiteMaxAggregateOutputType = {
    id: number | null
    estudianteId: number | null
    tipo: $Enums.TipoTramite | null
    estado: $Enums.EstadoTramite | null
    fecha: Date | null
  }

  export type TramiteCountAggregateOutputType = {
    id: number
    estudianteId: number
    tipo: number
    estado: number
    fecha: number
    _all: number
  }


  export type TramiteAvgAggregateInputType = {
    id?: true
    estudianteId?: true
  }

  export type TramiteSumAggregateInputType = {
    id?: true
    estudianteId?: true
  }

  export type TramiteMinAggregateInputType = {
    id?: true
    estudianteId?: true
    tipo?: true
    estado?: true
    fecha?: true
  }

  export type TramiteMaxAggregateInputType = {
    id?: true
    estudianteId?: true
    tipo?: true
    estado?: true
    fecha?: true
  }

  export type TramiteCountAggregateInputType = {
    id?: true
    estudianteId?: true
    tipo?: true
    estado?: true
    fecha?: true
    _all?: true
  }

  export type TramiteAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Tramite to aggregate.
     */
    where?: TramiteWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Tramites to fetch.
     */
    orderBy?: TramiteOrderByWithRelationInput | TramiteOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: TramiteWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Tramites from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Tramites.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Tramites
    **/
    _count?: true | TramiteCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: TramiteAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: TramiteSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: TramiteMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: TramiteMaxAggregateInputType
  }

  export type GetTramiteAggregateType<T extends TramiteAggregateArgs> = {
        [P in keyof T & keyof AggregateTramite]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateTramite[P]>
      : GetScalarType<T[P], AggregateTramite[P]>
  }




  export type TramiteGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: TramiteWhereInput
    orderBy?: TramiteOrderByWithAggregationInput | TramiteOrderByWithAggregationInput[]
    by: TramiteScalarFieldEnum[] | TramiteScalarFieldEnum
    having?: TramiteScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: TramiteCountAggregateInputType | true
    _avg?: TramiteAvgAggregateInputType
    _sum?: TramiteSumAggregateInputType
    _min?: TramiteMinAggregateInputType
    _max?: TramiteMaxAggregateInputType
  }

  export type TramiteGroupByOutputType = {
    id: number
    estudianteId: number
    tipo: $Enums.TipoTramite
    estado: $Enums.EstadoTramite
    fecha: Date
    _count: TramiteCountAggregateOutputType | null
    _avg: TramiteAvgAggregateOutputType | null
    _sum: TramiteSumAggregateOutputType | null
    _min: TramiteMinAggregateOutputType | null
    _max: TramiteMaxAggregateOutputType | null
  }

  type GetTramiteGroupByPayload<T extends TramiteGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<TramiteGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof TramiteGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], TramiteGroupByOutputType[P]>
            : GetScalarType<T[P], TramiteGroupByOutputType[P]>
        }
      >
    >


  export type TramiteSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    estudianteId?: boolean
    tipo?: boolean
    estado?: boolean
    fecha?: boolean
    inscripcion?: boolean | Tramite$inscripcionArgs<ExtArgs>
    Pago?: boolean | Tramite$PagoArgs<ExtArgs>
    estudiante?: boolean | EstudianteDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["tramite"]>



  export type TramiteSelectScalar = {
    id?: boolean
    estudianteId?: boolean
    tipo?: boolean
    estado?: boolean
    fecha?: boolean
  }

  export type TramiteOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "estudianteId" | "tipo" | "estado" | "fecha", ExtArgs["result"]["tramite"]>
  export type TramiteInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    inscripcion?: boolean | Tramite$inscripcionArgs<ExtArgs>
    Pago?: boolean | Tramite$PagoArgs<ExtArgs>
    estudiante?: boolean | EstudianteDefaultArgs<ExtArgs>
  }

  export type $TramitePayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Tramite"
    objects: {
      inscripcion: Prisma.$InscripcionPayload<ExtArgs> | null
      Pago: Prisma.$PagoPayload<ExtArgs> | null
      estudiante: Prisma.$EstudiantePayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      estudianteId: number
      tipo: $Enums.TipoTramite
      estado: $Enums.EstadoTramite
      fecha: Date
    }, ExtArgs["result"]["tramite"]>
    composites: {}
  }

  type TramiteGetPayload<S extends boolean | null | undefined | TramiteDefaultArgs> = $Result.GetResult<Prisma.$TramitePayload, S>

  type TramiteCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<TramiteFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: TramiteCountAggregateInputType | true
    }

  export interface TramiteDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Tramite'], meta: { name: 'Tramite' } }
    /**
     * Find zero or one Tramite that matches the filter.
     * @param {TramiteFindUniqueArgs} args - Arguments to find a Tramite
     * @example
     * // Get one Tramite
     * const tramite = await prisma.tramite.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends TramiteFindUniqueArgs>(args: SelectSubset<T, TramiteFindUniqueArgs<ExtArgs>>): Prisma__TramiteClient<$Result.GetResult<Prisma.$TramitePayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Tramite that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {TramiteFindUniqueOrThrowArgs} args - Arguments to find a Tramite
     * @example
     * // Get one Tramite
     * const tramite = await prisma.tramite.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends TramiteFindUniqueOrThrowArgs>(args: SelectSubset<T, TramiteFindUniqueOrThrowArgs<ExtArgs>>): Prisma__TramiteClient<$Result.GetResult<Prisma.$TramitePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Tramite that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TramiteFindFirstArgs} args - Arguments to find a Tramite
     * @example
     * // Get one Tramite
     * const tramite = await prisma.tramite.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends TramiteFindFirstArgs>(args?: SelectSubset<T, TramiteFindFirstArgs<ExtArgs>>): Prisma__TramiteClient<$Result.GetResult<Prisma.$TramitePayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Tramite that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TramiteFindFirstOrThrowArgs} args - Arguments to find a Tramite
     * @example
     * // Get one Tramite
     * const tramite = await prisma.tramite.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends TramiteFindFirstOrThrowArgs>(args?: SelectSubset<T, TramiteFindFirstOrThrowArgs<ExtArgs>>): Prisma__TramiteClient<$Result.GetResult<Prisma.$TramitePayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Tramites that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TramiteFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Tramites
     * const tramites = await prisma.tramite.findMany()
     * 
     * // Get first 10 Tramites
     * const tramites = await prisma.tramite.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const tramiteWithIdOnly = await prisma.tramite.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends TramiteFindManyArgs>(args?: SelectSubset<T, TramiteFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TramitePayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Tramite.
     * @param {TramiteCreateArgs} args - Arguments to create a Tramite.
     * @example
     * // Create one Tramite
     * const Tramite = await prisma.tramite.create({
     *   data: {
     *     // ... data to create a Tramite
     *   }
     * })
     * 
     */
    create<T extends TramiteCreateArgs>(args: SelectSubset<T, TramiteCreateArgs<ExtArgs>>): Prisma__TramiteClient<$Result.GetResult<Prisma.$TramitePayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Tramites.
     * @param {TramiteCreateManyArgs} args - Arguments to create many Tramites.
     * @example
     * // Create many Tramites
     * const tramite = await prisma.tramite.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends TramiteCreateManyArgs>(args?: SelectSubset<T, TramiteCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Tramite.
     * @param {TramiteDeleteArgs} args - Arguments to delete one Tramite.
     * @example
     * // Delete one Tramite
     * const Tramite = await prisma.tramite.delete({
     *   where: {
     *     // ... filter to delete one Tramite
     *   }
     * })
     * 
     */
    delete<T extends TramiteDeleteArgs>(args: SelectSubset<T, TramiteDeleteArgs<ExtArgs>>): Prisma__TramiteClient<$Result.GetResult<Prisma.$TramitePayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Tramite.
     * @param {TramiteUpdateArgs} args - Arguments to update one Tramite.
     * @example
     * // Update one Tramite
     * const tramite = await prisma.tramite.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends TramiteUpdateArgs>(args: SelectSubset<T, TramiteUpdateArgs<ExtArgs>>): Prisma__TramiteClient<$Result.GetResult<Prisma.$TramitePayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Tramites.
     * @param {TramiteDeleteManyArgs} args - Arguments to filter Tramites to delete.
     * @example
     * // Delete a few Tramites
     * const { count } = await prisma.tramite.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends TramiteDeleteManyArgs>(args?: SelectSubset<T, TramiteDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Tramites.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TramiteUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Tramites
     * const tramite = await prisma.tramite.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends TramiteUpdateManyArgs>(args: SelectSubset<T, TramiteUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Tramite.
     * @param {TramiteUpsertArgs} args - Arguments to update or create a Tramite.
     * @example
     * // Update or create a Tramite
     * const tramite = await prisma.tramite.upsert({
     *   create: {
     *     // ... data to create a Tramite
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Tramite we want to update
     *   }
     * })
     */
    upsert<T extends TramiteUpsertArgs>(args: SelectSubset<T, TramiteUpsertArgs<ExtArgs>>): Prisma__TramiteClient<$Result.GetResult<Prisma.$TramitePayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Tramites.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TramiteCountArgs} args - Arguments to filter Tramites to count.
     * @example
     * // Count the number of Tramites
     * const count = await prisma.tramite.count({
     *   where: {
     *     // ... the filter for the Tramites we want to count
     *   }
     * })
    **/
    count<T extends TramiteCountArgs>(
      args?: Subset<T, TramiteCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], TramiteCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Tramite.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TramiteAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends TramiteAggregateArgs>(args: Subset<T, TramiteAggregateArgs>): Prisma.PrismaPromise<GetTramiteAggregateType<T>>

    /**
     * Group by Tramite.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TramiteGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends TramiteGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: TramiteGroupByArgs['orderBy'] }
        : { orderBy?: TramiteGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, TramiteGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetTramiteGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Tramite model
   */
  readonly fields: TramiteFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Tramite.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__TramiteClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    inscripcion<T extends Tramite$inscripcionArgs<ExtArgs> = {}>(args?: Subset<T, Tramite$inscripcionArgs<ExtArgs>>): Prisma__InscripcionClient<$Result.GetResult<Prisma.$InscripcionPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    Pago<T extends Tramite$PagoArgs<ExtArgs> = {}>(args?: Subset<T, Tramite$PagoArgs<ExtArgs>>): Prisma__PagoClient<$Result.GetResult<Prisma.$PagoPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    estudiante<T extends EstudianteDefaultArgs<ExtArgs> = {}>(args?: Subset<T, EstudianteDefaultArgs<ExtArgs>>): Prisma__EstudianteClient<$Result.GetResult<Prisma.$EstudiantePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Tramite model
   */
  interface TramiteFieldRefs {
    readonly id: FieldRef<"Tramite", 'Int'>
    readonly estudianteId: FieldRef<"Tramite", 'Int'>
    readonly tipo: FieldRef<"Tramite", 'TipoTramite'>
    readonly estado: FieldRef<"Tramite", 'EstadoTramite'>
    readonly fecha: FieldRef<"Tramite", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Tramite findUnique
   */
  export type TramiteFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Tramite
     */
    select?: TramiteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Tramite
     */
    omit?: TramiteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TramiteInclude<ExtArgs> | null
    /**
     * Filter, which Tramite to fetch.
     */
    where: TramiteWhereUniqueInput
  }

  /**
   * Tramite findUniqueOrThrow
   */
  export type TramiteFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Tramite
     */
    select?: TramiteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Tramite
     */
    omit?: TramiteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TramiteInclude<ExtArgs> | null
    /**
     * Filter, which Tramite to fetch.
     */
    where: TramiteWhereUniqueInput
  }

  /**
   * Tramite findFirst
   */
  export type TramiteFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Tramite
     */
    select?: TramiteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Tramite
     */
    omit?: TramiteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TramiteInclude<ExtArgs> | null
    /**
     * Filter, which Tramite to fetch.
     */
    where?: TramiteWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Tramites to fetch.
     */
    orderBy?: TramiteOrderByWithRelationInput | TramiteOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Tramites.
     */
    cursor?: TramiteWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Tramites from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Tramites.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Tramites.
     */
    distinct?: TramiteScalarFieldEnum | TramiteScalarFieldEnum[]
  }

  /**
   * Tramite findFirstOrThrow
   */
  export type TramiteFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Tramite
     */
    select?: TramiteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Tramite
     */
    omit?: TramiteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TramiteInclude<ExtArgs> | null
    /**
     * Filter, which Tramite to fetch.
     */
    where?: TramiteWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Tramites to fetch.
     */
    orderBy?: TramiteOrderByWithRelationInput | TramiteOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Tramites.
     */
    cursor?: TramiteWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Tramites from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Tramites.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Tramites.
     */
    distinct?: TramiteScalarFieldEnum | TramiteScalarFieldEnum[]
  }

  /**
   * Tramite findMany
   */
  export type TramiteFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Tramite
     */
    select?: TramiteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Tramite
     */
    omit?: TramiteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TramiteInclude<ExtArgs> | null
    /**
     * Filter, which Tramites to fetch.
     */
    where?: TramiteWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Tramites to fetch.
     */
    orderBy?: TramiteOrderByWithRelationInput | TramiteOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Tramites.
     */
    cursor?: TramiteWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Tramites from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Tramites.
     */
    skip?: number
    distinct?: TramiteScalarFieldEnum | TramiteScalarFieldEnum[]
  }

  /**
   * Tramite create
   */
  export type TramiteCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Tramite
     */
    select?: TramiteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Tramite
     */
    omit?: TramiteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TramiteInclude<ExtArgs> | null
    /**
     * The data needed to create a Tramite.
     */
    data: XOR<TramiteCreateInput, TramiteUncheckedCreateInput>
  }

  /**
   * Tramite createMany
   */
  export type TramiteCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Tramites.
     */
    data: TramiteCreateManyInput | TramiteCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Tramite update
   */
  export type TramiteUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Tramite
     */
    select?: TramiteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Tramite
     */
    omit?: TramiteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TramiteInclude<ExtArgs> | null
    /**
     * The data needed to update a Tramite.
     */
    data: XOR<TramiteUpdateInput, TramiteUncheckedUpdateInput>
    /**
     * Choose, which Tramite to update.
     */
    where: TramiteWhereUniqueInput
  }

  /**
   * Tramite updateMany
   */
  export type TramiteUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Tramites.
     */
    data: XOR<TramiteUpdateManyMutationInput, TramiteUncheckedUpdateManyInput>
    /**
     * Filter which Tramites to update
     */
    where?: TramiteWhereInput
    /**
     * Limit how many Tramites to update.
     */
    limit?: number
  }

  /**
   * Tramite upsert
   */
  export type TramiteUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Tramite
     */
    select?: TramiteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Tramite
     */
    omit?: TramiteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TramiteInclude<ExtArgs> | null
    /**
     * The filter to search for the Tramite to update in case it exists.
     */
    where: TramiteWhereUniqueInput
    /**
     * In case the Tramite found by the `where` argument doesn't exist, create a new Tramite with this data.
     */
    create: XOR<TramiteCreateInput, TramiteUncheckedCreateInput>
    /**
     * In case the Tramite was found with the provided `where` argument, update it with this data.
     */
    update: XOR<TramiteUpdateInput, TramiteUncheckedUpdateInput>
  }

  /**
   * Tramite delete
   */
  export type TramiteDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Tramite
     */
    select?: TramiteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Tramite
     */
    omit?: TramiteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TramiteInclude<ExtArgs> | null
    /**
     * Filter which Tramite to delete.
     */
    where: TramiteWhereUniqueInput
  }

  /**
   * Tramite deleteMany
   */
  export type TramiteDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Tramites to delete
     */
    where?: TramiteWhereInput
    /**
     * Limit how many Tramites to delete.
     */
    limit?: number
  }

  /**
   * Tramite.inscripcion
   */
  export type Tramite$inscripcionArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Inscripcion
     */
    select?: InscripcionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Inscripcion
     */
    omit?: InscripcionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InscripcionInclude<ExtArgs> | null
    where?: InscripcionWhereInput
  }

  /**
   * Tramite.Pago
   */
  export type Tramite$PagoArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Pago
     */
    select?: PagoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Pago
     */
    omit?: PagoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PagoInclude<ExtArgs> | null
    where?: PagoWhereInput
  }

  /**
   * Tramite without action
   */
  export type TramiteDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Tramite
     */
    select?: TramiteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Tramite
     */
    omit?: TramiteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TramiteInclude<ExtArgs> | null
  }


  /**
   * Model Inscripcion
   */

  export type AggregateInscripcion = {
    _count: InscripcionCountAggregateOutputType | null
    _avg: InscripcionAvgAggregateOutputType | null
    _sum: InscripcionSumAggregateOutputType | null
    _min: InscripcionMinAggregateOutputType | null
    _max: InscripcionMaxAggregateOutputType | null
  }

  export type InscripcionAvgAggregateOutputType = {
    tramiteId: number | null
    grupoId: number | null
  }

  export type InscripcionSumAggregateOutputType = {
    tramiteId: number | null
    grupoId: number | null
  }

  export type InscripcionMinAggregateOutputType = {
    tramiteId: number | null
    grupoId: number | null
  }

  export type InscripcionMaxAggregateOutputType = {
    tramiteId: number | null
    grupoId: number | null
  }

  export type InscripcionCountAggregateOutputType = {
    tramiteId: number
    grupoId: number
    _all: number
  }


  export type InscripcionAvgAggregateInputType = {
    tramiteId?: true
    grupoId?: true
  }

  export type InscripcionSumAggregateInputType = {
    tramiteId?: true
    grupoId?: true
  }

  export type InscripcionMinAggregateInputType = {
    tramiteId?: true
    grupoId?: true
  }

  export type InscripcionMaxAggregateInputType = {
    tramiteId?: true
    grupoId?: true
  }

  export type InscripcionCountAggregateInputType = {
    tramiteId?: true
    grupoId?: true
    _all?: true
  }

  export type InscripcionAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Inscripcion to aggregate.
     */
    where?: InscripcionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Inscripcions to fetch.
     */
    orderBy?: InscripcionOrderByWithRelationInput | InscripcionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: InscripcionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Inscripcions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Inscripcions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Inscripcions
    **/
    _count?: true | InscripcionCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: InscripcionAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: InscripcionSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: InscripcionMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: InscripcionMaxAggregateInputType
  }

  export type GetInscripcionAggregateType<T extends InscripcionAggregateArgs> = {
        [P in keyof T & keyof AggregateInscripcion]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateInscripcion[P]>
      : GetScalarType<T[P], AggregateInscripcion[P]>
  }




  export type InscripcionGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: InscripcionWhereInput
    orderBy?: InscripcionOrderByWithAggregationInput | InscripcionOrderByWithAggregationInput[]
    by: InscripcionScalarFieldEnum[] | InscripcionScalarFieldEnum
    having?: InscripcionScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: InscripcionCountAggregateInputType | true
    _avg?: InscripcionAvgAggregateInputType
    _sum?: InscripcionSumAggregateInputType
    _min?: InscripcionMinAggregateInputType
    _max?: InscripcionMaxAggregateInputType
  }

  export type InscripcionGroupByOutputType = {
    tramiteId: number
    grupoId: number
    _count: InscripcionCountAggregateOutputType | null
    _avg: InscripcionAvgAggregateOutputType | null
    _sum: InscripcionSumAggregateOutputType | null
    _min: InscripcionMinAggregateOutputType | null
    _max: InscripcionMaxAggregateOutputType | null
  }

  type GetInscripcionGroupByPayload<T extends InscripcionGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<InscripcionGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof InscripcionGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], InscripcionGroupByOutputType[P]>
            : GetScalarType<T[P], InscripcionGroupByOutputType[P]>
        }
      >
    >


  export type InscripcionSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    tramiteId?: boolean
    grupoId?: boolean
    tramite?: boolean | TramiteDefaultArgs<ExtArgs>
    grupo?: boolean | GrupoDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["inscripcion"]>



  export type InscripcionSelectScalar = {
    tramiteId?: boolean
    grupoId?: boolean
  }

  export type InscripcionOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"tramiteId" | "grupoId", ExtArgs["result"]["inscripcion"]>
  export type InscripcionInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    tramite?: boolean | TramiteDefaultArgs<ExtArgs>
    grupo?: boolean | GrupoDefaultArgs<ExtArgs>
  }

  export type $InscripcionPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Inscripcion"
    objects: {
      tramite: Prisma.$TramitePayload<ExtArgs>
      grupo: Prisma.$GrupoPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      tramiteId: number
      grupoId: number
    }, ExtArgs["result"]["inscripcion"]>
    composites: {}
  }

  type InscripcionGetPayload<S extends boolean | null | undefined | InscripcionDefaultArgs> = $Result.GetResult<Prisma.$InscripcionPayload, S>

  type InscripcionCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<InscripcionFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: InscripcionCountAggregateInputType | true
    }

  export interface InscripcionDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Inscripcion'], meta: { name: 'Inscripcion' } }
    /**
     * Find zero or one Inscripcion that matches the filter.
     * @param {InscripcionFindUniqueArgs} args - Arguments to find a Inscripcion
     * @example
     * // Get one Inscripcion
     * const inscripcion = await prisma.inscripcion.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends InscripcionFindUniqueArgs>(args: SelectSubset<T, InscripcionFindUniqueArgs<ExtArgs>>): Prisma__InscripcionClient<$Result.GetResult<Prisma.$InscripcionPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Inscripcion that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {InscripcionFindUniqueOrThrowArgs} args - Arguments to find a Inscripcion
     * @example
     * // Get one Inscripcion
     * const inscripcion = await prisma.inscripcion.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends InscripcionFindUniqueOrThrowArgs>(args: SelectSubset<T, InscripcionFindUniqueOrThrowArgs<ExtArgs>>): Prisma__InscripcionClient<$Result.GetResult<Prisma.$InscripcionPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Inscripcion that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {InscripcionFindFirstArgs} args - Arguments to find a Inscripcion
     * @example
     * // Get one Inscripcion
     * const inscripcion = await prisma.inscripcion.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends InscripcionFindFirstArgs>(args?: SelectSubset<T, InscripcionFindFirstArgs<ExtArgs>>): Prisma__InscripcionClient<$Result.GetResult<Prisma.$InscripcionPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Inscripcion that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {InscripcionFindFirstOrThrowArgs} args - Arguments to find a Inscripcion
     * @example
     * // Get one Inscripcion
     * const inscripcion = await prisma.inscripcion.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends InscripcionFindFirstOrThrowArgs>(args?: SelectSubset<T, InscripcionFindFirstOrThrowArgs<ExtArgs>>): Prisma__InscripcionClient<$Result.GetResult<Prisma.$InscripcionPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Inscripcions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {InscripcionFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Inscripcions
     * const inscripcions = await prisma.inscripcion.findMany()
     * 
     * // Get first 10 Inscripcions
     * const inscripcions = await prisma.inscripcion.findMany({ take: 10 })
     * 
     * // Only select the `tramiteId`
     * const inscripcionWithTramiteIdOnly = await prisma.inscripcion.findMany({ select: { tramiteId: true } })
     * 
     */
    findMany<T extends InscripcionFindManyArgs>(args?: SelectSubset<T, InscripcionFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$InscripcionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Inscripcion.
     * @param {InscripcionCreateArgs} args - Arguments to create a Inscripcion.
     * @example
     * // Create one Inscripcion
     * const Inscripcion = await prisma.inscripcion.create({
     *   data: {
     *     // ... data to create a Inscripcion
     *   }
     * })
     * 
     */
    create<T extends InscripcionCreateArgs>(args: SelectSubset<T, InscripcionCreateArgs<ExtArgs>>): Prisma__InscripcionClient<$Result.GetResult<Prisma.$InscripcionPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Inscripcions.
     * @param {InscripcionCreateManyArgs} args - Arguments to create many Inscripcions.
     * @example
     * // Create many Inscripcions
     * const inscripcion = await prisma.inscripcion.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends InscripcionCreateManyArgs>(args?: SelectSubset<T, InscripcionCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Inscripcion.
     * @param {InscripcionDeleteArgs} args - Arguments to delete one Inscripcion.
     * @example
     * // Delete one Inscripcion
     * const Inscripcion = await prisma.inscripcion.delete({
     *   where: {
     *     // ... filter to delete one Inscripcion
     *   }
     * })
     * 
     */
    delete<T extends InscripcionDeleteArgs>(args: SelectSubset<T, InscripcionDeleteArgs<ExtArgs>>): Prisma__InscripcionClient<$Result.GetResult<Prisma.$InscripcionPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Inscripcion.
     * @param {InscripcionUpdateArgs} args - Arguments to update one Inscripcion.
     * @example
     * // Update one Inscripcion
     * const inscripcion = await prisma.inscripcion.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends InscripcionUpdateArgs>(args: SelectSubset<T, InscripcionUpdateArgs<ExtArgs>>): Prisma__InscripcionClient<$Result.GetResult<Prisma.$InscripcionPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Inscripcions.
     * @param {InscripcionDeleteManyArgs} args - Arguments to filter Inscripcions to delete.
     * @example
     * // Delete a few Inscripcions
     * const { count } = await prisma.inscripcion.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends InscripcionDeleteManyArgs>(args?: SelectSubset<T, InscripcionDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Inscripcions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {InscripcionUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Inscripcions
     * const inscripcion = await prisma.inscripcion.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends InscripcionUpdateManyArgs>(args: SelectSubset<T, InscripcionUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Inscripcion.
     * @param {InscripcionUpsertArgs} args - Arguments to update or create a Inscripcion.
     * @example
     * // Update or create a Inscripcion
     * const inscripcion = await prisma.inscripcion.upsert({
     *   create: {
     *     // ... data to create a Inscripcion
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Inscripcion we want to update
     *   }
     * })
     */
    upsert<T extends InscripcionUpsertArgs>(args: SelectSubset<T, InscripcionUpsertArgs<ExtArgs>>): Prisma__InscripcionClient<$Result.GetResult<Prisma.$InscripcionPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Inscripcions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {InscripcionCountArgs} args - Arguments to filter Inscripcions to count.
     * @example
     * // Count the number of Inscripcions
     * const count = await prisma.inscripcion.count({
     *   where: {
     *     // ... the filter for the Inscripcions we want to count
     *   }
     * })
    **/
    count<T extends InscripcionCountArgs>(
      args?: Subset<T, InscripcionCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], InscripcionCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Inscripcion.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {InscripcionAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends InscripcionAggregateArgs>(args: Subset<T, InscripcionAggregateArgs>): Prisma.PrismaPromise<GetInscripcionAggregateType<T>>

    /**
     * Group by Inscripcion.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {InscripcionGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends InscripcionGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: InscripcionGroupByArgs['orderBy'] }
        : { orderBy?: InscripcionGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, InscripcionGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetInscripcionGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Inscripcion model
   */
  readonly fields: InscripcionFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Inscripcion.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__InscripcionClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    tramite<T extends TramiteDefaultArgs<ExtArgs> = {}>(args?: Subset<T, TramiteDefaultArgs<ExtArgs>>): Prisma__TramiteClient<$Result.GetResult<Prisma.$TramitePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    grupo<T extends GrupoDefaultArgs<ExtArgs> = {}>(args?: Subset<T, GrupoDefaultArgs<ExtArgs>>): Prisma__GrupoClient<$Result.GetResult<Prisma.$GrupoPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Inscripcion model
   */
  interface InscripcionFieldRefs {
    readonly tramiteId: FieldRef<"Inscripcion", 'Int'>
    readonly grupoId: FieldRef<"Inscripcion", 'Int'>
  }
    

  // Custom InputTypes
  /**
   * Inscripcion findUnique
   */
  export type InscripcionFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Inscripcion
     */
    select?: InscripcionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Inscripcion
     */
    omit?: InscripcionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InscripcionInclude<ExtArgs> | null
    /**
     * Filter, which Inscripcion to fetch.
     */
    where: InscripcionWhereUniqueInput
  }

  /**
   * Inscripcion findUniqueOrThrow
   */
  export type InscripcionFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Inscripcion
     */
    select?: InscripcionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Inscripcion
     */
    omit?: InscripcionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InscripcionInclude<ExtArgs> | null
    /**
     * Filter, which Inscripcion to fetch.
     */
    where: InscripcionWhereUniqueInput
  }

  /**
   * Inscripcion findFirst
   */
  export type InscripcionFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Inscripcion
     */
    select?: InscripcionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Inscripcion
     */
    omit?: InscripcionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InscripcionInclude<ExtArgs> | null
    /**
     * Filter, which Inscripcion to fetch.
     */
    where?: InscripcionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Inscripcions to fetch.
     */
    orderBy?: InscripcionOrderByWithRelationInput | InscripcionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Inscripcions.
     */
    cursor?: InscripcionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Inscripcions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Inscripcions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Inscripcions.
     */
    distinct?: InscripcionScalarFieldEnum | InscripcionScalarFieldEnum[]
  }

  /**
   * Inscripcion findFirstOrThrow
   */
  export type InscripcionFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Inscripcion
     */
    select?: InscripcionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Inscripcion
     */
    omit?: InscripcionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InscripcionInclude<ExtArgs> | null
    /**
     * Filter, which Inscripcion to fetch.
     */
    where?: InscripcionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Inscripcions to fetch.
     */
    orderBy?: InscripcionOrderByWithRelationInput | InscripcionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Inscripcions.
     */
    cursor?: InscripcionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Inscripcions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Inscripcions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Inscripcions.
     */
    distinct?: InscripcionScalarFieldEnum | InscripcionScalarFieldEnum[]
  }

  /**
   * Inscripcion findMany
   */
  export type InscripcionFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Inscripcion
     */
    select?: InscripcionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Inscripcion
     */
    omit?: InscripcionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InscripcionInclude<ExtArgs> | null
    /**
     * Filter, which Inscripcions to fetch.
     */
    where?: InscripcionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Inscripcions to fetch.
     */
    orderBy?: InscripcionOrderByWithRelationInput | InscripcionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Inscripcions.
     */
    cursor?: InscripcionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Inscripcions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Inscripcions.
     */
    skip?: number
    distinct?: InscripcionScalarFieldEnum | InscripcionScalarFieldEnum[]
  }

  /**
   * Inscripcion create
   */
  export type InscripcionCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Inscripcion
     */
    select?: InscripcionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Inscripcion
     */
    omit?: InscripcionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InscripcionInclude<ExtArgs> | null
    /**
     * The data needed to create a Inscripcion.
     */
    data: XOR<InscripcionCreateInput, InscripcionUncheckedCreateInput>
  }

  /**
   * Inscripcion createMany
   */
  export type InscripcionCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Inscripcions.
     */
    data: InscripcionCreateManyInput | InscripcionCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Inscripcion update
   */
  export type InscripcionUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Inscripcion
     */
    select?: InscripcionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Inscripcion
     */
    omit?: InscripcionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InscripcionInclude<ExtArgs> | null
    /**
     * The data needed to update a Inscripcion.
     */
    data: XOR<InscripcionUpdateInput, InscripcionUncheckedUpdateInput>
    /**
     * Choose, which Inscripcion to update.
     */
    where: InscripcionWhereUniqueInput
  }

  /**
   * Inscripcion updateMany
   */
  export type InscripcionUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Inscripcions.
     */
    data: XOR<InscripcionUpdateManyMutationInput, InscripcionUncheckedUpdateManyInput>
    /**
     * Filter which Inscripcions to update
     */
    where?: InscripcionWhereInput
    /**
     * Limit how many Inscripcions to update.
     */
    limit?: number
  }

  /**
   * Inscripcion upsert
   */
  export type InscripcionUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Inscripcion
     */
    select?: InscripcionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Inscripcion
     */
    omit?: InscripcionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InscripcionInclude<ExtArgs> | null
    /**
     * The filter to search for the Inscripcion to update in case it exists.
     */
    where: InscripcionWhereUniqueInput
    /**
     * In case the Inscripcion found by the `where` argument doesn't exist, create a new Inscripcion with this data.
     */
    create: XOR<InscripcionCreateInput, InscripcionUncheckedCreateInput>
    /**
     * In case the Inscripcion was found with the provided `where` argument, update it with this data.
     */
    update: XOR<InscripcionUpdateInput, InscripcionUncheckedUpdateInput>
  }

  /**
   * Inscripcion delete
   */
  export type InscripcionDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Inscripcion
     */
    select?: InscripcionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Inscripcion
     */
    omit?: InscripcionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InscripcionInclude<ExtArgs> | null
    /**
     * Filter which Inscripcion to delete.
     */
    where: InscripcionWhereUniqueInput
  }

  /**
   * Inscripcion deleteMany
   */
  export type InscripcionDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Inscripcions to delete
     */
    where?: InscripcionWhereInput
    /**
     * Limit how many Inscripcions to delete.
     */
    limit?: number
  }

  /**
   * Inscripcion without action
   */
  export type InscripcionDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Inscripcion
     */
    select?: InscripcionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Inscripcion
     */
    omit?: InscripcionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InscripcionInclude<ExtArgs> | null
  }


  /**
   * Model Pago
   */

  export type AggregatePago = {
    _count: PagoCountAggregateOutputType | null
    _avg: PagoAvgAggregateOutputType | null
    _sum: PagoSumAggregateOutputType | null
    _min: PagoMinAggregateOutputType | null
    _max: PagoMaxAggregateOutputType | null
  }

  export type PagoAvgAggregateOutputType = {
    tramiteId: number | null
    monto: number | null
  }

  export type PagoSumAggregateOutputType = {
    tramiteId: number | null
    monto: number | null
  }

  export type PagoMinAggregateOutputType = {
    tramiteId: number | null
    concepto: string | null
    monto: number | null
  }

  export type PagoMaxAggregateOutputType = {
    tramiteId: number | null
    concepto: string | null
    monto: number | null
  }

  export type PagoCountAggregateOutputType = {
    tramiteId: number
    concepto: number
    monto: number
    _all: number
  }


  export type PagoAvgAggregateInputType = {
    tramiteId?: true
    monto?: true
  }

  export type PagoSumAggregateInputType = {
    tramiteId?: true
    monto?: true
  }

  export type PagoMinAggregateInputType = {
    tramiteId?: true
    concepto?: true
    monto?: true
  }

  export type PagoMaxAggregateInputType = {
    tramiteId?: true
    concepto?: true
    monto?: true
  }

  export type PagoCountAggregateInputType = {
    tramiteId?: true
    concepto?: true
    monto?: true
    _all?: true
  }

  export type PagoAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Pago to aggregate.
     */
    where?: PagoWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Pagos to fetch.
     */
    orderBy?: PagoOrderByWithRelationInput | PagoOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: PagoWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Pagos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Pagos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Pagos
    **/
    _count?: true | PagoCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: PagoAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: PagoSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: PagoMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: PagoMaxAggregateInputType
  }

  export type GetPagoAggregateType<T extends PagoAggregateArgs> = {
        [P in keyof T & keyof AggregatePago]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregatePago[P]>
      : GetScalarType<T[P], AggregatePago[P]>
  }




  export type PagoGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PagoWhereInput
    orderBy?: PagoOrderByWithAggregationInput | PagoOrderByWithAggregationInput[]
    by: PagoScalarFieldEnum[] | PagoScalarFieldEnum
    having?: PagoScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: PagoCountAggregateInputType | true
    _avg?: PagoAvgAggregateInputType
    _sum?: PagoSumAggregateInputType
    _min?: PagoMinAggregateInputType
    _max?: PagoMaxAggregateInputType
  }

  export type PagoGroupByOutputType = {
    tramiteId: number
    concepto: string
    monto: number
    _count: PagoCountAggregateOutputType | null
    _avg: PagoAvgAggregateOutputType | null
    _sum: PagoSumAggregateOutputType | null
    _min: PagoMinAggregateOutputType | null
    _max: PagoMaxAggregateOutputType | null
  }

  type GetPagoGroupByPayload<T extends PagoGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<PagoGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof PagoGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], PagoGroupByOutputType[P]>
            : GetScalarType<T[P], PagoGroupByOutputType[P]>
        }
      >
    >


  export type PagoSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    tramiteId?: boolean
    concepto?: boolean
    monto?: boolean
    recibos?: boolean | Pago$recibosArgs<ExtArgs>
    tramite?: boolean | TramiteDefaultArgs<ExtArgs>
    _count?: boolean | PagoCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["pago"]>



  export type PagoSelectScalar = {
    tramiteId?: boolean
    concepto?: boolean
    monto?: boolean
  }

  export type PagoOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"tramiteId" | "concepto" | "monto", ExtArgs["result"]["pago"]>
  export type PagoInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    recibos?: boolean | Pago$recibosArgs<ExtArgs>
    tramite?: boolean | TramiteDefaultArgs<ExtArgs>
    _count?: boolean | PagoCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $PagoPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Pago"
    objects: {
      recibos: Prisma.$ReciboPayload<ExtArgs>[]
      tramite: Prisma.$TramitePayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      tramiteId: number
      concepto: string
      monto: number
    }, ExtArgs["result"]["pago"]>
    composites: {}
  }

  type PagoGetPayload<S extends boolean | null | undefined | PagoDefaultArgs> = $Result.GetResult<Prisma.$PagoPayload, S>

  type PagoCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<PagoFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: PagoCountAggregateInputType | true
    }

  export interface PagoDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Pago'], meta: { name: 'Pago' } }
    /**
     * Find zero or one Pago that matches the filter.
     * @param {PagoFindUniqueArgs} args - Arguments to find a Pago
     * @example
     * // Get one Pago
     * const pago = await prisma.pago.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends PagoFindUniqueArgs>(args: SelectSubset<T, PagoFindUniqueArgs<ExtArgs>>): Prisma__PagoClient<$Result.GetResult<Prisma.$PagoPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Pago that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {PagoFindUniqueOrThrowArgs} args - Arguments to find a Pago
     * @example
     * // Get one Pago
     * const pago = await prisma.pago.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends PagoFindUniqueOrThrowArgs>(args: SelectSubset<T, PagoFindUniqueOrThrowArgs<ExtArgs>>): Prisma__PagoClient<$Result.GetResult<Prisma.$PagoPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Pago that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PagoFindFirstArgs} args - Arguments to find a Pago
     * @example
     * // Get one Pago
     * const pago = await prisma.pago.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends PagoFindFirstArgs>(args?: SelectSubset<T, PagoFindFirstArgs<ExtArgs>>): Prisma__PagoClient<$Result.GetResult<Prisma.$PagoPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Pago that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PagoFindFirstOrThrowArgs} args - Arguments to find a Pago
     * @example
     * // Get one Pago
     * const pago = await prisma.pago.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends PagoFindFirstOrThrowArgs>(args?: SelectSubset<T, PagoFindFirstOrThrowArgs<ExtArgs>>): Prisma__PagoClient<$Result.GetResult<Prisma.$PagoPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Pagos that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PagoFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Pagos
     * const pagos = await prisma.pago.findMany()
     * 
     * // Get first 10 Pagos
     * const pagos = await prisma.pago.findMany({ take: 10 })
     * 
     * // Only select the `tramiteId`
     * const pagoWithTramiteIdOnly = await prisma.pago.findMany({ select: { tramiteId: true } })
     * 
     */
    findMany<T extends PagoFindManyArgs>(args?: SelectSubset<T, PagoFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PagoPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Pago.
     * @param {PagoCreateArgs} args - Arguments to create a Pago.
     * @example
     * // Create one Pago
     * const Pago = await prisma.pago.create({
     *   data: {
     *     // ... data to create a Pago
     *   }
     * })
     * 
     */
    create<T extends PagoCreateArgs>(args: SelectSubset<T, PagoCreateArgs<ExtArgs>>): Prisma__PagoClient<$Result.GetResult<Prisma.$PagoPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Pagos.
     * @param {PagoCreateManyArgs} args - Arguments to create many Pagos.
     * @example
     * // Create many Pagos
     * const pago = await prisma.pago.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends PagoCreateManyArgs>(args?: SelectSubset<T, PagoCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Pago.
     * @param {PagoDeleteArgs} args - Arguments to delete one Pago.
     * @example
     * // Delete one Pago
     * const Pago = await prisma.pago.delete({
     *   where: {
     *     // ... filter to delete one Pago
     *   }
     * })
     * 
     */
    delete<T extends PagoDeleteArgs>(args: SelectSubset<T, PagoDeleteArgs<ExtArgs>>): Prisma__PagoClient<$Result.GetResult<Prisma.$PagoPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Pago.
     * @param {PagoUpdateArgs} args - Arguments to update one Pago.
     * @example
     * // Update one Pago
     * const pago = await prisma.pago.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends PagoUpdateArgs>(args: SelectSubset<T, PagoUpdateArgs<ExtArgs>>): Prisma__PagoClient<$Result.GetResult<Prisma.$PagoPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Pagos.
     * @param {PagoDeleteManyArgs} args - Arguments to filter Pagos to delete.
     * @example
     * // Delete a few Pagos
     * const { count } = await prisma.pago.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends PagoDeleteManyArgs>(args?: SelectSubset<T, PagoDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Pagos.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PagoUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Pagos
     * const pago = await prisma.pago.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends PagoUpdateManyArgs>(args: SelectSubset<T, PagoUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Pago.
     * @param {PagoUpsertArgs} args - Arguments to update or create a Pago.
     * @example
     * // Update or create a Pago
     * const pago = await prisma.pago.upsert({
     *   create: {
     *     // ... data to create a Pago
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Pago we want to update
     *   }
     * })
     */
    upsert<T extends PagoUpsertArgs>(args: SelectSubset<T, PagoUpsertArgs<ExtArgs>>): Prisma__PagoClient<$Result.GetResult<Prisma.$PagoPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Pagos.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PagoCountArgs} args - Arguments to filter Pagos to count.
     * @example
     * // Count the number of Pagos
     * const count = await prisma.pago.count({
     *   where: {
     *     // ... the filter for the Pagos we want to count
     *   }
     * })
    **/
    count<T extends PagoCountArgs>(
      args?: Subset<T, PagoCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], PagoCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Pago.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PagoAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends PagoAggregateArgs>(args: Subset<T, PagoAggregateArgs>): Prisma.PrismaPromise<GetPagoAggregateType<T>>

    /**
     * Group by Pago.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PagoGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends PagoGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: PagoGroupByArgs['orderBy'] }
        : { orderBy?: PagoGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, PagoGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetPagoGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Pago model
   */
  readonly fields: PagoFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Pago.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__PagoClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    recibos<T extends Pago$recibosArgs<ExtArgs> = {}>(args?: Subset<T, Pago$recibosArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ReciboPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    tramite<T extends TramiteDefaultArgs<ExtArgs> = {}>(args?: Subset<T, TramiteDefaultArgs<ExtArgs>>): Prisma__TramiteClient<$Result.GetResult<Prisma.$TramitePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Pago model
   */
  interface PagoFieldRefs {
    readonly tramiteId: FieldRef<"Pago", 'Int'>
    readonly concepto: FieldRef<"Pago", 'String'>
    readonly monto: FieldRef<"Pago", 'Float'>
  }
    

  // Custom InputTypes
  /**
   * Pago findUnique
   */
  export type PagoFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Pago
     */
    select?: PagoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Pago
     */
    omit?: PagoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PagoInclude<ExtArgs> | null
    /**
     * Filter, which Pago to fetch.
     */
    where: PagoWhereUniqueInput
  }

  /**
   * Pago findUniqueOrThrow
   */
  export type PagoFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Pago
     */
    select?: PagoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Pago
     */
    omit?: PagoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PagoInclude<ExtArgs> | null
    /**
     * Filter, which Pago to fetch.
     */
    where: PagoWhereUniqueInput
  }

  /**
   * Pago findFirst
   */
  export type PagoFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Pago
     */
    select?: PagoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Pago
     */
    omit?: PagoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PagoInclude<ExtArgs> | null
    /**
     * Filter, which Pago to fetch.
     */
    where?: PagoWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Pagos to fetch.
     */
    orderBy?: PagoOrderByWithRelationInput | PagoOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Pagos.
     */
    cursor?: PagoWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Pagos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Pagos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Pagos.
     */
    distinct?: PagoScalarFieldEnum | PagoScalarFieldEnum[]
  }

  /**
   * Pago findFirstOrThrow
   */
  export type PagoFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Pago
     */
    select?: PagoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Pago
     */
    omit?: PagoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PagoInclude<ExtArgs> | null
    /**
     * Filter, which Pago to fetch.
     */
    where?: PagoWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Pagos to fetch.
     */
    orderBy?: PagoOrderByWithRelationInput | PagoOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Pagos.
     */
    cursor?: PagoWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Pagos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Pagos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Pagos.
     */
    distinct?: PagoScalarFieldEnum | PagoScalarFieldEnum[]
  }

  /**
   * Pago findMany
   */
  export type PagoFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Pago
     */
    select?: PagoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Pago
     */
    omit?: PagoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PagoInclude<ExtArgs> | null
    /**
     * Filter, which Pagos to fetch.
     */
    where?: PagoWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Pagos to fetch.
     */
    orderBy?: PagoOrderByWithRelationInput | PagoOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Pagos.
     */
    cursor?: PagoWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Pagos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Pagos.
     */
    skip?: number
    distinct?: PagoScalarFieldEnum | PagoScalarFieldEnum[]
  }

  /**
   * Pago create
   */
  export type PagoCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Pago
     */
    select?: PagoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Pago
     */
    omit?: PagoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PagoInclude<ExtArgs> | null
    /**
     * The data needed to create a Pago.
     */
    data: XOR<PagoCreateInput, PagoUncheckedCreateInput>
  }

  /**
   * Pago createMany
   */
  export type PagoCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Pagos.
     */
    data: PagoCreateManyInput | PagoCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Pago update
   */
  export type PagoUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Pago
     */
    select?: PagoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Pago
     */
    omit?: PagoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PagoInclude<ExtArgs> | null
    /**
     * The data needed to update a Pago.
     */
    data: XOR<PagoUpdateInput, PagoUncheckedUpdateInput>
    /**
     * Choose, which Pago to update.
     */
    where: PagoWhereUniqueInput
  }

  /**
   * Pago updateMany
   */
  export type PagoUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Pagos.
     */
    data: XOR<PagoUpdateManyMutationInput, PagoUncheckedUpdateManyInput>
    /**
     * Filter which Pagos to update
     */
    where?: PagoWhereInput
    /**
     * Limit how many Pagos to update.
     */
    limit?: number
  }

  /**
   * Pago upsert
   */
  export type PagoUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Pago
     */
    select?: PagoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Pago
     */
    omit?: PagoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PagoInclude<ExtArgs> | null
    /**
     * The filter to search for the Pago to update in case it exists.
     */
    where: PagoWhereUniqueInput
    /**
     * In case the Pago found by the `where` argument doesn't exist, create a new Pago with this data.
     */
    create: XOR<PagoCreateInput, PagoUncheckedCreateInput>
    /**
     * In case the Pago was found with the provided `where` argument, update it with this data.
     */
    update: XOR<PagoUpdateInput, PagoUncheckedUpdateInput>
  }

  /**
   * Pago delete
   */
  export type PagoDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Pago
     */
    select?: PagoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Pago
     */
    omit?: PagoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PagoInclude<ExtArgs> | null
    /**
     * Filter which Pago to delete.
     */
    where: PagoWhereUniqueInput
  }

  /**
   * Pago deleteMany
   */
  export type PagoDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Pagos to delete
     */
    where?: PagoWhereInput
    /**
     * Limit how many Pagos to delete.
     */
    limit?: number
  }

  /**
   * Pago.recibos
   */
  export type Pago$recibosArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Recibo
     */
    select?: ReciboSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Recibo
     */
    omit?: ReciboOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ReciboInclude<ExtArgs> | null
    where?: ReciboWhereInput
    orderBy?: ReciboOrderByWithRelationInput | ReciboOrderByWithRelationInput[]
    cursor?: ReciboWhereUniqueInput
    take?: number
    skip?: number
    distinct?: ReciboScalarFieldEnum | ReciboScalarFieldEnum[]
  }

  /**
   * Pago without action
   */
  export type PagoDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Pago
     */
    select?: PagoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Pago
     */
    omit?: PagoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PagoInclude<ExtArgs> | null
  }


  /**
   * Model Recibo
   */

  export type AggregateRecibo = {
    _count: ReciboCountAggregateOutputType | null
    _avg: ReciboAvgAggregateOutputType | null
    _sum: ReciboSumAggregateOutputType | null
    _min: ReciboMinAggregateOutputType | null
    _max: ReciboMaxAggregateOutputType | null
  }

  export type ReciboAvgAggregateOutputType = {
    id: number | null
    pagoId: number | null
    monto: number | null
  }

  export type ReciboSumAggregateOutputType = {
    id: number | null
    pagoId: number | null
    monto: number | null
  }

  export type ReciboMinAggregateOutputType = {
    id: number | null
    pagoId: number | null
    monto: number | null
    fecha: Date | null
  }

  export type ReciboMaxAggregateOutputType = {
    id: number | null
    pagoId: number | null
    monto: number | null
    fecha: Date | null
  }

  export type ReciboCountAggregateOutputType = {
    id: number
    pagoId: number
    monto: number
    fecha: number
    _all: number
  }


  export type ReciboAvgAggregateInputType = {
    id?: true
    pagoId?: true
    monto?: true
  }

  export type ReciboSumAggregateInputType = {
    id?: true
    pagoId?: true
    monto?: true
  }

  export type ReciboMinAggregateInputType = {
    id?: true
    pagoId?: true
    monto?: true
    fecha?: true
  }

  export type ReciboMaxAggregateInputType = {
    id?: true
    pagoId?: true
    monto?: true
    fecha?: true
  }

  export type ReciboCountAggregateInputType = {
    id?: true
    pagoId?: true
    monto?: true
    fecha?: true
    _all?: true
  }

  export type ReciboAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Recibo to aggregate.
     */
    where?: ReciboWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Recibos to fetch.
     */
    orderBy?: ReciboOrderByWithRelationInput | ReciboOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ReciboWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Recibos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Recibos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Recibos
    **/
    _count?: true | ReciboCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: ReciboAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: ReciboSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ReciboMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ReciboMaxAggregateInputType
  }

  export type GetReciboAggregateType<T extends ReciboAggregateArgs> = {
        [P in keyof T & keyof AggregateRecibo]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateRecibo[P]>
      : GetScalarType<T[P], AggregateRecibo[P]>
  }




  export type ReciboGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ReciboWhereInput
    orderBy?: ReciboOrderByWithAggregationInput | ReciboOrderByWithAggregationInput[]
    by: ReciboScalarFieldEnum[] | ReciboScalarFieldEnum
    having?: ReciboScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ReciboCountAggregateInputType | true
    _avg?: ReciboAvgAggregateInputType
    _sum?: ReciboSumAggregateInputType
    _min?: ReciboMinAggregateInputType
    _max?: ReciboMaxAggregateInputType
  }

  export type ReciboGroupByOutputType = {
    id: number
    pagoId: number
    monto: number
    fecha: Date
    _count: ReciboCountAggregateOutputType | null
    _avg: ReciboAvgAggregateOutputType | null
    _sum: ReciboSumAggregateOutputType | null
    _min: ReciboMinAggregateOutputType | null
    _max: ReciboMaxAggregateOutputType | null
  }

  type GetReciboGroupByPayload<T extends ReciboGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ReciboGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ReciboGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ReciboGroupByOutputType[P]>
            : GetScalarType<T[P], ReciboGroupByOutputType[P]>
        }
      >
    >


  export type ReciboSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    pagoId?: boolean
    monto?: boolean
    fecha?: boolean
    pago?: boolean | PagoDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["recibo"]>



  export type ReciboSelectScalar = {
    id?: boolean
    pagoId?: boolean
    monto?: boolean
    fecha?: boolean
  }

  export type ReciboOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "pagoId" | "monto" | "fecha", ExtArgs["result"]["recibo"]>
  export type ReciboInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    pago?: boolean | PagoDefaultArgs<ExtArgs>
  }

  export type $ReciboPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Recibo"
    objects: {
      pago: Prisma.$PagoPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      pagoId: number
      monto: number
      fecha: Date
    }, ExtArgs["result"]["recibo"]>
    composites: {}
  }

  type ReciboGetPayload<S extends boolean | null | undefined | ReciboDefaultArgs> = $Result.GetResult<Prisma.$ReciboPayload, S>

  type ReciboCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<ReciboFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: ReciboCountAggregateInputType | true
    }

  export interface ReciboDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Recibo'], meta: { name: 'Recibo' } }
    /**
     * Find zero or one Recibo that matches the filter.
     * @param {ReciboFindUniqueArgs} args - Arguments to find a Recibo
     * @example
     * // Get one Recibo
     * const recibo = await prisma.recibo.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends ReciboFindUniqueArgs>(args: SelectSubset<T, ReciboFindUniqueArgs<ExtArgs>>): Prisma__ReciboClient<$Result.GetResult<Prisma.$ReciboPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Recibo that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {ReciboFindUniqueOrThrowArgs} args - Arguments to find a Recibo
     * @example
     * // Get one Recibo
     * const recibo = await prisma.recibo.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends ReciboFindUniqueOrThrowArgs>(args: SelectSubset<T, ReciboFindUniqueOrThrowArgs<ExtArgs>>): Prisma__ReciboClient<$Result.GetResult<Prisma.$ReciboPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Recibo that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ReciboFindFirstArgs} args - Arguments to find a Recibo
     * @example
     * // Get one Recibo
     * const recibo = await prisma.recibo.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends ReciboFindFirstArgs>(args?: SelectSubset<T, ReciboFindFirstArgs<ExtArgs>>): Prisma__ReciboClient<$Result.GetResult<Prisma.$ReciboPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Recibo that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ReciboFindFirstOrThrowArgs} args - Arguments to find a Recibo
     * @example
     * // Get one Recibo
     * const recibo = await prisma.recibo.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends ReciboFindFirstOrThrowArgs>(args?: SelectSubset<T, ReciboFindFirstOrThrowArgs<ExtArgs>>): Prisma__ReciboClient<$Result.GetResult<Prisma.$ReciboPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Recibos that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ReciboFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Recibos
     * const recibos = await prisma.recibo.findMany()
     * 
     * // Get first 10 Recibos
     * const recibos = await prisma.recibo.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const reciboWithIdOnly = await prisma.recibo.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends ReciboFindManyArgs>(args?: SelectSubset<T, ReciboFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ReciboPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Recibo.
     * @param {ReciboCreateArgs} args - Arguments to create a Recibo.
     * @example
     * // Create one Recibo
     * const Recibo = await prisma.recibo.create({
     *   data: {
     *     // ... data to create a Recibo
     *   }
     * })
     * 
     */
    create<T extends ReciboCreateArgs>(args: SelectSubset<T, ReciboCreateArgs<ExtArgs>>): Prisma__ReciboClient<$Result.GetResult<Prisma.$ReciboPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Recibos.
     * @param {ReciboCreateManyArgs} args - Arguments to create many Recibos.
     * @example
     * // Create many Recibos
     * const recibo = await prisma.recibo.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends ReciboCreateManyArgs>(args?: SelectSubset<T, ReciboCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Recibo.
     * @param {ReciboDeleteArgs} args - Arguments to delete one Recibo.
     * @example
     * // Delete one Recibo
     * const Recibo = await prisma.recibo.delete({
     *   where: {
     *     // ... filter to delete one Recibo
     *   }
     * })
     * 
     */
    delete<T extends ReciboDeleteArgs>(args: SelectSubset<T, ReciboDeleteArgs<ExtArgs>>): Prisma__ReciboClient<$Result.GetResult<Prisma.$ReciboPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Recibo.
     * @param {ReciboUpdateArgs} args - Arguments to update one Recibo.
     * @example
     * // Update one Recibo
     * const recibo = await prisma.recibo.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends ReciboUpdateArgs>(args: SelectSubset<T, ReciboUpdateArgs<ExtArgs>>): Prisma__ReciboClient<$Result.GetResult<Prisma.$ReciboPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Recibos.
     * @param {ReciboDeleteManyArgs} args - Arguments to filter Recibos to delete.
     * @example
     * // Delete a few Recibos
     * const { count } = await prisma.recibo.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends ReciboDeleteManyArgs>(args?: SelectSubset<T, ReciboDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Recibos.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ReciboUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Recibos
     * const recibo = await prisma.recibo.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends ReciboUpdateManyArgs>(args: SelectSubset<T, ReciboUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Recibo.
     * @param {ReciboUpsertArgs} args - Arguments to update or create a Recibo.
     * @example
     * // Update or create a Recibo
     * const recibo = await prisma.recibo.upsert({
     *   create: {
     *     // ... data to create a Recibo
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Recibo we want to update
     *   }
     * })
     */
    upsert<T extends ReciboUpsertArgs>(args: SelectSubset<T, ReciboUpsertArgs<ExtArgs>>): Prisma__ReciboClient<$Result.GetResult<Prisma.$ReciboPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Recibos.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ReciboCountArgs} args - Arguments to filter Recibos to count.
     * @example
     * // Count the number of Recibos
     * const count = await prisma.recibo.count({
     *   where: {
     *     // ... the filter for the Recibos we want to count
     *   }
     * })
    **/
    count<T extends ReciboCountArgs>(
      args?: Subset<T, ReciboCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ReciboCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Recibo.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ReciboAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ReciboAggregateArgs>(args: Subset<T, ReciboAggregateArgs>): Prisma.PrismaPromise<GetReciboAggregateType<T>>

    /**
     * Group by Recibo.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ReciboGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ReciboGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ReciboGroupByArgs['orderBy'] }
        : { orderBy?: ReciboGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ReciboGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetReciboGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Recibo model
   */
  readonly fields: ReciboFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Recibo.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__ReciboClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    pago<T extends PagoDefaultArgs<ExtArgs> = {}>(args?: Subset<T, PagoDefaultArgs<ExtArgs>>): Prisma__PagoClient<$Result.GetResult<Prisma.$PagoPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Recibo model
   */
  interface ReciboFieldRefs {
    readonly id: FieldRef<"Recibo", 'Int'>
    readonly pagoId: FieldRef<"Recibo", 'Int'>
    readonly monto: FieldRef<"Recibo", 'Float'>
    readonly fecha: FieldRef<"Recibo", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Recibo findUnique
   */
  export type ReciboFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Recibo
     */
    select?: ReciboSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Recibo
     */
    omit?: ReciboOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ReciboInclude<ExtArgs> | null
    /**
     * Filter, which Recibo to fetch.
     */
    where: ReciboWhereUniqueInput
  }

  /**
   * Recibo findUniqueOrThrow
   */
  export type ReciboFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Recibo
     */
    select?: ReciboSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Recibo
     */
    omit?: ReciboOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ReciboInclude<ExtArgs> | null
    /**
     * Filter, which Recibo to fetch.
     */
    where: ReciboWhereUniqueInput
  }

  /**
   * Recibo findFirst
   */
  export type ReciboFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Recibo
     */
    select?: ReciboSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Recibo
     */
    omit?: ReciboOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ReciboInclude<ExtArgs> | null
    /**
     * Filter, which Recibo to fetch.
     */
    where?: ReciboWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Recibos to fetch.
     */
    orderBy?: ReciboOrderByWithRelationInput | ReciboOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Recibos.
     */
    cursor?: ReciboWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Recibos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Recibos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Recibos.
     */
    distinct?: ReciboScalarFieldEnum | ReciboScalarFieldEnum[]
  }

  /**
   * Recibo findFirstOrThrow
   */
  export type ReciboFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Recibo
     */
    select?: ReciboSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Recibo
     */
    omit?: ReciboOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ReciboInclude<ExtArgs> | null
    /**
     * Filter, which Recibo to fetch.
     */
    where?: ReciboWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Recibos to fetch.
     */
    orderBy?: ReciboOrderByWithRelationInput | ReciboOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Recibos.
     */
    cursor?: ReciboWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Recibos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Recibos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Recibos.
     */
    distinct?: ReciboScalarFieldEnum | ReciboScalarFieldEnum[]
  }

  /**
   * Recibo findMany
   */
  export type ReciboFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Recibo
     */
    select?: ReciboSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Recibo
     */
    omit?: ReciboOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ReciboInclude<ExtArgs> | null
    /**
     * Filter, which Recibos to fetch.
     */
    where?: ReciboWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Recibos to fetch.
     */
    orderBy?: ReciboOrderByWithRelationInput | ReciboOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Recibos.
     */
    cursor?: ReciboWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Recibos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Recibos.
     */
    skip?: number
    distinct?: ReciboScalarFieldEnum | ReciboScalarFieldEnum[]
  }

  /**
   * Recibo create
   */
  export type ReciboCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Recibo
     */
    select?: ReciboSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Recibo
     */
    omit?: ReciboOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ReciboInclude<ExtArgs> | null
    /**
     * The data needed to create a Recibo.
     */
    data: XOR<ReciboCreateInput, ReciboUncheckedCreateInput>
  }

  /**
   * Recibo createMany
   */
  export type ReciboCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Recibos.
     */
    data: ReciboCreateManyInput | ReciboCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Recibo update
   */
  export type ReciboUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Recibo
     */
    select?: ReciboSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Recibo
     */
    omit?: ReciboOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ReciboInclude<ExtArgs> | null
    /**
     * The data needed to update a Recibo.
     */
    data: XOR<ReciboUpdateInput, ReciboUncheckedUpdateInput>
    /**
     * Choose, which Recibo to update.
     */
    where: ReciboWhereUniqueInput
  }

  /**
   * Recibo updateMany
   */
  export type ReciboUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Recibos.
     */
    data: XOR<ReciboUpdateManyMutationInput, ReciboUncheckedUpdateManyInput>
    /**
     * Filter which Recibos to update
     */
    where?: ReciboWhereInput
    /**
     * Limit how many Recibos to update.
     */
    limit?: number
  }

  /**
   * Recibo upsert
   */
  export type ReciboUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Recibo
     */
    select?: ReciboSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Recibo
     */
    omit?: ReciboOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ReciboInclude<ExtArgs> | null
    /**
     * The filter to search for the Recibo to update in case it exists.
     */
    where: ReciboWhereUniqueInput
    /**
     * In case the Recibo found by the `where` argument doesn't exist, create a new Recibo with this data.
     */
    create: XOR<ReciboCreateInput, ReciboUncheckedCreateInput>
    /**
     * In case the Recibo was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ReciboUpdateInput, ReciboUncheckedUpdateInput>
  }

  /**
   * Recibo delete
   */
  export type ReciboDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Recibo
     */
    select?: ReciboSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Recibo
     */
    omit?: ReciboOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ReciboInclude<ExtArgs> | null
    /**
     * Filter which Recibo to delete.
     */
    where: ReciboWhereUniqueInput
  }

  /**
   * Recibo deleteMany
   */
  export type ReciboDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Recibos to delete
     */
    where?: ReciboWhereInput
    /**
     * Limit how many Recibos to delete.
     */
    limit?: number
  }

  /**
   * Recibo without action
   */
  export type ReciboDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Recibo
     */
    select?: ReciboSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Recibo
     */
    omit?: ReciboOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ReciboInclude<ExtArgs> | null
  }


  /**
   * Model MaterialEducativo
   */

  export type AggregateMaterialEducativo = {
    _count: MaterialEducativoCountAggregateOutputType | null
    _avg: MaterialEducativoAvgAggregateOutputType | null
    _sum: MaterialEducativoSumAggregateOutputType | null
    _min: MaterialEducativoMinAggregateOutputType | null
    _max: MaterialEducativoMaxAggregateOutputType | null
  }

  export type MaterialEducativoAvgAggregateOutputType = {
    id: number | null
    profesorId: number | null
    grupoId: number | null
  }

  export type MaterialEducativoSumAggregateOutputType = {
    id: number | null
    profesorId: number | null
    grupoId: number | null
  }

  export type MaterialEducativoMinAggregateOutputType = {
    id: number | null
    titulo: string | null
    descripcion: string | null
    categoria: string | null
    existencia: boolean | null
    fecha: Date | null
    tipoArchivo: string | null
    profesorId: number | null
    grupoId: number | null
  }

  export type MaterialEducativoMaxAggregateOutputType = {
    id: number | null
    titulo: string | null
    descripcion: string | null
    categoria: string | null
    existencia: boolean | null
    fecha: Date | null
    tipoArchivo: string | null
    profesorId: number | null
    grupoId: number | null
  }

  export type MaterialEducativoCountAggregateOutputType = {
    id: number
    titulo: number
    descripcion: number
    categoria: number
    existencia: number
    fecha: number
    tipoArchivo: number
    profesorId: number
    grupoId: number
    _all: number
  }


  export type MaterialEducativoAvgAggregateInputType = {
    id?: true
    profesorId?: true
    grupoId?: true
  }

  export type MaterialEducativoSumAggregateInputType = {
    id?: true
    profesorId?: true
    grupoId?: true
  }

  export type MaterialEducativoMinAggregateInputType = {
    id?: true
    titulo?: true
    descripcion?: true
    categoria?: true
    existencia?: true
    fecha?: true
    tipoArchivo?: true
    profesorId?: true
    grupoId?: true
  }

  export type MaterialEducativoMaxAggregateInputType = {
    id?: true
    titulo?: true
    descripcion?: true
    categoria?: true
    existencia?: true
    fecha?: true
    tipoArchivo?: true
    profesorId?: true
    grupoId?: true
  }

  export type MaterialEducativoCountAggregateInputType = {
    id?: true
    titulo?: true
    descripcion?: true
    categoria?: true
    existencia?: true
    fecha?: true
    tipoArchivo?: true
    profesorId?: true
    grupoId?: true
    _all?: true
  }

  export type MaterialEducativoAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which MaterialEducativo to aggregate.
     */
    where?: MaterialEducativoWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MaterialEducativos to fetch.
     */
    orderBy?: MaterialEducativoOrderByWithRelationInput | MaterialEducativoOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: MaterialEducativoWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MaterialEducativos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MaterialEducativos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned MaterialEducativos
    **/
    _count?: true | MaterialEducativoCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: MaterialEducativoAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: MaterialEducativoSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: MaterialEducativoMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: MaterialEducativoMaxAggregateInputType
  }

  export type GetMaterialEducativoAggregateType<T extends MaterialEducativoAggregateArgs> = {
        [P in keyof T & keyof AggregateMaterialEducativo]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateMaterialEducativo[P]>
      : GetScalarType<T[P], AggregateMaterialEducativo[P]>
  }




  export type MaterialEducativoGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: MaterialEducativoWhereInput
    orderBy?: MaterialEducativoOrderByWithAggregationInput | MaterialEducativoOrderByWithAggregationInput[]
    by: MaterialEducativoScalarFieldEnum[] | MaterialEducativoScalarFieldEnum
    having?: MaterialEducativoScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: MaterialEducativoCountAggregateInputType | true
    _avg?: MaterialEducativoAvgAggregateInputType
    _sum?: MaterialEducativoSumAggregateInputType
    _min?: MaterialEducativoMinAggregateInputType
    _max?: MaterialEducativoMaxAggregateInputType
  }

  export type MaterialEducativoGroupByOutputType = {
    id: number
    titulo: string
    descripcion: string
    categoria: string
    existencia: boolean
    fecha: Date
    tipoArchivo: string
    profesorId: number
    grupoId: number
    _count: MaterialEducativoCountAggregateOutputType | null
    _avg: MaterialEducativoAvgAggregateOutputType | null
    _sum: MaterialEducativoSumAggregateOutputType | null
    _min: MaterialEducativoMinAggregateOutputType | null
    _max: MaterialEducativoMaxAggregateOutputType | null
  }

  type GetMaterialEducativoGroupByPayload<T extends MaterialEducativoGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<MaterialEducativoGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof MaterialEducativoGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], MaterialEducativoGroupByOutputType[P]>
            : GetScalarType<T[P], MaterialEducativoGroupByOutputType[P]>
        }
      >
    >


  export type MaterialEducativoSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    titulo?: boolean
    descripcion?: boolean
    categoria?: boolean
    existencia?: boolean
    fecha?: boolean
    tipoArchivo?: boolean
    profesorId?: boolean
    grupoId?: boolean
    profesor?: boolean | ProfesorDefaultArgs<ExtArgs>
    grupo?: boolean | GrupoDefaultArgs<ExtArgs>
    archivo?: boolean | MaterialEducativo$archivoArgs<ExtArgs>
    _count?: boolean | MaterialEducativoCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["materialEducativo"]>



  export type MaterialEducativoSelectScalar = {
    id?: boolean
    titulo?: boolean
    descripcion?: boolean
    categoria?: boolean
    existencia?: boolean
    fecha?: boolean
    tipoArchivo?: boolean
    profesorId?: boolean
    grupoId?: boolean
  }

  export type MaterialEducativoOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "titulo" | "descripcion" | "categoria" | "existencia" | "fecha" | "tipoArchivo" | "profesorId" | "grupoId", ExtArgs["result"]["materialEducativo"]>
  export type MaterialEducativoInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    profesor?: boolean | ProfesorDefaultArgs<ExtArgs>
    grupo?: boolean | GrupoDefaultArgs<ExtArgs>
    archivo?: boolean | MaterialEducativo$archivoArgs<ExtArgs>
    _count?: boolean | MaterialEducativoCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $MaterialEducativoPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "MaterialEducativo"
    objects: {
      profesor: Prisma.$ProfesorPayload<ExtArgs>
      grupo: Prisma.$GrupoPayload<ExtArgs>
      archivo: Prisma.$ArchivoSubidoPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      titulo: string
      descripcion: string
      categoria: string
      existencia: boolean
      fecha: Date
      tipoArchivo: string
      profesorId: number
      grupoId: number
    }, ExtArgs["result"]["materialEducativo"]>
    composites: {}
  }

  type MaterialEducativoGetPayload<S extends boolean | null | undefined | MaterialEducativoDefaultArgs> = $Result.GetResult<Prisma.$MaterialEducativoPayload, S>

  type MaterialEducativoCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<MaterialEducativoFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: MaterialEducativoCountAggregateInputType | true
    }

  export interface MaterialEducativoDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['MaterialEducativo'], meta: { name: 'MaterialEducativo' } }
    /**
     * Find zero or one MaterialEducativo that matches the filter.
     * @param {MaterialEducativoFindUniqueArgs} args - Arguments to find a MaterialEducativo
     * @example
     * // Get one MaterialEducativo
     * const materialEducativo = await prisma.materialEducativo.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends MaterialEducativoFindUniqueArgs>(args: SelectSubset<T, MaterialEducativoFindUniqueArgs<ExtArgs>>): Prisma__MaterialEducativoClient<$Result.GetResult<Prisma.$MaterialEducativoPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one MaterialEducativo that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {MaterialEducativoFindUniqueOrThrowArgs} args - Arguments to find a MaterialEducativo
     * @example
     * // Get one MaterialEducativo
     * const materialEducativo = await prisma.materialEducativo.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends MaterialEducativoFindUniqueOrThrowArgs>(args: SelectSubset<T, MaterialEducativoFindUniqueOrThrowArgs<ExtArgs>>): Prisma__MaterialEducativoClient<$Result.GetResult<Prisma.$MaterialEducativoPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first MaterialEducativo that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MaterialEducativoFindFirstArgs} args - Arguments to find a MaterialEducativo
     * @example
     * // Get one MaterialEducativo
     * const materialEducativo = await prisma.materialEducativo.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends MaterialEducativoFindFirstArgs>(args?: SelectSubset<T, MaterialEducativoFindFirstArgs<ExtArgs>>): Prisma__MaterialEducativoClient<$Result.GetResult<Prisma.$MaterialEducativoPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first MaterialEducativo that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MaterialEducativoFindFirstOrThrowArgs} args - Arguments to find a MaterialEducativo
     * @example
     * // Get one MaterialEducativo
     * const materialEducativo = await prisma.materialEducativo.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends MaterialEducativoFindFirstOrThrowArgs>(args?: SelectSubset<T, MaterialEducativoFindFirstOrThrowArgs<ExtArgs>>): Prisma__MaterialEducativoClient<$Result.GetResult<Prisma.$MaterialEducativoPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more MaterialEducativos that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MaterialEducativoFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all MaterialEducativos
     * const materialEducativos = await prisma.materialEducativo.findMany()
     * 
     * // Get first 10 MaterialEducativos
     * const materialEducativos = await prisma.materialEducativo.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const materialEducativoWithIdOnly = await prisma.materialEducativo.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends MaterialEducativoFindManyArgs>(args?: SelectSubset<T, MaterialEducativoFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MaterialEducativoPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a MaterialEducativo.
     * @param {MaterialEducativoCreateArgs} args - Arguments to create a MaterialEducativo.
     * @example
     * // Create one MaterialEducativo
     * const MaterialEducativo = await prisma.materialEducativo.create({
     *   data: {
     *     // ... data to create a MaterialEducativo
     *   }
     * })
     * 
     */
    create<T extends MaterialEducativoCreateArgs>(args: SelectSubset<T, MaterialEducativoCreateArgs<ExtArgs>>): Prisma__MaterialEducativoClient<$Result.GetResult<Prisma.$MaterialEducativoPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many MaterialEducativos.
     * @param {MaterialEducativoCreateManyArgs} args - Arguments to create many MaterialEducativos.
     * @example
     * // Create many MaterialEducativos
     * const materialEducativo = await prisma.materialEducativo.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends MaterialEducativoCreateManyArgs>(args?: SelectSubset<T, MaterialEducativoCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a MaterialEducativo.
     * @param {MaterialEducativoDeleteArgs} args - Arguments to delete one MaterialEducativo.
     * @example
     * // Delete one MaterialEducativo
     * const MaterialEducativo = await prisma.materialEducativo.delete({
     *   where: {
     *     // ... filter to delete one MaterialEducativo
     *   }
     * })
     * 
     */
    delete<T extends MaterialEducativoDeleteArgs>(args: SelectSubset<T, MaterialEducativoDeleteArgs<ExtArgs>>): Prisma__MaterialEducativoClient<$Result.GetResult<Prisma.$MaterialEducativoPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one MaterialEducativo.
     * @param {MaterialEducativoUpdateArgs} args - Arguments to update one MaterialEducativo.
     * @example
     * // Update one MaterialEducativo
     * const materialEducativo = await prisma.materialEducativo.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends MaterialEducativoUpdateArgs>(args: SelectSubset<T, MaterialEducativoUpdateArgs<ExtArgs>>): Prisma__MaterialEducativoClient<$Result.GetResult<Prisma.$MaterialEducativoPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more MaterialEducativos.
     * @param {MaterialEducativoDeleteManyArgs} args - Arguments to filter MaterialEducativos to delete.
     * @example
     * // Delete a few MaterialEducativos
     * const { count } = await prisma.materialEducativo.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends MaterialEducativoDeleteManyArgs>(args?: SelectSubset<T, MaterialEducativoDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more MaterialEducativos.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MaterialEducativoUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many MaterialEducativos
     * const materialEducativo = await prisma.materialEducativo.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends MaterialEducativoUpdateManyArgs>(args: SelectSubset<T, MaterialEducativoUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one MaterialEducativo.
     * @param {MaterialEducativoUpsertArgs} args - Arguments to update or create a MaterialEducativo.
     * @example
     * // Update or create a MaterialEducativo
     * const materialEducativo = await prisma.materialEducativo.upsert({
     *   create: {
     *     // ... data to create a MaterialEducativo
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the MaterialEducativo we want to update
     *   }
     * })
     */
    upsert<T extends MaterialEducativoUpsertArgs>(args: SelectSubset<T, MaterialEducativoUpsertArgs<ExtArgs>>): Prisma__MaterialEducativoClient<$Result.GetResult<Prisma.$MaterialEducativoPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of MaterialEducativos.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MaterialEducativoCountArgs} args - Arguments to filter MaterialEducativos to count.
     * @example
     * // Count the number of MaterialEducativos
     * const count = await prisma.materialEducativo.count({
     *   where: {
     *     // ... the filter for the MaterialEducativos we want to count
     *   }
     * })
    **/
    count<T extends MaterialEducativoCountArgs>(
      args?: Subset<T, MaterialEducativoCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], MaterialEducativoCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a MaterialEducativo.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MaterialEducativoAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends MaterialEducativoAggregateArgs>(args: Subset<T, MaterialEducativoAggregateArgs>): Prisma.PrismaPromise<GetMaterialEducativoAggregateType<T>>

    /**
     * Group by MaterialEducativo.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MaterialEducativoGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends MaterialEducativoGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: MaterialEducativoGroupByArgs['orderBy'] }
        : { orderBy?: MaterialEducativoGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, MaterialEducativoGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetMaterialEducativoGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the MaterialEducativo model
   */
  readonly fields: MaterialEducativoFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for MaterialEducativo.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__MaterialEducativoClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    profesor<T extends ProfesorDefaultArgs<ExtArgs> = {}>(args?: Subset<T, ProfesorDefaultArgs<ExtArgs>>): Prisma__ProfesorClient<$Result.GetResult<Prisma.$ProfesorPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    grupo<T extends GrupoDefaultArgs<ExtArgs> = {}>(args?: Subset<T, GrupoDefaultArgs<ExtArgs>>): Prisma__GrupoClient<$Result.GetResult<Prisma.$GrupoPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    archivo<T extends MaterialEducativo$archivoArgs<ExtArgs> = {}>(args?: Subset<T, MaterialEducativo$archivoArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ArchivoSubidoPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the MaterialEducativo model
   */
  interface MaterialEducativoFieldRefs {
    readonly id: FieldRef<"MaterialEducativo", 'Int'>
    readonly titulo: FieldRef<"MaterialEducativo", 'String'>
    readonly descripcion: FieldRef<"MaterialEducativo", 'String'>
    readonly categoria: FieldRef<"MaterialEducativo", 'String'>
    readonly existencia: FieldRef<"MaterialEducativo", 'Boolean'>
    readonly fecha: FieldRef<"MaterialEducativo", 'DateTime'>
    readonly tipoArchivo: FieldRef<"MaterialEducativo", 'String'>
    readonly profesorId: FieldRef<"MaterialEducativo", 'Int'>
    readonly grupoId: FieldRef<"MaterialEducativo", 'Int'>
  }
    

  // Custom InputTypes
  /**
   * MaterialEducativo findUnique
   */
  export type MaterialEducativoFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MaterialEducativo
     */
    select?: MaterialEducativoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MaterialEducativo
     */
    omit?: MaterialEducativoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MaterialEducativoInclude<ExtArgs> | null
    /**
     * Filter, which MaterialEducativo to fetch.
     */
    where: MaterialEducativoWhereUniqueInput
  }

  /**
   * MaterialEducativo findUniqueOrThrow
   */
  export type MaterialEducativoFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MaterialEducativo
     */
    select?: MaterialEducativoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MaterialEducativo
     */
    omit?: MaterialEducativoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MaterialEducativoInclude<ExtArgs> | null
    /**
     * Filter, which MaterialEducativo to fetch.
     */
    where: MaterialEducativoWhereUniqueInput
  }

  /**
   * MaterialEducativo findFirst
   */
  export type MaterialEducativoFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MaterialEducativo
     */
    select?: MaterialEducativoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MaterialEducativo
     */
    omit?: MaterialEducativoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MaterialEducativoInclude<ExtArgs> | null
    /**
     * Filter, which MaterialEducativo to fetch.
     */
    where?: MaterialEducativoWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MaterialEducativos to fetch.
     */
    orderBy?: MaterialEducativoOrderByWithRelationInput | MaterialEducativoOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for MaterialEducativos.
     */
    cursor?: MaterialEducativoWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MaterialEducativos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MaterialEducativos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of MaterialEducativos.
     */
    distinct?: MaterialEducativoScalarFieldEnum | MaterialEducativoScalarFieldEnum[]
  }

  /**
   * MaterialEducativo findFirstOrThrow
   */
  export type MaterialEducativoFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MaterialEducativo
     */
    select?: MaterialEducativoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MaterialEducativo
     */
    omit?: MaterialEducativoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MaterialEducativoInclude<ExtArgs> | null
    /**
     * Filter, which MaterialEducativo to fetch.
     */
    where?: MaterialEducativoWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MaterialEducativos to fetch.
     */
    orderBy?: MaterialEducativoOrderByWithRelationInput | MaterialEducativoOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for MaterialEducativos.
     */
    cursor?: MaterialEducativoWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MaterialEducativos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MaterialEducativos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of MaterialEducativos.
     */
    distinct?: MaterialEducativoScalarFieldEnum | MaterialEducativoScalarFieldEnum[]
  }

  /**
   * MaterialEducativo findMany
   */
  export type MaterialEducativoFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MaterialEducativo
     */
    select?: MaterialEducativoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MaterialEducativo
     */
    omit?: MaterialEducativoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MaterialEducativoInclude<ExtArgs> | null
    /**
     * Filter, which MaterialEducativos to fetch.
     */
    where?: MaterialEducativoWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MaterialEducativos to fetch.
     */
    orderBy?: MaterialEducativoOrderByWithRelationInput | MaterialEducativoOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing MaterialEducativos.
     */
    cursor?: MaterialEducativoWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MaterialEducativos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MaterialEducativos.
     */
    skip?: number
    distinct?: MaterialEducativoScalarFieldEnum | MaterialEducativoScalarFieldEnum[]
  }

  /**
   * MaterialEducativo create
   */
  export type MaterialEducativoCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MaterialEducativo
     */
    select?: MaterialEducativoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MaterialEducativo
     */
    omit?: MaterialEducativoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MaterialEducativoInclude<ExtArgs> | null
    /**
     * The data needed to create a MaterialEducativo.
     */
    data: XOR<MaterialEducativoCreateInput, MaterialEducativoUncheckedCreateInput>
  }

  /**
   * MaterialEducativo createMany
   */
  export type MaterialEducativoCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many MaterialEducativos.
     */
    data: MaterialEducativoCreateManyInput | MaterialEducativoCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * MaterialEducativo update
   */
  export type MaterialEducativoUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MaterialEducativo
     */
    select?: MaterialEducativoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MaterialEducativo
     */
    omit?: MaterialEducativoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MaterialEducativoInclude<ExtArgs> | null
    /**
     * The data needed to update a MaterialEducativo.
     */
    data: XOR<MaterialEducativoUpdateInput, MaterialEducativoUncheckedUpdateInput>
    /**
     * Choose, which MaterialEducativo to update.
     */
    where: MaterialEducativoWhereUniqueInput
  }

  /**
   * MaterialEducativo updateMany
   */
  export type MaterialEducativoUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update MaterialEducativos.
     */
    data: XOR<MaterialEducativoUpdateManyMutationInput, MaterialEducativoUncheckedUpdateManyInput>
    /**
     * Filter which MaterialEducativos to update
     */
    where?: MaterialEducativoWhereInput
    /**
     * Limit how many MaterialEducativos to update.
     */
    limit?: number
  }

  /**
   * MaterialEducativo upsert
   */
  export type MaterialEducativoUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MaterialEducativo
     */
    select?: MaterialEducativoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MaterialEducativo
     */
    omit?: MaterialEducativoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MaterialEducativoInclude<ExtArgs> | null
    /**
     * The filter to search for the MaterialEducativo to update in case it exists.
     */
    where: MaterialEducativoWhereUniqueInput
    /**
     * In case the MaterialEducativo found by the `where` argument doesn't exist, create a new MaterialEducativo with this data.
     */
    create: XOR<MaterialEducativoCreateInput, MaterialEducativoUncheckedCreateInput>
    /**
     * In case the MaterialEducativo was found with the provided `where` argument, update it with this data.
     */
    update: XOR<MaterialEducativoUpdateInput, MaterialEducativoUncheckedUpdateInput>
  }

  /**
   * MaterialEducativo delete
   */
  export type MaterialEducativoDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MaterialEducativo
     */
    select?: MaterialEducativoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MaterialEducativo
     */
    omit?: MaterialEducativoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MaterialEducativoInclude<ExtArgs> | null
    /**
     * Filter which MaterialEducativo to delete.
     */
    where: MaterialEducativoWhereUniqueInput
  }

  /**
   * MaterialEducativo deleteMany
   */
  export type MaterialEducativoDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which MaterialEducativos to delete
     */
    where?: MaterialEducativoWhereInput
    /**
     * Limit how many MaterialEducativos to delete.
     */
    limit?: number
  }

  /**
   * MaterialEducativo.archivo
   */
  export type MaterialEducativo$archivoArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ArchivoSubido
     */
    select?: ArchivoSubidoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ArchivoSubido
     */
    omit?: ArchivoSubidoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ArchivoSubidoInclude<ExtArgs> | null
    where?: ArchivoSubidoWhereInput
    orderBy?: ArchivoSubidoOrderByWithRelationInput | ArchivoSubidoOrderByWithRelationInput[]
    cursor?: ArchivoSubidoWhereUniqueInput
    take?: number
    skip?: number
    distinct?: ArchivoSubidoScalarFieldEnum | ArchivoSubidoScalarFieldEnum[]
  }

  /**
   * MaterialEducativo without action
   */
  export type MaterialEducativoDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MaterialEducativo
     */
    select?: MaterialEducativoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MaterialEducativo
     */
    omit?: MaterialEducativoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MaterialEducativoInclude<ExtArgs> | null
  }


  /**
   * Model ArchivoSubido
   */

  export type AggregateArchivoSubido = {
    _count: ArchivoSubidoCountAggregateOutputType | null
    _avg: ArchivoSubidoAvgAggregateOutputType | null
    _sum: ArchivoSubidoSumAggregateOutputType | null
    _min: ArchivoSubidoMinAggregateOutputType | null
    _max: ArchivoSubidoMaxAggregateOutputType | null
  }

  export type ArchivoSubidoAvgAggregateOutputType = {
    id: number | null
    materialId: number | null
  }

  export type ArchivoSubidoSumAggregateOutputType = {
    id: number | null
    materialId: number | null
  }

  export type ArchivoSubidoMinAggregateOutputType = {
    id: number | null
    materialId: number | null
    nombreArchivo: string | null
    urlNube: string | null
  }

  export type ArchivoSubidoMaxAggregateOutputType = {
    id: number | null
    materialId: number | null
    nombreArchivo: string | null
    urlNube: string | null
  }

  export type ArchivoSubidoCountAggregateOutputType = {
    id: number
    materialId: number
    nombreArchivo: number
    urlNube: number
    _all: number
  }


  export type ArchivoSubidoAvgAggregateInputType = {
    id?: true
    materialId?: true
  }

  export type ArchivoSubidoSumAggregateInputType = {
    id?: true
    materialId?: true
  }

  export type ArchivoSubidoMinAggregateInputType = {
    id?: true
    materialId?: true
    nombreArchivo?: true
    urlNube?: true
  }

  export type ArchivoSubidoMaxAggregateInputType = {
    id?: true
    materialId?: true
    nombreArchivo?: true
    urlNube?: true
  }

  export type ArchivoSubidoCountAggregateInputType = {
    id?: true
    materialId?: true
    nombreArchivo?: true
    urlNube?: true
    _all?: true
  }

  export type ArchivoSubidoAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which ArchivoSubido to aggregate.
     */
    where?: ArchivoSubidoWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ArchivoSubidos to fetch.
     */
    orderBy?: ArchivoSubidoOrderByWithRelationInput | ArchivoSubidoOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ArchivoSubidoWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ArchivoSubidos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ArchivoSubidos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned ArchivoSubidos
    **/
    _count?: true | ArchivoSubidoCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: ArchivoSubidoAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: ArchivoSubidoSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ArchivoSubidoMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ArchivoSubidoMaxAggregateInputType
  }

  export type GetArchivoSubidoAggregateType<T extends ArchivoSubidoAggregateArgs> = {
        [P in keyof T & keyof AggregateArchivoSubido]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateArchivoSubido[P]>
      : GetScalarType<T[P], AggregateArchivoSubido[P]>
  }




  export type ArchivoSubidoGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ArchivoSubidoWhereInput
    orderBy?: ArchivoSubidoOrderByWithAggregationInput | ArchivoSubidoOrderByWithAggregationInput[]
    by: ArchivoSubidoScalarFieldEnum[] | ArchivoSubidoScalarFieldEnum
    having?: ArchivoSubidoScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ArchivoSubidoCountAggregateInputType | true
    _avg?: ArchivoSubidoAvgAggregateInputType
    _sum?: ArchivoSubidoSumAggregateInputType
    _min?: ArchivoSubidoMinAggregateInputType
    _max?: ArchivoSubidoMaxAggregateInputType
  }

  export type ArchivoSubidoGroupByOutputType = {
    id: number
    materialId: number
    nombreArchivo: string
    urlNube: string
    _count: ArchivoSubidoCountAggregateOutputType | null
    _avg: ArchivoSubidoAvgAggregateOutputType | null
    _sum: ArchivoSubidoSumAggregateOutputType | null
    _min: ArchivoSubidoMinAggregateOutputType | null
    _max: ArchivoSubidoMaxAggregateOutputType | null
  }

  type GetArchivoSubidoGroupByPayload<T extends ArchivoSubidoGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ArchivoSubidoGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ArchivoSubidoGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ArchivoSubidoGroupByOutputType[P]>
            : GetScalarType<T[P], ArchivoSubidoGroupByOutputType[P]>
        }
      >
    >


  export type ArchivoSubidoSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    materialId?: boolean
    nombreArchivo?: boolean
    urlNube?: boolean
    material?: boolean | MaterialEducativoDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["archivoSubido"]>



  export type ArchivoSubidoSelectScalar = {
    id?: boolean
    materialId?: boolean
    nombreArchivo?: boolean
    urlNube?: boolean
  }

  export type ArchivoSubidoOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "materialId" | "nombreArchivo" | "urlNube", ExtArgs["result"]["archivoSubido"]>
  export type ArchivoSubidoInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    material?: boolean | MaterialEducativoDefaultArgs<ExtArgs>
  }

  export type $ArchivoSubidoPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "ArchivoSubido"
    objects: {
      material: Prisma.$MaterialEducativoPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      materialId: number
      nombreArchivo: string
      urlNube: string
    }, ExtArgs["result"]["archivoSubido"]>
    composites: {}
  }

  type ArchivoSubidoGetPayload<S extends boolean | null | undefined | ArchivoSubidoDefaultArgs> = $Result.GetResult<Prisma.$ArchivoSubidoPayload, S>

  type ArchivoSubidoCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<ArchivoSubidoFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: ArchivoSubidoCountAggregateInputType | true
    }

  export interface ArchivoSubidoDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['ArchivoSubido'], meta: { name: 'ArchivoSubido' } }
    /**
     * Find zero or one ArchivoSubido that matches the filter.
     * @param {ArchivoSubidoFindUniqueArgs} args - Arguments to find a ArchivoSubido
     * @example
     * // Get one ArchivoSubido
     * const archivoSubido = await prisma.archivoSubido.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends ArchivoSubidoFindUniqueArgs>(args: SelectSubset<T, ArchivoSubidoFindUniqueArgs<ExtArgs>>): Prisma__ArchivoSubidoClient<$Result.GetResult<Prisma.$ArchivoSubidoPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one ArchivoSubido that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {ArchivoSubidoFindUniqueOrThrowArgs} args - Arguments to find a ArchivoSubido
     * @example
     * // Get one ArchivoSubido
     * const archivoSubido = await prisma.archivoSubido.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends ArchivoSubidoFindUniqueOrThrowArgs>(args: SelectSubset<T, ArchivoSubidoFindUniqueOrThrowArgs<ExtArgs>>): Prisma__ArchivoSubidoClient<$Result.GetResult<Prisma.$ArchivoSubidoPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first ArchivoSubido that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ArchivoSubidoFindFirstArgs} args - Arguments to find a ArchivoSubido
     * @example
     * // Get one ArchivoSubido
     * const archivoSubido = await prisma.archivoSubido.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends ArchivoSubidoFindFirstArgs>(args?: SelectSubset<T, ArchivoSubidoFindFirstArgs<ExtArgs>>): Prisma__ArchivoSubidoClient<$Result.GetResult<Prisma.$ArchivoSubidoPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first ArchivoSubido that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ArchivoSubidoFindFirstOrThrowArgs} args - Arguments to find a ArchivoSubido
     * @example
     * // Get one ArchivoSubido
     * const archivoSubido = await prisma.archivoSubido.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends ArchivoSubidoFindFirstOrThrowArgs>(args?: SelectSubset<T, ArchivoSubidoFindFirstOrThrowArgs<ExtArgs>>): Prisma__ArchivoSubidoClient<$Result.GetResult<Prisma.$ArchivoSubidoPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more ArchivoSubidos that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ArchivoSubidoFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all ArchivoSubidos
     * const archivoSubidos = await prisma.archivoSubido.findMany()
     * 
     * // Get first 10 ArchivoSubidos
     * const archivoSubidos = await prisma.archivoSubido.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const archivoSubidoWithIdOnly = await prisma.archivoSubido.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends ArchivoSubidoFindManyArgs>(args?: SelectSubset<T, ArchivoSubidoFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ArchivoSubidoPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a ArchivoSubido.
     * @param {ArchivoSubidoCreateArgs} args - Arguments to create a ArchivoSubido.
     * @example
     * // Create one ArchivoSubido
     * const ArchivoSubido = await prisma.archivoSubido.create({
     *   data: {
     *     // ... data to create a ArchivoSubido
     *   }
     * })
     * 
     */
    create<T extends ArchivoSubidoCreateArgs>(args: SelectSubset<T, ArchivoSubidoCreateArgs<ExtArgs>>): Prisma__ArchivoSubidoClient<$Result.GetResult<Prisma.$ArchivoSubidoPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many ArchivoSubidos.
     * @param {ArchivoSubidoCreateManyArgs} args - Arguments to create many ArchivoSubidos.
     * @example
     * // Create many ArchivoSubidos
     * const archivoSubido = await prisma.archivoSubido.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends ArchivoSubidoCreateManyArgs>(args?: SelectSubset<T, ArchivoSubidoCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a ArchivoSubido.
     * @param {ArchivoSubidoDeleteArgs} args - Arguments to delete one ArchivoSubido.
     * @example
     * // Delete one ArchivoSubido
     * const ArchivoSubido = await prisma.archivoSubido.delete({
     *   where: {
     *     // ... filter to delete one ArchivoSubido
     *   }
     * })
     * 
     */
    delete<T extends ArchivoSubidoDeleteArgs>(args: SelectSubset<T, ArchivoSubidoDeleteArgs<ExtArgs>>): Prisma__ArchivoSubidoClient<$Result.GetResult<Prisma.$ArchivoSubidoPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one ArchivoSubido.
     * @param {ArchivoSubidoUpdateArgs} args - Arguments to update one ArchivoSubido.
     * @example
     * // Update one ArchivoSubido
     * const archivoSubido = await prisma.archivoSubido.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends ArchivoSubidoUpdateArgs>(args: SelectSubset<T, ArchivoSubidoUpdateArgs<ExtArgs>>): Prisma__ArchivoSubidoClient<$Result.GetResult<Prisma.$ArchivoSubidoPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more ArchivoSubidos.
     * @param {ArchivoSubidoDeleteManyArgs} args - Arguments to filter ArchivoSubidos to delete.
     * @example
     * // Delete a few ArchivoSubidos
     * const { count } = await prisma.archivoSubido.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends ArchivoSubidoDeleteManyArgs>(args?: SelectSubset<T, ArchivoSubidoDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more ArchivoSubidos.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ArchivoSubidoUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many ArchivoSubidos
     * const archivoSubido = await prisma.archivoSubido.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends ArchivoSubidoUpdateManyArgs>(args: SelectSubset<T, ArchivoSubidoUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one ArchivoSubido.
     * @param {ArchivoSubidoUpsertArgs} args - Arguments to update or create a ArchivoSubido.
     * @example
     * // Update or create a ArchivoSubido
     * const archivoSubido = await prisma.archivoSubido.upsert({
     *   create: {
     *     // ... data to create a ArchivoSubido
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the ArchivoSubido we want to update
     *   }
     * })
     */
    upsert<T extends ArchivoSubidoUpsertArgs>(args: SelectSubset<T, ArchivoSubidoUpsertArgs<ExtArgs>>): Prisma__ArchivoSubidoClient<$Result.GetResult<Prisma.$ArchivoSubidoPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of ArchivoSubidos.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ArchivoSubidoCountArgs} args - Arguments to filter ArchivoSubidos to count.
     * @example
     * // Count the number of ArchivoSubidos
     * const count = await prisma.archivoSubido.count({
     *   where: {
     *     // ... the filter for the ArchivoSubidos we want to count
     *   }
     * })
    **/
    count<T extends ArchivoSubidoCountArgs>(
      args?: Subset<T, ArchivoSubidoCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ArchivoSubidoCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a ArchivoSubido.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ArchivoSubidoAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ArchivoSubidoAggregateArgs>(args: Subset<T, ArchivoSubidoAggregateArgs>): Prisma.PrismaPromise<GetArchivoSubidoAggregateType<T>>

    /**
     * Group by ArchivoSubido.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ArchivoSubidoGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ArchivoSubidoGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ArchivoSubidoGroupByArgs['orderBy'] }
        : { orderBy?: ArchivoSubidoGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ArchivoSubidoGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetArchivoSubidoGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the ArchivoSubido model
   */
  readonly fields: ArchivoSubidoFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for ArchivoSubido.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__ArchivoSubidoClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    material<T extends MaterialEducativoDefaultArgs<ExtArgs> = {}>(args?: Subset<T, MaterialEducativoDefaultArgs<ExtArgs>>): Prisma__MaterialEducativoClient<$Result.GetResult<Prisma.$MaterialEducativoPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the ArchivoSubido model
   */
  interface ArchivoSubidoFieldRefs {
    readonly id: FieldRef<"ArchivoSubido", 'Int'>
    readonly materialId: FieldRef<"ArchivoSubido", 'Int'>
    readonly nombreArchivo: FieldRef<"ArchivoSubido", 'String'>
    readonly urlNube: FieldRef<"ArchivoSubido", 'String'>
  }
    

  // Custom InputTypes
  /**
   * ArchivoSubido findUnique
   */
  export type ArchivoSubidoFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ArchivoSubido
     */
    select?: ArchivoSubidoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ArchivoSubido
     */
    omit?: ArchivoSubidoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ArchivoSubidoInclude<ExtArgs> | null
    /**
     * Filter, which ArchivoSubido to fetch.
     */
    where: ArchivoSubidoWhereUniqueInput
  }

  /**
   * ArchivoSubido findUniqueOrThrow
   */
  export type ArchivoSubidoFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ArchivoSubido
     */
    select?: ArchivoSubidoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ArchivoSubido
     */
    omit?: ArchivoSubidoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ArchivoSubidoInclude<ExtArgs> | null
    /**
     * Filter, which ArchivoSubido to fetch.
     */
    where: ArchivoSubidoWhereUniqueInput
  }

  /**
   * ArchivoSubido findFirst
   */
  export type ArchivoSubidoFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ArchivoSubido
     */
    select?: ArchivoSubidoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ArchivoSubido
     */
    omit?: ArchivoSubidoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ArchivoSubidoInclude<ExtArgs> | null
    /**
     * Filter, which ArchivoSubido to fetch.
     */
    where?: ArchivoSubidoWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ArchivoSubidos to fetch.
     */
    orderBy?: ArchivoSubidoOrderByWithRelationInput | ArchivoSubidoOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ArchivoSubidos.
     */
    cursor?: ArchivoSubidoWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ArchivoSubidos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ArchivoSubidos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ArchivoSubidos.
     */
    distinct?: ArchivoSubidoScalarFieldEnum | ArchivoSubidoScalarFieldEnum[]
  }

  /**
   * ArchivoSubido findFirstOrThrow
   */
  export type ArchivoSubidoFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ArchivoSubido
     */
    select?: ArchivoSubidoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ArchivoSubido
     */
    omit?: ArchivoSubidoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ArchivoSubidoInclude<ExtArgs> | null
    /**
     * Filter, which ArchivoSubido to fetch.
     */
    where?: ArchivoSubidoWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ArchivoSubidos to fetch.
     */
    orderBy?: ArchivoSubidoOrderByWithRelationInput | ArchivoSubidoOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ArchivoSubidos.
     */
    cursor?: ArchivoSubidoWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ArchivoSubidos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ArchivoSubidos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ArchivoSubidos.
     */
    distinct?: ArchivoSubidoScalarFieldEnum | ArchivoSubidoScalarFieldEnum[]
  }

  /**
   * ArchivoSubido findMany
   */
  export type ArchivoSubidoFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ArchivoSubido
     */
    select?: ArchivoSubidoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ArchivoSubido
     */
    omit?: ArchivoSubidoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ArchivoSubidoInclude<ExtArgs> | null
    /**
     * Filter, which ArchivoSubidos to fetch.
     */
    where?: ArchivoSubidoWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ArchivoSubidos to fetch.
     */
    orderBy?: ArchivoSubidoOrderByWithRelationInput | ArchivoSubidoOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing ArchivoSubidos.
     */
    cursor?: ArchivoSubidoWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ArchivoSubidos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ArchivoSubidos.
     */
    skip?: number
    distinct?: ArchivoSubidoScalarFieldEnum | ArchivoSubidoScalarFieldEnum[]
  }

  /**
   * ArchivoSubido create
   */
  export type ArchivoSubidoCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ArchivoSubido
     */
    select?: ArchivoSubidoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ArchivoSubido
     */
    omit?: ArchivoSubidoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ArchivoSubidoInclude<ExtArgs> | null
    /**
     * The data needed to create a ArchivoSubido.
     */
    data: XOR<ArchivoSubidoCreateInput, ArchivoSubidoUncheckedCreateInput>
  }

  /**
   * ArchivoSubido createMany
   */
  export type ArchivoSubidoCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many ArchivoSubidos.
     */
    data: ArchivoSubidoCreateManyInput | ArchivoSubidoCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * ArchivoSubido update
   */
  export type ArchivoSubidoUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ArchivoSubido
     */
    select?: ArchivoSubidoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ArchivoSubido
     */
    omit?: ArchivoSubidoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ArchivoSubidoInclude<ExtArgs> | null
    /**
     * The data needed to update a ArchivoSubido.
     */
    data: XOR<ArchivoSubidoUpdateInput, ArchivoSubidoUncheckedUpdateInput>
    /**
     * Choose, which ArchivoSubido to update.
     */
    where: ArchivoSubidoWhereUniqueInput
  }

  /**
   * ArchivoSubido updateMany
   */
  export type ArchivoSubidoUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update ArchivoSubidos.
     */
    data: XOR<ArchivoSubidoUpdateManyMutationInput, ArchivoSubidoUncheckedUpdateManyInput>
    /**
     * Filter which ArchivoSubidos to update
     */
    where?: ArchivoSubidoWhereInput
    /**
     * Limit how many ArchivoSubidos to update.
     */
    limit?: number
  }

  /**
   * ArchivoSubido upsert
   */
  export type ArchivoSubidoUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ArchivoSubido
     */
    select?: ArchivoSubidoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ArchivoSubido
     */
    omit?: ArchivoSubidoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ArchivoSubidoInclude<ExtArgs> | null
    /**
     * The filter to search for the ArchivoSubido to update in case it exists.
     */
    where: ArchivoSubidoWhereUniqueInput
    /**
     * In case the ArchivoSubido found by the `where` argument doesn't exist, create a new ArchivoSubido with this data.
     */
    create: XOR<ArchivoSubidoCreateInput, ArchivoSubidoUncheckedCreateInput>
    /**
     * In case the ArchivoSubido was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ArchivoSubidoUpdateInput, ArchivoSubidoUncheckedUpdateInput>
  }

  /**
   * ArchivoSubido delete
   */
  export type ArchivoSubidoDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ArchivoSubido
     */
    select?: ArchivoSubidoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ArchivoSubido
     */
    omit?: ArchivoSubidoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ArchivoSubidoInclude<ExtArgs> | null
    /**
     * Filter which ArchivoSubido to delete.
     */
    where: ArchivoSubidoWhereUniqueInput
  }

  /**
   * ArchivoSubido deleteMany
   */
  export type ArchivoSubidoDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which ArchivoSubidos to delete
     */
    where?: ArchivoSubidoWhereInput
    /**
     * Limit how many ArchivoSubidos to delete.
     */
    limit?: number
  }

  /**
   * ArchivoSubido without action
   */
  export type ArchivoSubidoDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ArchivoSubido
     */
    select?: ArchivoSubidoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ArchivoSubido
     */
    omit?: ArchivoSubidoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ArchivoSubidoInclude<ExtArgs> | null
  }


  /**
   * Model Materia
   */

  export type AggregateMateria = {
    _count: MateriaCountAggregateOutputType | null
    _avg: MateriaAvgAggregateOutputType | null
    _sum: MateriaSumAggregateOutputType | null
    _min: MateriaMinAggregateOutputType | null
    _max: MateriaMaxAggregateOutputType | null
  }

  export type MateriaAvgAggregateOutputType = {
    id: number | null
    profesorId: number | null
  }

  export type MateriaSumAggregateOutputType = {
    id: number | null
    profesorId: number | null
  }

  export type MateriaMinAggregateOutputType = {
    id: number | null
    nombre: string | null
    profesorId: number | null
  }

  export type MateriaMaxAggregateOutputType = {
    id: number | null
    nombre: string | null
    profesorId: number | null
  }

  export type MateriaCountAggregateOutputType = {
    id: number
    nombre: number
    profesorId: number
    _all: number
  }


  export type MateriaAvgAggregateInputType = {
    id?: true
    profesorId?: true
  }

  export type MateriaSumAggregateInputType = {
    id?: true
    profesorId?: true
  }

  export type MateriaMinAggregateInputType = {
    id?: true
    nombre?: true
    profesorId?: true
  }

  export type MateriaMaxAggregateInputType = {
    id?: true
    nombre?: true
    profesorId?: true
  }

  export type MateriaCountAggregateInputType = {
    id?: true
    nombre?: true
    profesorId?: true
    _all?: true
  }

  export type MateriaAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Materia to aggregate.
     */
    where?: MateriaWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Materias to fetch.
     */
    orderBy?: MateriaOrderByWithRelationInput | MateriaOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: MateriaWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Materias from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Materias.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Materias
    **/
    _count?: true | MateriaCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: MateriaAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: MateriaSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: MateriaMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: MateriaMaxAggregateInputType
  }

  export type GetMateriaAggregateType<T extends MateriaAggregateArgs> = {
        [P in keyof T & keyof AggregateMateria]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateMateria[P]>
      : GetScalarType<T[P], AggregateMateria[P]>
  }




  export type MateriaGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: MateriaWhereInput
    orderBy?: MateriaOrderByWithAggregationInput | MateriaOrderByWithAggregationInput[]
    by: MateriaScalarFieldEnum[] | MateriaScalarFieldEnum
    having?: MateriaScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: MateriaCountAggregateInputType | true
    _avg?: MateriaAvgAggregateInputType
    _sum?: MateriaSumAggregateInputType
    _min?: MateriaMinAggregateInputType
    _max?: MateriaMaxAggregateInputType
  }

  export type MateriaGroupByOutputType = {
    id: number
    nombre: string
    profesorId: number
    _count: MateriaCountAggregateOutputType | null
    _avg: MateriaAvgAggregateOutputType | null
    _sum: MateriaSumAggregateOutputType | null
    _min: MateriaMinAggregateOutputType | null
    _max: MateriaMaxAggregateOutputType | null
  }

  type GetMateriaGroupByPayload<T extends MateriaGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<MateriaGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof MateriaGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], MateriaGroupByOutputType[P]>
            : GetScalarType<T[P], MateriaGroupByOutputType[P]>
        }
      >
    >


  export type MateriaSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    nombre?: boolean
    profesorId?: boolean
    profesor?: boolean | ProfesorDefaultArgs<ExtArgs>
    Calificacion?: boolean | Materia$CalificacionArgs<ExtArgs>
    Asistencia?: boolean | Materia$AsistenciaArgs<ExtArgs>
    _count?: boolean | MateriaCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["materia"]>



  export type MateriaSelectScalar = {
    id?: boolean
    nombre?: boolean
    profesorId?: boolean
  }

  export type MateriaOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "nombre" | "profesorId", ExtArgs["result"]["materia"]>
  export type MateriaInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    profesor?: boolean | ProfesorDefaultArgs<ExtArgs>
    Calificacion?: boolean | Materia$CalificacionArgs<ExtArgs>
    Asistencia?: boolean | Materia$AsistenciaArgs<ExtArgs>
    _count?: boolean | MateriaCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $MateriaPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Materia"
    objects: {
      profesor: Prisma.$ProfesorPayload<ExtArgs>
      Calificacion: Prisma.$CalificacionPayload<ExtArgs>[]
      Asistencia: Prisma.$AsistenciaPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      nombre: string
      profesorId: number
    }, ExtArgs["result"]["materia"]>
    composites: {}
  }

  type MateriaGetPayload<S extends boolean | null | undefined | MateriaDefaultArgs> = $Result.GetResult<Prisma.$MateriaPayload, S>

  type MateriaCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<MateriaFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: MateriaCountAggregateInputType | true
    }

  export interface MateriaDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Materia'], meta: { name: 'Materia' } }
    /**
     * Find zero or one Materia that matches the filter.
     * @param {MateriaFindUniqueArgs} args - Arguments to find a Materia
     * @example
     * // Get one Materia
     * const materia = await prisma.materia.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends MateriaFindUniqueArgs>(args: SelectSubset<T, MateriaFindUniqueArgs<ExtArgs>>): Prisma__MateriaClient<$Result.GetResult<Prisma.$MateriaPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Materia that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {MateriaFindUniqueOrThrowArgs} args - Arguments to find a Materia
     * @example
     * // Get one Materia
     * const materia = await prisma.materia.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends MateriaFindUniqueOrThrowArgs>(args: SelectSubset<T, MateriaFindUniqueOrThrowArgs<ExtArgs>>): Prisma__MateriaClient<$Result.GetResult<Prisma.$MateriaPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Materia that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MateriaFindFirstArgs} args - Arguments to find a Materia
     * @example
     * // Get one Materia
     * const materia = await prisma.materia.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends MateriaFindFirstArgs>(args?: SelectSubset<T, MateriaFindFirstArgs<ExtArgs>>): Prisma__MateriaClient<$Result.GetResult<Prisma.$MateriaPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Materia that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MateriaFindFirstOrThrowArgs} args - Arguments to find a Materia
     * @example
     * // Get one Materia
     * const materia = await prisma.materia.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends MateriaFindFirstOrThrowArgs>(args?: SelectSubset<T, MateriaFindFirstOrThrowArgs<ExtArgs>>): Prisma__MateriaClient<$Result.GetResult<Prisma.$MateriaPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Materias that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MateriaFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Materias
     * const materias = await prisma.materia.findMany()
     * 
     * // Get first 10 Materias
     * const materias = await prisma.materia.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const materiaWithIdOnly = await prisma.materia.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends MateriaFindManyArgs>(args?: SelectSubset<T, MateriaFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MateriaPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Materia.
     * @param {MateriaCreateArgs} args - Arguments to create a Materia.
     * @example
     * // Create one Materia
     * const Materia = await prisma.materia.create({
     *   data: {
     *     // ... data to create a Materia
     *   }
     * })
     * 
     */
    create<T extends MateriaCreateArgs>(args: SelectSubset<T, MateriaCreateArgs<ExtArgs>>): Prisma__MateriaClient<$Result.GetResult<Prisma.$MateriaPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Materias.
     * @param {MateriaCreateManyArgs} args - Arguments to create many Materias.
     * @example
     * // Create many Materias
     * const materia = await prisma.materia.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends MateriaCreateManyArgs>(args?: SelectSubset<T, MateriaCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Materia.
     * @param {MateriaDeleteArgs} args - Arguments to delete one Materia.
     * @example
     * // Delete one Materia
     * const Materia = await prisma.materia.delete({
     *   where: {
     *     // ... filter to delete one Materia
     *   }
     * })
     * 
     */
    delete<T extends MateriaDeleteArgs>(args: SelectSubset<T, MateriaDeleteArgs<ExtArgs>>): Prisma__MateriaClient<$Result.GetResult<Prisma.$MateriaPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Materia.
     * @param {MateriaUpdateArgs} args - Arguments to update one Materia.
     * @example
     * // Update one Materia
     * const materia = await prisma.materia.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends MateriaUpdateArgs>(args: SelectSubset<T, MateriaUpdateArgs<ExtArgs>>): Prisma__MateriaClient<$Result.GetResult<Prisma.$MateriaPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Materias.
     * @param {MateriaDeleteManyArgs} args - Arguments to filter Materias to delete.
     * @example
     * // Delete a few Materias
     * const { count } = await prisma.materia.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends MateriaDeleteManyArgs>(args?: SelectSubset<T, MateriaDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Materias.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MateriaUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Materias
     * const materia = await prisma.materia.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends MateriaUpdateManyArgs>(args: SelectSubset<T, MateriaUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Materia.
     * @param {MateriaUpsertArgs} args - Arguments to update or create a Materia.
     * @example
     * // Update or create a Materia
     * const materia = await prisma.materia.upsert({
     *   create: {
     *     // ... data to create a Materia
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Materia we want to update
     *   }
     * })
     */
    upsert<T extends MateriaUpsertArgs>(args: SelectSubset<T, MateriaUpsertArgs<ExtArgs>>): Prisma__MateriaClient<$Result.GetResult<Prisma.$MateriaPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Materias.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MateriaCountArgs} args - Arguments to filter Materias to count.
     * @example
     * // Count the number of Materias
     * const count = await prisma.materia.count({
     *   where: {
     *     // ... the filter for the Materias we want to count
     *   }
     * })
    **/
    count<T extends MateriaCountArgs>(
      args?: Subset<T, MateriaCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], MateriaCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Materia.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MateriaAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends MateriaAggregateArgs>(args: Subset<T, MateriaAggregateArgs>): Prisma.PrismaPromise<GetMateriaAggregateType<T>>

    /**
     * Group by Materia.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MateriaGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends MateriaGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: MateriaGroupByArgs['orderBy'] }
        : { orderBy?: MateriaGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, MateriaGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetMateriaGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Materia model
   */
  readonly fields: MateriaFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Materia.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__MateriaClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    profesor<T extends ProfesorDefaultArgs<ExtArgs> = {}>(args?: Subset<T, ProfesorDefaultArgs<ExtArgs>>): Prisma__ProfesorClient<$Result.GetResult<Prisma.$ProfesorPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    Calificacion<T extends Materia$CalificacionArgs<ExtArgs> = {}>(args?: Subset<T, Materia$CalificacionArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CalificacionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    Asistencia<T extends Materia$AsistenciaArgs<ExtArgs> = {}>(args?: Subset<T, Materia$AsistenciaArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AsistenciaPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Materia model
   */
  interface MateriaFieldRefs {
    readonly id: FieldRef<"Materia", 'Int'>
    readonly nombre: FieldRef<"Materia", 'String'>
    readonly profesorId: FieldRef<"Materia", 'Int'>
  }
    

  // Custom InputTypes
  /**
   * Materia findUnique
   */
  export type MateriaFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Materia
     */
    select?: MateriaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Materia
     */
    omit?: MateriaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MateriaInclude<ExtArgs> | null
    /**
     * Filter, which Materia to fetch.
     */
    where: MateriaWhereUniqueInput
  }

  /**
   * Materia findUniqueOrThrow
   */
  export type MateriaFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Materia
     */
    select?: MateriaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Materia
     */
    omit?: MateriaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MateriaInclude<ExtArgs> | null
    /**
     * Filter, which Materia to fetch.
     */
    where: MateriaWhereUniqueInput
  }

  /**
   * Materia findFirst
   */
  export type MateriaFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Materia
     */
    select?: MateriaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Materia
     */
    omit?: MateriaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MateriaInclude<ExtArgs> | null
    /**
     * Filter, which Materia to fetch.
     */
    where?: MateriaWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Materias to fetch.
     */
    orderBy?: MateriaOrderByWithRelationInput | MateriaOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Materias.
     */
    cursor?: MateriaWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Materias from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Materias.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Materias.
     */
    distinct?: MateriaScalarFieldEnum | MateriaScalarFieldEnum[]
  }

  /**
   * Materia findFirstOrThrow
   */
  export type MateriaFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Materia
     */
    select?: MateriaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Materia
     */
    omit?: MateriaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MateriaInclude<ExtArgs> | null
    /**
     * Filter, which Materia to fetch.
     */
    where?: MateriaWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Materias to fetch.
     */
    orderBy?: MateriaOrderByWithRelationInput | MateriaOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Materias.
     */
    cursor?: MateriaWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Materias from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Materias.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Materias.
     */
    distinct?: MateriaScalarFieldEnum | MateriaScalarFieldEnum[]
  }

  /**
   * Materia findMany
   */
  export type MateriaFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Materia
     */
    select?: MateriaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Materia
     */
    omit?: MateriaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MateriaInclude<ExtArgs> | null
    /**
     * Filter, which Materias to fetch.
     */
    where?: MateriaWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Materias to fetch.
     */
    orderBy?: MateriaOrderByWithRelationInput | MateriaOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Materias.
     */
    cursor?: MateriaWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Materias from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Materias.
     */
    skip?: number
    distinct?: MateriaScalarFieldEnum | MateriaScalarFieldEnum[]
  }

  /**
   * Materia create
   */
  export type MateriaCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Materia
     */
    select?: MateriaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Materia
     */
    omit?: MateriaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MateriaInclude<ExtArgs> | null
    /**
     * The data needed to create a Materia.
     */
    data: XOR<MateriaCreateInput, MateriaUncheckedCreateInput>
  }

  /**
   * Materia createMany
   */
  export type MateriaCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Materias.
     */
    data: MateriaCreateManyInput | MateriaCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Materia update
   */
  export type MateriaUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Materia
     */
    select?: MateriaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Materia
     */
    omit?: MateriaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MateriaInclude<ExtArgs> | null
    /**
     * The data needed to update a Materia.
     */
    data: XOR<MateriaUpdateInput, MateriaUncheckedUpdateInput>
    /**
     * Choose, which Materia to update.
     */
    where: MateriaWhereUniqueInput
  }

  /**
   * Materia updateMany
   */
  export type MateriaUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Materias.
     */
    data: XOR<MateriaUpdateManyMutationInput, MateriaUncheckedUpdateManyInput>
    /**
     * Filter which Materias to update
     */
    where?: MateriaWhereInput
    /**
     * Limit how many Materias to update.
     */
    limit?: number
  }

  /**
   * Materia upsert
   */
  export type MateriaUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Materia
     */
    select?: MateriaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Materia
     */
    omit?: MateriaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MateriaInclude<ExtArgs> | null
    /**
     * The filter to search for the Materia to update in case it exists.
     */
    where: MateriaWhereUniqueInput
    /**
     * In case the Materia found by the `where` argument doesn't exist, create a new Materia with this data.
     */
    create: XOR<MateriaCreateInput, MateriaUncheckedCreateInput>
    /**
     * In case the Materia was found with the provided `where` argument, update it with this data.
     */
    update: XOR<MateriaUpdateInput, MateriaUncheckedUpdateInput>
  }

  /**
   * Materia delete
   */
  export type MateriaDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Materia
     */
    select?: MateriaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Materia
     */
    omit?: MateriaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MateriaInclude<ExtArgs> | null
    /**
     * Filter which Materia to delete.
     */
    where: MateriaWhereUniqueInput
  }

  /**
   * Materia deleteMany
   */
  export type MateriaDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Materias to delete
     */
    where?: MateriaWhereInput
    /**
     * Limit how many Materias to delete.
     */
    limit?: number
  }

  /**
   * Materia.Calificacion
   */
  export type Materia$CalificacionArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Calificacion
     */
    select?: CalificacionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Calificacion
     */
    omit?: CalificacionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CalificacionInclude<ExtArgs> | null
    where?: CalificacionWhereInput
    orderBy?: CalificacionOrderByWithRelationInput | CalificacionOrderByWithRelationInput[]
    cursor?: CalificacionWhereUniqueInput
    take?: number
    skip?: number
    distinct?: CalificacionScalarFieldEnum | CalificacionScalarFieldEnum[]
  }

  /**
   * Materia.Asistencia
   */
  export type Materia$AsistenciaArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Asistencia
     */
    select?: AsistenciaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Asistencia
     */
    omit?: AsistenciaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AsistenciaInclude<ExtArgs> | null
    where?: AsistenciaWhereInput
    orderBy?: AsistenciaOrderByWithRelationInput | AsistenciaOrderByWithRelationInput[]
    cursor?: AsistenciaWhereUniqueInput
    take?: number
    skip?: number
    distinct?: AsistenciaScalarFieldEnum | AsistenciaScalarFieldEnum[]
  }

  /**
   * Materia without action
   */
  export type MateriaDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Materia
     */
    select?: MateriaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Materia
     */
    omit?: MateriaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MateriaInclude<ExtArgs> | null
  }


  /**
   * Model Calificacion
   */

  export type AggregateCalificacion = {
    _count: CalificacionCountAggregateOutputType | null
    _avg: CalificacionAvgAggregateOutputType | null
    _sum: CalificacionSumAggregateOutputType | null
    _min: CalificacionMinAggregateOutputType | null
    _max: CalificacionMaxAggregateOutputType | null
  }

  export type CalificacionAvgAggregateOutputType = {
    id: number | null
    estudianteId: number | null
    materiaId: number | null
    parcial1: number | null
    parcial2: number | null
    ordinario: number | null
    final: number | null
  }

  export type CalificacionSumAggregateOutputType = {
    id: number | null
    estudianteId: number | null
    materiaId: number | null
    parcial1: number | null
    parcial2: number | null
    ordinario: number | null
    final: number | null
  }

  export type CalificacionMinAggregateOutputType = {
    id: number | null
    estudianteId: number | null
    materiaId: number | null
    parcial1: number | null
    parcial2: number | null
    ordinario: number | null
    final: number | null
    fecha: Date | null
  }

  export type CalificacionMaxAggregateOutputType = {
    id: number | null
    estudianteId: number | null
    materiaId: number | null
    parcial1: number | null
    parcial2: number | null
    ordinario: number | null
    final: number | null
    fecha: Date | null
  }

  export type CalificacionCountAggregateOutputType = {
    id: number
    estudianteId: number
    materiaId: number
    parcial1: number
    parcial2: number
    ordinario: number
    final: number
    fecha: number
    _all: number
  }


  export type CalificacionAvgAggregateInputType = {
    id?: true
    estudianteId?: true
    materiaId?: true
    parcial1?: true
    parcial2?: true
    ordinario?: true
    final?: true
  }

  export type CalificacionSumAggregateInputType = {
    id?: true
    estudianteId?: true
    materiaId?: true
    parcial1?: true
    parcial2?: true
    ordinario?: true
    final?: true
  }

  export type CalificacionMinAggregateInputType = {
    id?: true
    estudianteId?: true
    materiaId?: true
    parcial1?: true
    parcial2?: true
    ordinario?: true
    final?: true
    fecha?: true
  }

  export type CalificacionMaxAggregateInputType = {
    id?: true
    estudianteId?: true
    materiaId?: true
    parcial1?: true
    parcial2?: true
    ordinario?: true
    final?: true
    fecha?: true
  }

  export type CalificacionCountAggregateInputType = {
    id?: true
    estudianteId?: true
    materiaId?: true
    parcial1?: true
    parcial2?: true
    ordinario?: true
    final?: true
    fecha?: true
    _all?: true
  }

  export type CalificacionAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Calificacion to aggregate.
     */
    where?: CalificacionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Calificacions to fetch.
     */
    orderBy?: CalificacionOrderByWithRelationInput | CalificacionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: CalificacionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Calificacions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Calificacions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Calificacions
    **/
    _count?: true | CalificacionCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: CalificacionAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: CalificacionSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: CalificacionMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: CalificacionMaxAggregateInputType
  }

  export type GetCalificacionAggregateType<T extends CalificacionAggregateArgs> = {
        [P in keyof T & keyof AggregateCalificacion]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateCalificacion[P]>
      : GetScalarType<T[P], AggregateCalificacion[P]>
  }




  export type CalificacionGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: CalificacionWhereInput
    orderBy?: CalificacionOrderByWithAggregationInput | CalificacionOrderByWithAggregationInput[]
    by: CalificacionScalarFieldEnum[] | CalificacionScalarFieldEnum
    having?: CalificacionScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: CalificacionCountAggregateInputType | true
    _avg?: CalificacionAvgAggregateInputType
    _sum?: CalificacionSumAggregateInputType
    _min?: CalificacionMinAggregateInputType
    _max?: CalificacionMaxAggregateInputType
  }

  export type CalificacionGroupByOutputType = {
    id: number
    estudianteId: number
    materiaId: number
    parcial1: number
    parcial2: number
    ordinario: number
    final: number
    fecha: Date
    _count: CalificacionCountAggregateOutputType | null
    _avg: CalificacionAvgAggregateOutputType | null
    _sum: CalificacionSumAggregateOutputType | null
    _min: CalificacionMinAggregateOutputType | null
    _max: CalificacionMaxAggregateOutputType | null
  }

  type GetCalificacionGroupByPayload<T extends CalificacionGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<CalificacionGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof CalificacionGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], CalificacionGroupByOutputType[P]>
            : GetScalarType<T[P], CalificacionGroupByOutputType[P]>
        }
      >
    >


  export type CalificacionSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    estudianteId?: boolean
    materiaId?: boolean
    parcial1?: boolean
    parcial2?: boolean
    ordinario?: boolean
    final?: boolean
    fecha?: boolean
    estudiante?: boolean | EstudianteDefaultArgs<ExtArgs>
    materia?: boolean | MateriaDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["calificacion"]>



  export type CalificacionSelectScalar = {
    id?: boolean
    estudianteId?: boolean
    materiaId?: boolean
    parcial1?: boolean
    parcial2?: boolean
    ordinario?: boolean
    final?: boolean
    fecha?: boolean
  }

  export type CalificacionOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "estudianteId" | "materiaId" | "parcial1" | "parcial2" | "ordinario" | "final" | "fecha", ExtArgs["result"]["calificacion"]>
  export type CalificacionInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    estudiante?: boolean | EstudianteDefaultArgs<ExtArgs>
    materia?: boolean | MateriaDefaultArgs<ExtArgs>
  }

  export type $CalificacionPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Calificacion"
    objects: {
      estudiante: Prisma.$EstudiantePayload<ExtArgs>
      materia: Prisma.$MateriaPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      estudianteId: number
      materiaId: number
      parcial1: number
      parcial2: number
      ordinario: number
      final: number
      fecha: Date
    }, ExtArgs["result"]["calificacion"]>
    composites: {}
  }

  type CalificacionGetPayload<S extends boolean | null | undefined | CalificacionDefaultArgs> = $Result.GetResult<Prisma.$CalificacionPayload, S>

  type CalificacionCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<CalificacionFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: CalificacionCountAggregateInputType | true
    }

  export interface CalificacionDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Calificacion'], meta: { name: 'Calificacion' } }
    /**
     * Find zero or one Calificacion that matches the filter.
     * @param {CalificacionFindUniqueArgs} args - Arguments to find a Calificacion
     * @example
     * // Get one Calificacion
     * const calificacion = await prisma.calificacion.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends CalificacionFindUniqueArgs>(args: SelectSubset<T, CalificacionFindUniqueArgs<ExtArgs>>): Prisma__CalificacionClient<$Result.GetResult<Prisma.$CalificacionPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Calificacion that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {CalificacionFindUniqueOrThrowArgs} args - Arguments to find a Calificacion
     * @example
     * // Get one Calificacion
     * const calificacion = await prisma.calificacion.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends CalificacionFindUniqueOrThrowArgs>(args: SelectSubset<T, CalificacionFindUniqueOrThrowArgs<ExtArgs>>): Prisma__CalificacionClient<$Result.GetResult<Prisma.$CalificacionPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Calificacion that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CalificacionFindFirstArgs} args - Arguments to find a Calificacion
     * @example
     * // Get one Calificacion
     * const calificacion = await prisma.calificacion.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends CalificacionFindFirstArgs>(args?: SelectSubset<T, CalificacionFindFirstArgs<ExtArgs>>): Prisma__CalificacionClient<$Result.GetResult<Prisma.$CalificacionPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Calificacion that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CalificacionFindFirstOrThrowArgs} args - Arguments to find a Calificacion
     * @example
     * // Get one Calificacion
     * const calificacion = await prisma.calificacion.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends CalificacionFindFirstOrThrowArgs>(args?: SelectSubset<T, CalificacionFindFirstOrThrowArgs<ExtArgs>>): Prisma__CalificacionClient<$Result.GetResult<Prisma.$CalificacionPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Calificacions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CalificacionFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Calificacions
     * const calificacions = await prisma.calificacion.findMany()
     * 
     * // Get first 10 Calificacions
     * const calificacions = await prisma.calificacion.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const calificacionWithIdOnly = await prisma.calificacion.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends CalificacionFindManyArgs>(args?: SelectSubset<T, CalificacionFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CalificacionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Calificacion.
     * @param {CalificacionCreateArgs} args - Arguments to create a Calificacion.
     * @example
     * // Create one Calificacion
     * const Calificacion = await prisma.calificacion.create({
     *   data: {
     *     // ... data to create a Calificacion
     *   }
     * })
     * 
     */
    create<T extends CalificacionCreateArgs>(args: SelectSubset<T, CalificacionCreateArgs<ExtArgs>>): Prisma__CalificacionClient<$Result.GetResult<Prisma.$CalificacionPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Calificacions.
     * @param {CalificacionCreateManyArgs} args - Arguments to create many Calificacions.
     * @example
     * // Create many Calificacions
     * const calificacion = await prisma.calificacion.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends CalificacionCreateManyArgs>(args?: SelectSubset<T, CalificacionCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Calificacion.
     * @param {CalificacionDeleteArgs} args - Arguments to delete one Calificacion.
     * @example
     * // Delete one Calificacion
     * const Calificacion = await prisma.calificacion.delete({
     *   where: {
     *     // ... filter to delete one Calificacion
     *   }
     * })
     * 
     */
    delete<T extends CalificacionDeleteArgs>(args: SelectSubset<T, CalificacionDeleteArgs<ExtArgs>>): Prisma__CalificacionClient<$Result.GetResult<Prisma.$CalificacionPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Calificacion.
     * @param {CalificacionUpdateArgs} args - Arguments to update one Calificacion.
     * @example
     * // Update one Calificacion
     * const calificacion = await prisma.calificacion.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends CalificacionUpdateArgs>(args: SelectSubset<T, CalificacionUpdateArgs<ExtArgs>>): Prisma__CalificacionClient<$Result.GetResult<Prisma.$CalificacionPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Calificacions.
     * @param {CalificacionDeleteManyArgs} args - Arguments to filter Calificacions to delete.
     * @example
     * // Delete a few Calificacions
     * const { count } = await prisma.calificacion.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends CalificacionDeleteManyArgs>(args?: SelectSubset<T, CalificacionDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Calificacions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CalificacionUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Calificacions
     * const calificacion = await prisma.calificacion.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends CalificacionUpdateManyArgs>(args: SelectSubset<T, CalificacionUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Calificacion.
     * @param {CalificacionUpsertArgs} args - Arguments to update or create a Calificacion.
     * @example
     * // Update or create a Calificacion
     * const calificacion = await prisma.calificacion.upsert({
     *   create: {
     *     // ... data to create a Calificacion
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Calificacion we want to update
     *   }
     * })
     */
    upsert<T extends CalificacionUpsertArgs>(args: SelectSubset<T, CalificacionUpsertArgs<ExtArgs>>): Prisma__CalificacionClient<$Result.GetResult<Prisma.$CalificacionPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Calificacions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CalificacionCountArgs} args - Arguments to filter Calificacions to count.
     * @example
     * // Count the number of Calificacions
     * const count = await prisma.calificacion.count({
     *   where: {
     *     // ... the filter for the Calificacions we want to count
     *   }
     * })
    **/
    count<T extends CalificacionCountArgs>(
      args?: Subset<T, CalificacionCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], CalificacionCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Calificacion.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CalificacionAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends CalificacionAggregateArgs>(args: Subset<T, CalificacionAggregateArgs>): Prisma.PrismaPromise<GetCalificacionAggregateType<T>>

    /**
     * Group by Calificacion.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CalificacionGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends CalificacionGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: CalificacionGroupByArgs['orderBy'] }
        : { orderBy?: CalificacionGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, CalificacionGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetCalificacionGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Calificacion model
   */
  readonly fields: CalificacionFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Calificacion.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__CalificacionClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    estudiante<T extends EstudianteDefaultArgs<ExtArgs> = {}>(args?: Subset<T, EstudianteDefaultArgs<ExtArgs>>): Prisma__EstudianteClient<$Result.GetResult<Prisma.$EstudiantePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    materia<T extends MateriaDefaultArgs<ExtArgs> = {}>(args?: Subset<T, MateriaDefaultArgs<ExtArgs>>): Prisma__MateriaClient<$Result.GetResult<Prisma.$MateriaPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Calificacion model
   */
  interface CalificacionFieldRefs {
    readonly id: FieldRef<"Calificacion", 'Int'>
    readonly estudianteId: FieldRef<"Calificacion", 'Int'>
    readonly materiaId: FieldRef<"Calificacion", 'Int'>
    readonly parcial1: FieldRef<"Calificacion", 'Float'>
    readonly parcial2: FieldRef<"Calificacion", 'Float'>
    readonly ordinario: FieldRef<"Calificacion", 'Float'>
    readonly final: FieldRef<"Calificacion", 'Float'>
    readonly fecha: FieldRef<"Calificacion", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Calificacion findUnique
   */
  export type CalificacionFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Calificacion
     */
    select?: CalificacionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Calificacion
     */
    omit?: CalificacionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CalificacionInclude<ExtArgs> | null
    /**
     * Filter, which Calificacion to fetch.
     */
    where: CalificacionWhereUniqueInput
  }

  /**
   * Calificacion findUniqueOrThrow
   */
  export type CalificacionFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Calificacion
     */
    select?: CalificacionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Calificacion
     */
    omit?: CalificacionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CalificacionInclude<ExtArgs> | null
    /**
     * Filter, which Calificacion to fetch.
     */
    where: CalificacionWhereUniqueInput
  }

  /**
   * Calificacion findFirst
   */
  export type CalificacionFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Calificacion
     */
    select?: CalificacionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Calificacion
     */
    omit?: CalificacionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CalificacionInclude<ExtArgs> | null
    /**
     * Filter, which Calificacion to fetch.
     */
    where?: CalificacionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Calificacions to fetch.
     */
    orderBy?: CalificacionOrderByWithRelationInput | CalificacionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Calificacions.
     */
    cursor?: CalificacionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Calificacions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Calificacions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Calificacions.
     */
    distinct?: CalificacionScalarFieldEnum | CalificacionScalarFieldEnum[]
  }

  /**
   * Calificacion findFirstOrThrow
   */
  export type CalificacionFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Calificacion
     */
    select?: CalificacionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Calificacion
     */
    omit?: CalificacionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CalificacionInclude<ExtArgs> | null
    /**
     * Filter, which Calificacion to fetch.
     */
    where?: CalificacionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Calificacions to fetch.
     */
    orderBy?: CalificacionOrderByWithRelationInput | CalificacionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Calificacions.
     */
    cursor?: CalificacionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Calificacions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Calificacions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Calificacions.
     */
    distinct?: CalificacionScalarFieldEnum | CalificacionScalarFieldEnum[]
  }

  /**
   * Calificacion findMany
   */
  export type CalificacionFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Calificacion
     */
    select?: CalificacionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Calificacion
     */
    omit?: CalificacionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CalificacionInclude<ExtArgs> | null
    /**
     * Filter, which Calificacions to fetch.
     */
    where?: CalificacionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Calificacions to fetch.
     */
    orderBy?: CalificacionOrderByWithRelationInput | CalificacionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Calificacions.
     */
    cursor?: CalificacionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Calificacions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Calificacions.
     */
    skip?: number
    distinct?: CalificacionScalarFieldEnum | CalificacionScalarFieldEnum[]
  }

  /**
   * Calificacion create
   */
  export type CalificacionCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Calificacion
     */
    select?: CalificacionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Calificacion
     */
    omit?: CalificacionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CalificacionInclude<ExtArgs> | null
    /**
     * The data needed to create a Calificacion.
     */
    data: XOR<CalificacionCreateInput, CalificacionUncheckedCreateInput>
  }

  /**
   * Calificacion createMany
   */
  export type CalificacionCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Calificacions.
     */
    data: CalificacionCreateManyInput | CalificacionCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Calificacion update
   */
  export type CalificacionUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Calificacion
     */
    select?: CalificacionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Calificacion
     */
    omit?: CalificacionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CalificacionInclude<ExtArgs> | null
    /**
     * The data needed to update a Calificacion.
     */
    data: XOR<CalificacionUpdateInput, CalificacionUncheckedUpdateInput>
    /**
     * Choose, which Calificacion to update.
     */
    where: CalificacionWhereUniqueInput
  }

  /**
   * Calificacion updateMany
   */
  export type CalificacionUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Calificacions.
     */
    data: XOR<CalificacionUpdateManyMutationInput, CalificacionUncheckedUpdateManyInput>
    /**
     * Filter which Calificacions to update
     */
    where?: CalificacionWhereInput
    /**
     * Limit how many Calificacions to update.
     */
    limit?: number
  }

  /**
   * Calificacion upsert
   */
  export type CalificacionUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Calificacion
     */
    select?: CalificacionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Calificacion
     */
    omit?: CalificacionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CalificacionInclude<ExtArgs> | null
    /**
     * The filter to search for the Calificacion to update in case it exists.
     */
    where: CalificacionWhereUniqueInput
    /**
     * In case the Calificacion found by the `where` argument doesn't exist, create a new Calificacion with this data.
     */
    create: XOR<CalificacionCreateInput, CalificacionUncheckedCreateInput>
    /**
     * In case the Calificacion was found with the provided `where` argument, update it with this data.
     */
    update: XOR<CalificacionUpdateInput, CalificacionUncheckedUpdateInput>
  }

  /**
   * Calificacion delete
   */
  export type CalificacionDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Calificacion
     */
    select?: CalificacionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Calificacion
     */
    omit?: CalificacionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CalificacionInclude<ExtArgs> | null
    /**
     * Filter which Calificacion to delete.
     */
    where: CalificacionWhereUniqueInput
  }

  /**
   * Calificacion deleteMany
   */
  export type CalificacionDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Calificacions to delete
     */
    where?: CalificacionWhereInput
    /**
     * Limit how many Calificacions to delete.
     */
    limit?: number
  }

  /**
   * Calificacion without action
   */
  export type CalificacionDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Calificacion
     */
    select?: CalificacionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Calificacion
     */
    omit?: CalificacionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CalificacionInclude<ExtArgs> | null
  }


  /**
   * Model Asistencia
   */

  export type AggregateAsistencia = {
    _count: AsistenciaCountAggregateOutputType | null
    _avg: AsistenciaAvgAggregateOutputType | null
    _sum: AsistenciaSumAggregateOutputType | null
    _min: AsistenciaMinAggregateOutputType | null
    _max: AsistenciaMaxAggregateOutputType | null
  }

  export type AsistenciaAvgAggregateOutputType = {
    id: number | null
    estudianteId: number | null
    materiaId: number | null
    parcial1: number | null
    parcial2: number | null
    final: number | null
  }

  export type AsistenciaSumAggregateOutputType = {
    id: number | null
    estudianteId: number | null
    materiaId: number | null
    parcial1: number | null
    parcial2: number | null
    final: number | null
  }

  export type AsistenciaMinAggregateOutputType = {
    id: number | null
    estudianteId: number | null
    materiaId: number | null
    parcial1: number | null
    parcial2: number | null
    final: number | null
    fecha: Date | null
  }

  export type AsistenciaMaxAggregateOutputType = {
    id: number | null
    estudianteId: number | null
    materiaId: number | null
    parcial1: number | null
    parcial2: number | null
    final: number | null
    fecha: Date | null
  }

  export type AsistenciaCountAggregateOutputType = {
    id: number
    estudianteId: number
    materiaId: number
    parcial1: number
    parcial2: number
    final: number
    fecha: number
    _all: number
  }


  export type AsistenciaAvgAggregateInputType = {
    id?: true
    estudianteId?: true
    materiaId?: true
    parcial1?: true
    parcial2?: true
    final?: true
  }

  export type AsistenciaSumAggregateInputType = {
    id?: true
    estudianteId?: true
    materiaId?: true
    parcial1?: true
    parcial2?: true
    final?: true
  }

  export type AsistenciaMinAggregateInputType = {
    id?: true
    estudianteId?: true
    materiaId?: true
    parcial1?: true
    parcial2?: true
    final?: true
    fecha?: true
  }

  export type AsistenciaMaxAggregateInputType = {
    id?: true
    estudianteId?: true
    materiaId?: true
    parcial1?: true
    parcial2?: true
    final?: true
    fecha?: true
  }

  export type AsistenciaCountAggregateInputType = {
    id?: true
    estudianteId?: true
    materiaId?: true
    parcial1?: true
    parcial2?: true
    final?: true
    fecha?: true
    _all?: true
  }

  export type AsistenciaAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Asistencia to aggregate.
     */
    where?: AsistenciaWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Asistencias to fetch.
     */
    orderBy?: AsistenciaOrderByWithRelationInput | AsistenciaOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: AsistenciaWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Asistencias from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Asistencias.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Asistencias
    **/
    _count?: true | AsistenciaCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: AsistenciaAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: AsistenciaSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: AsistenciaMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: AsistenciaMaxAggregateInputType
  }

  export type GetAsistenciaAggregateType<T extends AsistenciaAggregateArgs> = {
        [P in keyof T & keyof AggregateAsistencia]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateAsistencia[P]>
      : GetScalarType<T[P], AggregateAsistencia[P]>
  }




  export type AsistenciaGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: AsistenciaWhereInput
    orderBy?: AsistenciaOrderByWithAggregationInput | AsistenciaOrderByWithAggregationInput[]
    by: AsistenciaScalarFieldEnum[] | AsistenciaScalarFieldEnum
    having?: AsistenciaScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: AsistenciaCountAggregateInputType | true
    _avg?: AsistenciaAvgAggregateInputType
    _sum?: AsistenciaSumAggregateInputType
    _min?: AsistenciaMinAggregateInputType
    _max?: AsistenciaMaxAggregateInputType
  }

  export type AsistenciaGroupByOutputType = {
    id: number
    estudianteId: number
    materiaId: number
    parcial1: number
    parcial2: number
    final: number
    fecha: Date
    _count: AsistenciaCountAggregateOutputType | null
    _avg: AsistenciaAvgAggregateOutputType | null
    _sum: AsistenciaSumAggregateOutputType | null
    _min: AsistenciaMinAggregateOutputType | null
    _max: AsistenciaMaxAggregateOutputType | null
  }

  type GetAsistenciaGroupByPayload<T extends AsistenciaGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<AsistenciaGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof AsistenciaGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], AsistenciaGroupByOutputType[P]>
            : GetScalarType<T[P], AsistenciaGroupByOutputType[P]>
        }
      >
    >


  export type AsistenciaSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    estudianteId?: boolean
    materiaId?: boolean
    parcial1?: boolean
    parcial2?: boolean
    final?: boolean
    fecha?: boolean
    estudiante?: boolean | EstudianteDefaultArgs<ExtArgs>
    materia?: boolean | MateriaDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["asistencia"]>



  export type AsistenciaSelectScalar = {
    id?: boolean
    estudianteId?: boolean
    materiaId?: boolean
    parcial1?: boolean
    parcial2?: boolean
    final?: boolean
    fecha?: boolean
  }

  export type AsistenciaOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "estudianteId" | "materiaId" | "parcial1" | "parcial2" | "final" | "fecha", ExtArgs["result"]["asistencia"]>
  export type AsistenciaInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    estudiante?: boolean | EstudianteDefaultArgs<ExtArgs>
    materia?: boolean | MateriaDefaultArgs<ExtArgs>
  }

  export type $AsistenciaPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Asistencia"
    objects: {
      estudiante: Prisma.$EstudiantePayload<ExtArgs>
      materia: Prisma.$MateriaPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      estudianteId: number
      materiaId: number
      parcial1: number
      parcial2: number
      final: number
      fecha: Date
    }, ExtArgs["result"]["asistencia"]>
    composites: {}
  }

  type AsistenciaGetPayload<S extends boolean | null | undefined | AsistenciaDefaultArgs> = $Result.GetResult<Prisma.$AsistenciaPayload, S>

  type AsistenciaCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<AsistenciaFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: AsistenciaCountAggregateInputType | true
    }

  export interface AsistenciaDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Asistencia'], meta: { name: 'Asistencia' } }
    /**
     * Find zero or one Asistencia that matches the filter.
     * @param {AsistenciaFindUniqueArgs} args - Arguments to find a Asistencia
     * @example
     * // Get one Asistencia
     * const asistencia = await prisma.asistencia.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends AsistenciaFindUniqueArgs>(args: SelectSubset<T, AsistenciaFindUniqueArgs<ExtArgs>>): Prisma__AsistenciaClient<$Result.GetResult<Prisma.$AsistenciaPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Asistencia that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {AsistenciaFindUniqueOrThrowArgs} args - Arguments to find a Asistencia
     * @example
     * // Get one Asistencia
     * const asistencia = await prisma.asistencia.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends AsistenciaFindUniqueOrThrowArgs>(args: SelectSubset<T, AsistenciaFindUniqueOrThrowArgs<ExtArgs>>): Prisma__AsistenciaClient<$Result.GetResult<Prisma.$AsistenciaPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Asistencia that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AsistenciaFindFirstArgs} args - Arguments to find a Asistencia
     * @example
     * // Get one Asistencia
     * const asistencia = await prisma.asistencia.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends AsistenciaFindFirstArgs>(args?: SelectSubset<T, AsistenciaFindFirstArgs<ExtArgs>>): Prisma__AsistenciaClient<$Result.GetResult<Prisma.$AsistenciaPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Asistencia that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AsistenciaFindFirstOrThrowArgs} args - Arguments to find a Asistencia
     * @example
     * // Get one Asistencia
     * const asistencia = await prisma.asistencia.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends AsistenciaFindFirstOrThrowArgs>(args?: SelectSubset<T, AsistenciaFindFirstOrThrowArgs<ExtArgs>>): Prisma__AsistenciaClient<$Result.GetResult<Prisma.$AsistenciaPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Asistencias that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AsistenciaFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Asistencias
     * const asistencias = await prisma.asistencia.findMany()
     * 
     * // Get first 10 Asistencias
     * const asistencias = await prisma.asistencia.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const asistenciaWithIdOnly = await prisma.asistencia.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends AsistenciaFindManyArgs>(args?: SelectSubset<T, AsistenciaFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AsistenciaPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Asistencia.
     * @param {AsistenciaCreateArgs} args - Arguments to create a Asistencia.
     * @example
     * // Create one Asistencia
     * const Asistencia = await prisma.asistencia.create({
     *   data: {
     *     // ... data to create a Asistencia
     *   }
     * })
     * 
     */
    create<T extends AsistenciaCreateArgs>(args: SelectSubset<T, AsistenciaCreateArgs<ExtArgs>>): Prisma__AsistenciaClient<$Result.GetResult<Prisma.$AsistenciaPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Asistencias.
     * @param {AsistenciaCreateManyArgs} args - Arguments to create many Asistencias.
     * @example
     * // Create many Asistencias
     * const asistencia = await prisma.asistencia.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends AsistenciaCreateManyArgs>(args?: SelectSubset<T, AsistenciaCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Asistencia.
     * @param {AsistenciaDeleteArgs} args - Arguments to delete one Asistencia.
     * @example
     * // Delete one Asistencia
     * const Asistencia = await prisma.asistencia.delete({
     *   where: {
     *     // ... filter to delete one Asistencia
     *   }
     * })
     * 
     */
    delete<T extends AsistenciaDeleteArgs>(args: SelectSubset<T, AsistenciaDeleteArgs<ExtArgs>>): Prisma__AsistenciaClient<$Result.GetResult<Prisma.$AsistenciaPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Asistencia.
     * @param {AsistenciaUpdateArgs} args - Arguments to update one Asistencia.
     * @example
     * // Update one Asistencia
     * const asistencia = await prisma.asistencia.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends AsistenciaUpdateArgs>(args: SelectSubset<T, AsistenciaUpdateArgs<ExtArgs>>): Prisma__AsistenciaClient<$Result.GetResult<Prisma.$AsistenciaPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Asistencias.
     * @param {AsistenciaDeleteManyArgs} args - Arguments to filter Asistencias to delete.
     * @example
     * // Delete a few Asistencias
     * const { count } = await prisma.asistencia.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends AsistenciaDeleteManyArgs>(args?: SelectSubset<T, AsistenciaDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Asistencias.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AsistenciaUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Asistencias
     * const asistencia = await prisma.asistencia.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends AsistenciaUpdateManyArgs>(args: SelectSubset<T, AsistenciaUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Asistencia.
     * @param {AsistenciaUpsertArgs} args - Arguments to update or create a Asistencia.
     * @example
     * // Update or create a Asistencia
     * const asistencia = await prisma.asistencia.upsert({
     *   create: {
     *     // ... data to create a Asistencia
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Asistencia we want to update
     *   }
     * })
     */
    upsert<T extends AsistenciaUpsertArgs>(args: SelectSubset<T, AsistenciaUpsertArgs<ExtArgs>>): Prisma__AsistenciaClient<$Result.GetResult<Prisma.$AsistenciaPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Asistencias.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AsistenciaCountArgs} args - Arguments to filter Asistencias to count.
     * @example
     * // Count the number of Asistencias
     * const count = await prisma.asistencia.count({
     *   where: {
     *     // ... the filter for the Asistencias we want to count
     *   }
     * })
    **/
    count<T extends AsistenciaCountArgs>(
      args?: Subset<T, AsistenciaCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], AsistenciaCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Asistencia.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AsistenciaAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends AsistenciaAggregateArgs>(args: Subset<T, AsistenciaAggregateArgs>): Prisma.PrismaPromise<GetAsistenciaAggregateType<T>>

    /**
     * Group by Asistencia.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AsistenciaGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends AsistenciaGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: AsistenciaGroupByArgs['orderBy'] }
        : { orderBy?: AsistenciaGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, AsistenciaGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetAsistenciaGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Asistencia model
   */
  readonly fields: AsistenciaFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Asistencia.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__AsistenciaClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    estudiante<T extends EstudianteDefaultArgs<ExtArgs> = {}>(args?: Subset<T, EstudianteDefaultArgs<ExtArgs>>): Prisma__EstudianteClient<$Result.GetResult<Prisma.$EstudiantePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    materia<T extends MateriaDefaultArgs<ExtArgs> = {}>(args?: Subset<T, MateriaDefaultArgs<ExtArgs>>): Prisma__MateriaClient<$Result.GetResult<Prisma.$MateriaPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Asistencia model
   */
  interface AsistenciaFieldRefs {
    readonly id: FieldRef<"Asistencia", 'Int'>
    readonly estudianteId: FieldRef<"Asistencia", 'Int'>
    readonly materiaId: FieldRef<"Asistencia", 'Int'>
    readonly parcial1: FieldRef<"Asistencia", 'Int'>
    readonly parcial2: FieldRef<"Asistencia", 'Int'>
    readonly final: FieldRef<"Asistencia", 'Int'>
    readonly fecha: FieldRef<"Asistencia", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Asistencia findUnique
   */
  export type AsistenciaFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Asistencia
     */
    select?: AsistenciaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Asistencia
     */
    omit?: AsistenciaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AsistenciaInclude<ExtArgs> | null
    /**
     * Filter, which Asistencia to fetch.
     */
    where: AsistenciaWhereUniqueInput
  }

  /**
   * Asistencia findUniqueOrThrow
   */
  export type AsistenciaFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Asistencia
     */
    select?: AsistenciaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Asistencia
     */
    omit?: AsistenciaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AsistenciaInclude<ExtArgs> | null
    /**
     * Filter, which Asistencia to fetch.
     */
    where: AsistenciaWhereUniqueInput
  }

  /**
   * Asistencia findFirst
   */
  export type AsistenciaFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Asistencia
     */
    select?: AsistenciaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Asistencia
     */
    omit?: AsistenciaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AsistenciaInclude<ExtArgs> | null
    /**
     * Filter, which Asistencia to fetch.
     */
    where?: AsistenciaWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Asistencias to fetch.
     */
    orderBy?: AsistenciaOrderByWithRelationInput | AsistenciaOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Asistencias.
     */
    cursor?: AsistenciaWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Asistencias from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Asistencias.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Asistencias.
     */
    distinct?: AsistenciaScalarFieldEnum | AsistenciaScalarFieldEnum[]
  }

  /**
   * Asistencia findFirstOrThrow
   */
  export type AsistenciaFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Asistencia
     */
    select?: AsistenciaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Asistencia
     */
    omit?: AsistenciaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AsistenciaInclude<ExtArgs> | null
    /**
     * Filter, which Asistencia to fetch.
     */
    where?: AsistenciaWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Asistencias to fetch.
     */
    orderBy?: AsistenciaOrderByWithRelationInput | AsistenciaOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Asistencias.
     */
    cursor?: AsistenciaWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Asistencias from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Asistencias.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Asistencias.
     */
    distinct?: AsistenciaScalarFieldEnum | AsistenciaScalarFieldEnum[]
  }

  /**
   * Asistencia findMany
   */
  export type AsistenciaFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Asistencia
     */
    select?: AsistenciaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Asistencia
     */
    omit?: AsistenciaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AsistenciaInclude<ExtArgs> | null
    /**
     * Filter, which Asistencias to fetch.
     */
    where?: AsistenciaWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Asistencias to fetch.
     */
    orderBy?: AsistenciaOrderByWithRelationInput | AsistenciaOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Asistencias.
     */
    cursor?: AsistenciaWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Asistencias from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Asistencias.
     */
    skip?: number
    distinct?: AsistenciaScalarFieldEnum | AsistenciaScalarFieldEnum[]
  }

  /**
   * Asistencia create
   */
  export type AsistenciaCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Asistencia
     */
    select?: AsistenciaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Asistencia
     */
    omit?: AsistenciaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AsistenciaInclude<ExtArgs> | null
    /**
     * The data needed to create a Asistencia.
     */
    data: XOR<AsistenciaCreateInput, AsistenciaUncheckedCreateInput>
  }

  /**
   * Asistencia createMany
   */
  export type AsistenciaCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Asistencias.
     */
    data: AsistenciaCreateManyInput | AsistenciaCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Asistencia update
   */
  export type AsistenciaUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Asistencia
     */
    select?: AsistenciaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Asistencia
     */
    omit?: AsistenciaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AsistenciaInclude<ExtArgs> | null
    /**
     * The data needed to update a Asistencia.
     */
    data: XOR<AsistenciaUpdateInput, AsistenciaUncheckedUpdateInput>
    /**
     * Choose, which Asistencia to update.
     */
    where: AsistenciaWhereUniqueInput
  }

  /**
   * Asistencia updateMany
   */
  export type AsistenciaUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Asistencias.
     */
    data: XOR<AsistenciaUpdateManyMutationInput, AsistenciaUncheckedUpdateManyInput>
    /**
     * Filter which Asistencias to update
     */
    where?: AsistenciaWhereInput
    /**
     * Limit how many Asistencias to update.
     */
    limit?: number
  }

  /**
   * Asistencia upsert
   */
  export type AsistenciaUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Asistencia
     */
    select?: AsistenciaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Asistencia
     */
    omit?: AsistenciaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AsistenciaInclude<ExtArgs> | null
    /**
     * The filter to search for the Asistencia to update in case it exists.
     */
    where: AsistenciaWhereUniqueInput
    /**
     * In case the Asistencia found by the `where` argument doesn't exist, create a new Asistencia with this data.
     */
    create: XOR<AsistenciaCreateInput, AsistenciaUncheckedCreateInput>
    /**
     * In case the Asistencia was found with the provided `where` argument, update it with this data.
     */
    update: XOR<AsistenciaUpdateInput, AsistenciaUncheckedUpdateInput>
  }

  /**
   * Asistencia delete
   */
  export type AsistenciaDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Asistencia
     */
    select?: AsistenciaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Asistencia
     */
    omit?: AsistenciaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AsistenciaInclude<ExtArgs> | null
    /**
     * Filter which Asistencia to delete.
     */
    where: AsistenciaWhereUniqueInput
  }

  /**
   * Asistencia deleteMany
   */
  export type AsistenciaDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Asistencias to delete
     */
    where?: AsistenciaWhereInput
    /**
     * Limit how many Asistencias to delete.
     */
    limit?: number
  }

  /**
   * Asistencia without action
   */
  export type AsistenciaDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Asistencia
     */
    select?: AsistenciaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Asistencia
     */
    omit?: AsistenciaOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AsistenciaInclude<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    ReadUncommitted: 'ReadUncommitted',
    ReadCommitted: 'ReadCommitted',
    RepeatableRead: 'RepeatableRead',
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const UsuarioScalarFieldEnum: {
    id: 'id',
    nombre: 'nombre',
    correo: 'correo',
    telefono: 'telefono',
    contrasena: 'contrasena',
    puesto: 'puesto',
    fechaCreacion: 'fechaCreacion'
  };

  export type UsuarioScalarFieldEnum = (typeof UsuarioScalarFieldEnum)[keyof typeof UsuarioScalarFieldEnum]


  export const EstudianteScalarFieldEnum: {
    usuarioId: 'usuarioId',
    grupoId: 'grupoId',
    padreFamiliaId: 'padreFamiliaId',
    estado: 'estado'
  };

  export type EstudianteScalarFieldEnum = (typeof EstudianteScalarFieldEnum)[keyof typeof EstudianteScalarFieldEnum]


  export const ProfesorScalarFieldEnum: {
    usuarioId: 'usuarioId'
  };

  export type ProfesorScalarFieldEnum = (typeof ProfesorScalarFieldEnum)[keyof typeof ProfesorScalarFieldEnum]


  export const PadreFamiliaScalarFieldEnum: {
    usuarioId: 'usuarioId',
    domicilio: 'domicilio'
  };

  export type PadreFamiliaScalarFieldEnum = (typeof PadreFamiliaScalarFieldEnum)[keyof typeof PadreFamiliaScalarFieldEnum]


  export const GrupoScalarFieldEnum: {
    id: 'id',
    nombre: 'nombre',
    grado: 'grado'
  };

  export type GrupoScalarFieldEnum = (typeof GrupoScalarFieldEnum)[keyof typeof GrupoScalarFieldEnum]


  export const TramiteScalarFieldEnum: {
    id: 'id',
    estudianteId: 'estudianteId',
    tipo: 'tipo',
    estado: 'estado',
    fecha: 'fecha'
  };

  export type TramiteScalarFieldEnum = (typeof TramiteScalarFieldEnum)[keyof typeof TramiteScalarFieldEnum]


  export const InscripcionScalarFieldEnum: {
    tramiteId: 'tramiteId',
    grupoId: 'grupoId'
  };

  export type InscripcionScalarFieldEnum = (typeof InscripcionScalarFieldEnum)[keyof typeof InscripcionScalarFieldEnum]


  export const PagoScalarFieldEnum: {
    tramiteId: 'tramiteId',
    concepto: 'concepto',
    monto: 'monto'
  };

  export type PagoScalarFieldEnum = (typeof PagoScalarFieldEnum)[keyof typeof PagoScalarFieldEnum]


  export const ReciboScalarFieldEnum: {
    id: 'id',
    pagoId: 'pagoId',
    monto: 'monto',
    fecha: 'fecha'
  };

  export type ReciboScalarFieldEnum = (typeof ReciboScalarFieldEnum)[keyof typeof ReciboScalarFieldEnum]


  export const MaterialEducativoScalarFieldEnum: {
    id: 'id',
    titulo: 'titulo',
    descripcion: 'descripcion',
    categoria: 'categoria',
    existencia: 'existencia',
    fecha: 'fecha',
    tipoArchivo: 'tipoArchivo',
    profesorId: 'profesorId',
    grupoId: 'grupoId'
  };

  export type MaterialEducativoScalarFieldEnum = (typeof MaterialEducativoScalarFieldEnum)[keyof typeof MaterialEducativoScalarFieldEnum]


  export const ArchivoSubidoScalarFieldEnum: {
    id: 'id',
    materialId: 'materialId',
    nombreArchivo: 'nombreArchivo',
    urlNube: 'urlNube'
  };

  export type ArchivoSubidoScalarFieldEnum = (typeof ArchivoSubidoScalarFieldEnum)[keyof typeof ArchivoSubidoScalarFieldEnum]


  export const MateriaScalarFieldEnum: {
    id: 'id',
    nombre: 'nombre',
    profesorId: 'profesorId'
  };

  export type MateriaScalarFieldEnum = (typeof MateriaScalarFieldEnum)[keyof typeof MateriaScalarFieldEnum]


  export const CalificacionScalarFieldEnum: {
    id: 'id',
    estudianteId: 'estudianteId',
    materiaId: 'materiaId',
    parcial1: 'parcial1',
    parcial2: 'parcial2',
    ordinario: 'ordinario',
    final: 'final',
    fecha: 'fecha'
  };

  export type CalificacionScalarFieldEnum = (typeof CalificacionScalarFieldEnum)[keyof typeof CalificacionScalarFieldEnum]


  export const AsistenciaScalarFieldEnum: {
    id: 'id',
    estudianteId: 'estudianteId',
    materiaId: 'materiaId',
    parcial1: 'parcial1',
    parcial2: 'parcial2',
    final: 'final',
    fecha: 'fecha'
  };

  export type AsistenciaScalarFieldEnum = (typeof AsistenciaScalarFieldEnum)[keyof typeof AsistenciaScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const UsuarioOrderByRelevanceFieldEnum: {
    nombre: 'nombre',
    correo: 'correo',
    telefono: 'telefono',
    contrasena: 'contrasena'
  };

  export type UsuarioOrderByRelevanceFieldEnum = (typeof UsuarioOrderByRelevanceFieldEnum)[keyof typeof UsuarioOrderByRelevanceFieldEnum]


  export const NullsOrder: {
    first: 'first',
    last: 'last'
  };

  export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder]


  export const PadreFamiliaOrderByRelevanceFieldEnum: {
    domicilio: 'domicilio'
  };

  export type PadreFamiliaOrderByRelevanceFieldEnum = (typeof PadreFamiliaOrderByRelevanceFieldEnum)[keyof typeof PadreFamiliaOrderByRelevanceFieldEnum]


  export const GrupoOrderByRelevanceFieldEnum: {
    nombre: 'nombre'
  };

  export type GrupoOrderByRelevanceFieldEnum = (typeof GrupoOrderByRelevanceFieldEnum)[keyof typeof GrupoOrderByRelevanceFieldEnum]


  export const PagoOrderByRelevanceFieldEnum: {
    concepto: 'concepto'
  };

  export type PagoOrderByRelevanceFieldEnum = (typeof PagoOrderByRelevanceFieldEnum)[keyof typeof PagoOrderByRelevanceFieldEnum]


  export const MaterialEducativoOrderByRelevanceFieldEnum: {
    titulo: 'titulo',
    descripcion: 'descripcion',
    categoria: 'categoria',
    tipoArchivo: 'tipoArchivo'
  };

  export type MaterialEducativoOrderByRelevanceFieldEnum = (typeof MaterialEducativoOrderByRelevanceFieldEnum)[keyof typeof MaterialEducativoOrderByRelevanceFieldEnum]


  export const ArchivoSubidoOrderByRelevanceFieldEnum: {
    nombreArchivo: 'nombreArchivo',
    urlNube: 'urlNube'
  };

  export type ArchivoSubidoOrderByRelevanceFieldEnum = (typeof ArchivoSubidoOrderByRelevanceFieldEnum)[keyof typeof ArchivoSubidoOrderByRelevanceFieldEnum]


  export const MateriaOrderByRelevanceFieldEnum: {
    nombre: 'nombre'
  };

  export type MateriaOrderByRelevanceFieldEnum = (typeof MateriaOrderByRelevanceFieldEnum)[keyof typeof MateriaOrderByRelevanceFieldEnum]


  /**
   * Field references
   */


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'RolUsuario'
   */
  export type EnumRolUsuarioFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'RolUsuario'>
    


  /**
   * Reference to a field of type 'DateTime'
   */
  export type DateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime'>
    


  /**
   * Reference to a field of type 'EstadoEstudiante'
   */
  export type EnumEstadoEstudianteFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'EstadoEstudiante'>
    


  /**
   * Reference to a field of type 'TipoTramite'
   */
  export type EnumTipoTramiteFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'TipoTramite'>
    


  /**
   * Reference to a field of type 'EstadoTramite'
   */
  export type EnumEstadoTramiteFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'EstadoTramite'>
    


  /**
   * Reference to a field of type 'Float'
   */
  export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>
    


  /**
   * Reference to a field of type 'Boolean'
   */
  export type BooleanFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Boolean'>
    
  /**
   * Deep Input Types
   */


  export type UsuarioWhereInput = {
    AND?: UsuarioWhereInput | UsuarioWhereInput[]
    OR?: UsuarioWhereInput[]
    NOT?: UsuarioWhereInput | UsuarioWhereInput[]
    id?: IntFilter<"Usuario"> | number
    nombre?: StringFilter<"Usuario"> | string
    correo?: StringFilter<"Usuario"> | string
    telefono?: StringFilter<"Usuario"> | string
    contrasena?: StringFilter<"Usuario"> | string
    puesto?: EnumRolUsuarioFilter<"Usuario"> | $Enums.RolUsuario
    fechaCreacion?: DateTimeFilter<"Usuario"> | Date | string
    Estudiante?: XOR<EstudianteNullableScalarRelationFilter, EstudianteWhereInput> | null
    Profesor?: XOR<ProfesorNullableScalarRelationFilter, ProfesorWhereInput> | null
    PadreFamilia?: PadreFamiliaListRelationFilter
  }

  export type UsuarioOrderByWithRelationInput = {
    id?: SortOrder
    nombre?: SortOrder
    correo?: SortOrder
    telefono?: SortOrder
    contrasena?: SortOrder
    puesto?: SortOrder
    fechaCreacion?: SortOrder
    Estudiante?: EstudianteOrderByWithRelationInput
    Profesor?: ProfesorOrderByWithRelationInput
    PadreFamilia?: PadreFamiliaOrderByRelationAggregateInput
    _relevance?: UsuarioOrderByRelevanceInput
  }

  export type UsuarioWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    correo?: string
    AND?: UsuarioWhereInput | UsuarioWhereInput[]
    OR?: UsuarioWhereInput[]
    NOT?: UsuarioWhereInput | UsuarioWhereInput[]
    nombre?: StringFilter<"Usuario"> | string
    telefono?: StringFilter<"Usuario"> | string
    contrasena?: StringFilter<"Usuario"> | string
    puesto?: EnumRolUsuarioFilter<"Usuario"> | $Enums.RolUsuario
    fechaCreacion?: DateTimeFilter<"Usuario"> | Date | string
    Estudiante?: XOR<EstudianteNullableScalarRelationFilter, EstudianteWhereInput> | null
    Profesor?: XOR<ProfesorNullableScalarRelationFilter, ProfesorWhereInput> | null
    PadreFamilia?: PadreFamiliaListRelationFilter
  }, "id" | "correo">

  export type UsuarioOrderByWithAggregationInput = {
    id?: SortOrder
    nombre?: SortOrder
    correo?: SortOrder
    telefono?: SortOrder
    contrasena?: SortOrder
    puesto?: SortOrder
    fechaCreacion?: SortOrder
    _count?: UsuarioCountOrderByAggregateInput
    _avg?: UsuarioAvgOrderByAggregateInput
    _max?: UsuarioMaxOrderByAggregateInput
    _min?: UsuarioMinOrderByAggregateInput
    _sum?: UsuarioSumOrderByAggregateInput
  }

  export type UsuarioScalarWhereWithAggregatesInput = {
    AND?: UsuarioScalarWhereWithAggregatesInput | UsuarioScalarWhereWithAggregatesInput[]
    OR?: UsuarioScalarWhereWithAggregatesInput[]
    NOT?: UsuarioScalarWhereWithAggregatesInput | UsuarioScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"Usuario"> | number
    nombre?: StringWithAggregatesFilter<"Usuario"> | string
    correo?: StringWithAggregatesFilter<"Usuario"> | string
    telefono?: StringWithAggregatesFilter<"Usuario"> | string
    contrasena?: StringWithAggregatesFilter<"Usuario"> | string
    puesto?: EnumRolUsuarioWithAggregatesFilter<"Usuario"> | $Enums.RolUsuario
    fechaCreacion?: DateTimeWithAggregatesFilter<"Usuario"> | Date | string
  }

  export type EstudianteWhereInput = {
    AND?: EstudianteWhereInput | EstudianteWhereInput[]
    OR?: EstudianteWhereInput[]
    NOT?: EstudianteWhereInput | EstudianteWhereInput[]
    usuarioId?: IntFilter<"Estudiante"> | number
    grupoId?: IntNullableFilter<"Estudiante"> | number | null
    padreFamiliaId?: IntNullableFilter<"Estudiante"> | number | null
    estado?: EnumEstadoEstudianteFilter<"Estudiante"> | $Enums.EstadoEstudiante
    tramites?: TramiteListRelationFilter
    grupo?: XOR<GrupoNullableScalarRelationFilter, GrupoWhereInput> | null
    usuario?: XOR<UsuarioScalarRelationFilter, UsuarioWhereInput>
    PadreFamilia?: XOR<PadreFamiliaNullableScalarRelationFilter, PadreFamiliaWhereInput> | null
    Calificacion?: CalificacionListRelationFilter
    Asistencia?: AsistenciaListRelationFilter
  }

  export type EstudianteOrderByWithRelationInput = {
    usuarioId?: SortOrder
    grupoId?: SortOrderInput | SortOrder
    padreFamiliaId?: SortOrderInput | SortOrder
    estado?: SortOrder
    tramites?: TramiteOrderByRelationAggregateInput
    grupo?: GrupoOrderByWithRelationInput
    usuario?: UsuarioOrderByWithRelationInput
    PadreFamilia?: PadreFamiliaOrderByWithRelationInput
    Calificacion?: CalificacionOrderByRelationAggregateInput
    Asistencia?: AsistenciaOrderByRelationAggregateInput
  }

  export type EstudianteWhereUniqueInput = Prisma.AtLeast<{
    usuarioId?: number
    AND?: EstudianteWhereInput | EstudianteWhereInput[]
    OR?: EstudianteWhereInput[]
    NOT?: EstudianteWhereInput | EstudianteWhereInput[]
    grupoId?: IntNullableFilter<"Estudiante"> | number | null
    padreFamiliaId?: IntNullableFilter<"Estudiante"> | number | null
    estado?: EnumEstadoEstudianteFilter<"Estudiante"> | $Enums.EstadoEstudiante
    tramites?: TramiteListRelationFilter
    grupo?: XOR<GrupoNullableScalarRelationFilter, GrupoWhereInput> | null
    usuario?: XOR<UsuarioScalarRelationFilter, UsuarioWhereInput>
    PadreFamilia?: XOR<PadreFamiliaNullableScalarRelationFilter, PadreFamiliaWhereInput> | null
    Calificacion?: CalificacionListRelationFilter
    Asistencia?: AsistenciaListRelationFilter
  }, "usuarioId">

  export type EstudianteOrderByWithAggregationInput = {
    usuarioId?: SortOrder
    grupoId?: SortOrderInput | SortOrder
    padreFamiliaId?: SortOrderInput | SortOrder
    estado?: SortOrder
    _count?: EstudianteCountOrderByAggregateInput
    _avg?: EstudianteAvgOrderByAggregateInput
    _max?: EstudianteMaxOrderByAggregateInput
    _min?: EstudianteMinOrderByAggregateInput
    _sum?: EstudianteSumOrderByAggregateInput
  }

  export type EstudianteScalarWhereWithAggregatesInput = {
    AND?: EstudianteScalarWhereWithAggregatesInput | EstudianteScalarWhereWithAggregatesInput[]
    OR?: EstudianteScalarWhereWithAggregatesInput[]
    NOT?: EstudianteScalarWhereWithAggregatesInput | EstudianteScalarWhereWithAggregatesInput[]
    usuarioId?: IntWithAggregatesFilter<"Estudiante"> | number
    grupoId?: IntNullableWithAggregatesFilter<"Estudiante"> | number | null
    padreFamiliaId?: IntNullableWithAggregatesFilter<"Estudiante"> | number | null
    estado?: EnumEstadoEstudianteWithAggregatesFilter<"Estudiante"> | $Enums.EstadoEstudiante
  }

  export type ProfesorWhereInput = {
    AND?: ProfesorWhereInput | ProfesorWhereInput[]
    OR?: ProfesorWhereInput[]
    NOT?: ProfesorWhereInput | ProfesorWhereInput[]
    usuarioId?: IntFilter<"Profesor"> | number
    usuario?: XOR<UsuarioScalarRelationFilter, UsuarioWhereInput>
    materiales?: MaterialEducativoListRelationFilter
    Materia?: MateriaListRelationFilter
  }

  export type ProfesorOrderByWithRelationInput = {
    usuarioId?: SortOrder
    usuario?: UsuarioOrderByWithRelationInput
    materiales?: MaterialEducativoOrderByRelationAggregateInput
    Materia?: MateriaOrderByRelationAggregateInput
  }

  export type ProfesorWhereUniqueInput = Prisma.AtLeast<{
    usuarioId?: number
    AND?: ProfesorWhereInput | ProfesorWhereInput[]
    OR?: ProfesorWhereInput[]
    NOT?: ProfesorWhereInput | ProfesorWhereInput[]
    usuario?: XOR<UsuarioScalarRelationFilter, UsuarioWhereInput>
    materiales?: MaterialEducativoListRelationFilter
    Materia?: MateriaListRelationFilter
  }, "usuarioId">

  export type ProfesorOrderByWithAggregationInput = {
    usuarioId?: SortOrder
    _count?: ProfesorCountOrderByAggregateInput
    _avg?: ProfesorAvgOrderByAggregateInput
    _max?: ProfesorMaxOrderByAggregateInput
    _min?: ProfesorMinOrderByAggregateInput
    _sum?: ProfesorSumOrderByAggregateInput
  }

  export type ProfesorScalarWhereWithAggregatesInput = {
    AND?: ProfesorScalarWhereWithAggregatesInput | ProfesorScalarWhereWithAggregatesInput[]
    OR?: ProfesorScalarWhereWithAggregatesInput[]
    NOT?: ProfesorScalarWhereWithAggregatesInput | ProfesorScalarWhereWithAggregatesInput[]
    usuarioId?: IntWithAggregatesFilter<"Profesor"> | number
  }

  export type PadreFamiliaWhereInput = {
    AND?: PadreFamiliaWhereInput | PadreFamiliaWhereInput[]
    OR?: PadreFamiliaWhereInput[]
    NOT?: PadreFamiliaWhereInput | PadreFamiliaWhereInput[]
    usuarioId?: IntFilter<"PadreFamilia"> | number
    domicilio?: StringFilter<"PadreFamilia"> | string
    usuario?: XOR<UsuarioScalarRelationFilter, UsuarioWhereInput>
    estudiantes?: EstudianteListRelationFilter
  }

  export type PadreFamiliaOrderByWithRelationInput = {
    usuarioId?: SortOrder
    domicilio?: SortOrder
    usuario?: UsuarioOrderByWithRelationInput
    estudiantes?: EstudianteOrderByRelationAggregateInput
    _relevance?: PadreFamiliaOrderByRelevanceInput
  }

  export type PadreFamiliaWhereUniqueInput = Prisma.AtLeast<{
    usuarioId?: number
    AND?: PadreFamiliaWhereInput | PadreFamiliaWhereInput[]
    OR?: PadreFamiliaWhereInput[]
    NOT?: PadreFamiliaWhereInput | PadreFamiliaWhereInput[]
    domicilio?: StringFilter<"PadreFamilia"> | string
    usuario?: XOR<UsuarioScalarRelationFilter, UsuarioWhereInput>
    estudiantes?: EstudianteListRelationFilter
  }, "usuarioId">

  export type PadreFamiliaOrderByWithAggregationInput = {
    usuarioId?: SortOrder
    domicilio?: SortOrder
    _count?: PadreFamiliaCountOrderByAggregateInput
    _avg?: PadreFamiliaAvgOrderByAggregateInput
    _max?: PadreFamiliaMaxOrderByAggregateInput
    _min?: PadreFamiliaMinOrderByAggregateInput
    _sum?: PadreFamiliaSumOrderByAggregateInput
  }

  export type PadreFamiliaScalarWhereWithAggregatesInput = {
    AND?: PadreFamiliaScalarWhereWithAggregatesInput | PadreFamiliaScalarWhereWithAggregatesInput[]
    OR?: PadreFamiliaScalarWhereWithAggregatesInput[]
    NOT?: PadreFamiliaScalarWhereWithAggregatesInput | PadreFamiliaScalarWhereWithAggregatesInput[]
    usuarioId?: IntWithAggregatesFilter<"PadreFamilia"> | number
    domicilio?: StringWithAggregatesFilter<"PadreFamilia"> | string
  }

  export type GrupoWhereInput = {
    AND?: GrupoWhereInput | GrupoWhereInput[]
    OR?: GrupoWhereInput[]
    NOT?: GrupoWhereInput | GrupoWhereInput[]
    id?: IntFilter<"Grupo"> | number
    nombre?: StringFilter<"Grupo"> | string
    grado?: IntFilter<"Grupo"> | number
    estudiantes?: EstudianteListRelationFilter
    inscripciones?: InscripcionListRelationFilter
    materiales?: MaterialEducativoListRelationFilter
  }

  export type GrupoOrderByWithRelationInput = {
    id?: SortOrder
    nombre?: SortOrder
    grado?: SortOrder
    estudiantes?: EstudianteOrderByRelationAggregateInput
    inscripciones?: InscripcionOrderByRelationAggregateInput
    materiales?: MaterialEducativoOrderByRelationAggregateInput
    _relevance?: GrupoOrderByRelevanceInput
  }

  export type GrupoWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: GrupoWhereInput | GrupoWhereInput[]
    OR?: GrupoWhereInput[]
    NOT?: GrupoWhereInput | GrupoWhereInput[]
    nombre?: StringFilter<"Grupo"> | string
    grado?: IntFilter<"Grupo"> | number
    estudiantes?: EstudianteListRelationFilter
    inscripciones?: InscripcionListRelationFilter
    materiales?: MaterialEducativoListRelationFilter
  }, "id">

  export type GrupoOrderByWithAggregationInput = {
    id?: SortOrder
    nombre?: SortOrder
    grado?: SortOrder
    _count?: GrupoCountOrderByAggregateInput
    _avg?: GrupoAvgOrderByAggregateInput
    _max?: GrupoMaxOrderByAggregateInput
    _min?: GrupoMinOrderByAggregateInput
    _sum?: GrupoSumOrderByAggregateInput
  }

  export type GrupoScalarWhereWithAggregatesInput = {
    AND?: GrupoScalarWhereWithAggregatesInput | GrupoScalarWhereWithAggregatesInput[]
    OR?: GrupoScalarWhereWithAggregatesInput[]
    NOT?: GrupoScalarWhereWithAggregatesInput | GrupoScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"Grupo"> | number
    nombre?: StringWithAggregatesFilter<"Grupo"> | string
    grado?: IntWithAggregatesFilter<"Grupo"> | number
  }

  export type TramiteWhereInput = {
    AND?: TramiteWhereInput | TramiteWhereInput[]
    OR?: TramiteWhereInput[]
    NOT?: TramiteWhereInput | TramiteWhereInput[]
    id?: IntFilter<"Tramite"> | number
    estudianteId?: IntFilter<"Tramite"> | number
    tipo?: EnumTipoTramiteFilter<"Tramite"> | $Enums.TipoTramite
    estado?: EnumEstadoTramiteFilter<"Tramite"> | $Enums.EstadoTramite
    fecha?: DateTimeFilter<"Tramite"> | Date | string
    inscripcion?: XOR<InscripcionNullableScalarRelationFilter, InscripcionWhereInput> | null
    Pago?: XOR<PagoNullableScalarRelationFilter, PagoWhereInput> | null
    estudiante?: XOR<EstudianteScalarRelationFilter, EstudianteWhereInput>
  }

  export type TramiteOrderByWithRelationInput = {
    id?: SortOrder
    estudianteId?: SortOrder
    tipo?: SortOrder
    estado?: SortOrder
    fecha?: SortOrder
    inscripcion?: InscripcionOrderByWithRelationInput
    Pago?: PagoOrderByWithRelationInput
    estudiante?: EstudianteOrderByWithRelationInput
  }

  export type TramiteWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: TramiteWhereInput | TramiteWhereInput[]
    OR?: TramiteWhereInput[]
    NOT?: TramiteWhereInput | TramiteWhereInput[]
    estudianteId?: IntFilter<"Tramite"> | number
    tipo?: EnumTipoTramiteFilter<"Tramite"> | $Enums.TipoTramite
    estado?: EnumEstadoTramiteFilter<"Tramite"> | $Enums.EstadoTramite
    fecha?: DateTimeFilter<"Tramite"> | Date | string
    inscripcion?: XOR<InscripcionNullableScalarRelationFilter, InscripcionWhereInput> | null
    Pago?: XOR<PagoNullableScalarRelationFilter, PagoWhereInput> | null
    estudiante?: XOR<EstudianteScalarRelationFilter, EstudianteWhereInput>
  }, "id">

  export type TramiteOrderByWithAggregationInput = {
    id?: SortOrder
    estudianteId?: SortOrder
    tipo?: SortOrder
    estado?: SortOrder
    fecha?: SortOrder
    _count?: TramiteCountOrderByAggregateInput
    _avg?: TramiteAvgOrderByAggregateInput
    _max?: TramiteMaxOrderByAggregateInput
    _min?: TramiteMinOrderByAggregateInput
    _sum?: TramiteSumOrderByAggregateInput
  }

  export type TramiteScalarWhereWithAggregatesInput = {
    AND?: TramiteScalarWhereWithAggregatesInput | TramiteScalarWhereWithAggregatesInput[]
    OR?: TramiteScalarWhereWithAggregatesInput[]
    NOT?: TramiteScalarWhereWithAggregatesInput | TramiteScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"Tramite"> | number
    estudianteId?: IntWithAggregatesFilter<"Tramite"> | number
    tipo?: EnumTipoTramiteWithAggregatesFilter<"Tramite"> | $Enums.TipoTramite
    estado?: EnumEstadoTramiteWithAggregatesFilter<"Tramite"> | $Enums.EstadoTramite
    fecha?: DateTimeWithAggregatesFilter<"Tramite"> | Date | string
  }

  export type InscripcionWhereInput = {
    AND?: InscripcionWhereInput | InscripcionWhereInput[]
    OR?: InscripcionWhereInput[]
    NOT?: InscripcionWhereInput | InscripcionWhereInput[]
    tramiteId?: IntFilter<"Inscripcion"> | number
    grupoId?: IntFilter<"Inscripcion"> | number
    tramite?: XOR<TramiteScalarRelationFilter, TramiteWhereInput>
    grupo?: XOR<GrupoScalarRelationFilter, GrupoWhereInput>
  }

  export type InscripcionOrderByWithRelationInput = {
    tramiteId?: SortOrder
    grupoId?: SortOrder
    tramite?: TramiteOrderByWithRelationInput
    grupo?: GrupoOrderByWithRelationInput
  }

  export type InscripcionWhereUniqueInput = Prisma.AtLeast<{
    tramiteId?: number
    AND?: InscripcionWhereInput | InscripcionWhereInput[]
    OR?: InscripcionWhereInput[]
    NOT?: InscripcionWhereInput | InscripcionWhereInput[]
    grupoId?: IntFilter<"Inscripcion"> | number
    tramite?: XOR<TramiteScalarRelationFilter, TramiteWhereInput>
    grupo?: XOR<GrupoScalarRelationFilter, GrupoWhereInput>
  }, "tramiteId">

  export type InscripcionOrderByWithAggregationInput = {
    tramiteId?: SortOrder
    grupoId?: SortOrder
    _count?: InscripcionCountOrderByAggregateInput
    _avg?: InscripcionAvgOrderByAggregateInput
    _max?: InscripcionMaxOrderByAggregateInput
    _min?: InscripcionMinOrderByAggregateInput
    _sum?: InscripcionSumOrderByAggregateInput
  }

  export type InscripcionScalarWhereWithAggregatesInput = {
    AND?: InscripcionScalarWhereWithAggregatesInput | InscripcionScalarWhereWithAggregatesInput[]
    OR?: InscripcionScalarWhereWithAggregatesInput[]
    NOT?: InscripcionScalarWhereWithAggregatesInput | InscripcionScalarWhereWithAggregatesInput[]
    tramiteId?: IntWithAggregatesFilter<"Inscripcion"> | number
    grupoId?: IntWithAggregatesFilter<"Inscripcion"> | number
  }

  export type PagoWhereInput = {
    AND?: PagoWhereInput | PagoWhereInput[]
    OR?: PagoWhereInput[]
    NOT?: PagoWhereInput | PagoWhereInput[]
    tramiteId?: IntFilter<"Pago"> | number
    concepto?: StringFilter<"Pago"> | string
    monto?: FloatFilter<"Pago"> | number
    recibos?: ReciboListRelationFilter
    tramite?: XOR<TramiteScalarRelationFilter, TramiteWhereInput>
  }

  export type PagoOrderByWithRelationInput = {
    tramiteId?: SortOrder
    concepto?: SortOrder
    monto?: SortOrder
    recibos?: ReciboOrderByRelationAggregateInput
    tramite?: TramiteOrderByWithRelationInput
    _relevance?: PagoOrderByRelevanceInput
  }

  export type PagoWhereUniqueInput = Prisma.AtLeast<{
    tramiteId?: number
    AND?: PagoWhereInput | PagoWhereInput[]
    OR?: PagoWhereInput[]
    NOT?: PagoWhereInput | PagoWhereInput[]
    concepto?: StringFilter<"Pago"> | string
    monto?: FloatFilter<"Pago"> | number
    recibos?: ReciboListRelationFilter
    tramite?: XOR<TramiteScalarRelationFilter, TramiteWhereInput>
  }, "tramiteId">

  export type PagoOrderByWithAggregationInput = {
    tramiteId?: SortOrder
    concepto?: SortOrder
    monto?: SortOrder
    _count?: PagoCountOrderByAggregateInput
    _avg?: PagoAvgOrderByAggregateInput
    _max?: PagoMaxOrderByAggregateInput
    _min?: PagoMinOrderByAggregateInput
    _sum?: PagoSumOrderByAggregateInput
  }

  export type PagoScalarWhereWithAggregatesInput = {
    AND?: PagoScalarWhereWithAggregatesInput | PagoScalarWhereWithAggregatesInput[]
    OR?: PagoScalarWhereWithAggregatesInput[]
    NOT?: PagoScalarWhereWithAggregatesInput | PagoScalarWhereWithAggregatesInput[]
    tramiteId?: IntWithAggregatesFilter<"Pago"> | number
    concepto?: StringWithAggregatesFilter<"Pago"> | string
    monto?: FloatWithAggregatesFilter<"Pago"> | number
  }

  export type ReciboWhereInput = {
    AND?: ReciboWhereInput | ReciboWhereInput[]
    OR?: ReciboWhereInput[]
    NOT?: ReciboWhereInput | ReciboWhereInput[]
    id?: IntFilter<"Recibo"> | number
    pagoId?: IntFilter<"Recibo"> | number
    monto?: FloatFilter<"Recibo"> | number
    fecha?: DateTimeFilter<"Recibo"> | Date | string
    pago?: XOR<PagoScalarRelationFilter, PagoWhereInput>
  }

  export type ReciboOrderByWithRelationInput = {
    id?: SortOrder
    pagoId?: SortOrder
    monto?: SortOrder
    fecha?: SortOrder
    pago?: PagoOrderByWithRelationInput
  }

  export type ReciboWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: ReciboWhereInput | ReciboWhereInput[]
    OR?: ReciboWhereInput[]
    NOT?: ReciboWhereInput | ReciboWhereInput[]
    pagoId?: IntFilter<"Recibo"> | number
    monto?: FloatFilter<"Recibo"> | number
    fecha?: DateTimeFilter<"Recibo"> | Date | string
    pago?: XOR<PagoScalarRelationFilter, PagoWhereInput>
  }, "id">

  export type ReciboOrderByWithAggregationInput = {
    id?: SortOrder
    pagoId?: SortOrder
    monto?: SortOrder
    fecha?: SortOrder
    _count?: ReciboCountOrderByAggregateInput
    _avg?: ReciboAvgOrderByAggregateInput
    _max?: ReciboMaxOrderByAggregateInput
    _min?: ReciboMinOrderByAggregateInput
    _sum?: ReciboSumOrderByAggregateInput
  }

  export type ReciboScalarWhereWithAggregatesInput = {
    AND?: ReciboScalarWhereWithAggregatesInput | ReciboScalarWhereWithAggregatesInput[]
    OR?: ReciboScalarWhereWithAggregatesInput[]
    NOT?: ReciboScalarWhereWithAggregatesInput | ReciboScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"Recibo"> | number
    pagoId?: IntWithAggregatesFilter<"Recibo"> | number
    monto?: FloatWithAggregatesFilter<"Recibo"> | number
    fecha?: DateTimeWithAggregatesFilter<"Recibo"> | Date | string
  }

  export type MaterialEducativoWhereInput = {
    AND?: MaterialEducativoWhereInput | MaterialEducativoWhereInput[]
    OR?: MaterialEducativoWhereInput[]
    NOT?: MaterialEducativoWhereInput | MaterialEducativoWhereInput[]
    id?: IntFilter<"MaterialEducativo"> | number
    titulo?: StringFilter<"MaterialEducativo"> | string
    descripcion?: StringFilter<"MaterialEducativo"> | string
    categoria?: StringFilter<"MaterialEducativo"> | string
    existencia?: BoolFilter<"MaterialEducativo"> | boolean
    fecha?: DateTimeFilter<"MaterialEducativo"> | Date | string
    tipoArchivo?: StringFilter<"MaterialEducativo"> | string
    profesorId?: IntFilter<"MaterialEducativo"> | number
    grupoId?: IntFilter<"MaterialEducativo"> | number
    profesor?: XOR<ProfesorScalarRelationFilter, ProfesorWhereInput>
    grupo?: XOR<GrupoScalarRelationFilter, GrupoWhereInput>
    archivo?: ArchivoSubidoListRelationFilter
  }

  export type MaterialEducativoOrderByWithRelationInput = {
    id?: SortOrder
    titulo?: SortOrder
    descripcion?: SortOrder
    categoria?: SortOrder
    existencia?: SortOrder
    fecha?: SortOrder
    tipoArchivo?: SortOrder
    profesorId?: SortOrder
    grupoId?: SortOrder
    profesor?: ProfesorOrderByWithRelationInput
    grupo?: GrupoOrderByWithRelationInput
    archivo?: ArchivoSubidoOrderByRelationAggregateInput
    _relevance?: MaterialEducativoOrderByRelevanceInput
  }

  export type MaterialEducativoWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: MaterialEducativoWhereInput | MaterialEducativoWhereInput[]
    OR?: MaterialEducativoWhereInput[]
    NOT?: MaterialEducativoWhereInput | MaterialEducativoWhereInput[]
    titulo?: StringFilter<"MaterialEducativo"> | string
    descripcion?: StringFilter<"MaterialEducativo"> | string
    categoria?: StringFilter<"MaterialEducativo"> | string
    existencia?: BoolFilter<"MaterialEducativo"> | boolean
    fecha?: DateTimeFilter<"MaterialEducativo"> | Date | string
    tipoArchivo?: StringFilter<"MaterialEducativo"> | string
    profesorId?: IntFilter<"MaterialEducativo"> | number
    grupoId?: IntFilter<"MaterialEducativo"> | number
    profesor?: XOR<ProfesorScalarRelationFilter, ProfesorWhereInput>
    grupo?: XOR<GrupoScalarRelationFilter, GrupoWhereInput>
    archivo?: ArchivoSubidoListRelationFilter
  }, "id">

  export type MaterialEducativoOrderByWithAggregationInput = {
    id?: SortOrder
    titulo?: SortOrder
    descripcion?: SortOrder
    categoria?: SortOrder
    existencia?: SortOrder
    fecha?: SortOrder
    tipoArchivo?: SortOrder
    profesorId?: SortOrder
    grupoId?: SortOrder
    _count?: MaterialEducativoCountOrderByAggregateInput
    _avg?: MaterialEducativoAvgOrderByAggregateInput
    _max?: MaterialEducativoMaxOrderByAggregateInput
    _min?: MaterialEducativoMinOrderByAggregateInput
    _sum?: MaterialEducativoSumOrderByAggregateInput
  }

  export type MaterialEducativoScalarWhereWithAggregatesInput = {
    AND?: MaterialEducativoScalarWhereWithAggregatesInput | MaterialEducativoScalarWhereWithAggregatesInput[]
    OR?: MaterialEducativoScalarWhereWithAggregatesInput[]
    NOT?: MaterialEducativoScalarWhereWithAggregatesInput | MaterialEducativoScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"MaterialEducativo"> | number
    titulo?: StringWithAggregatesFilter<"MaterialEducativo"> | string
    descripcion?: StringWithAggregatesFilter<"MaterialEducativo"> | string
    categoria?: StringWithAggregatesFilter<"MaterialEducativo"> | string
    existencia?: BoolWithAggregatesFilter<"MaterialEducativo"> | boolean
    fecha?: DateTimeWithAggregatesFilter<"MaterialEducativo"> | Date | string
    tipoArchivo?: StringWithAggregatesFilter<"MaterialEducativo"> | string
    profesorId?: IntWithAggregatesFilter<"MaterialEducativo"> | number
    grupoId?: IntWithAggregatesFilter<"MaterialEducativo"> | number
  }

  export type ArchivoSubidoWhereInput = {
    AND?: ArchivoSubidoWhereInput | ArchivoSubidoWhereInput[]
    OR?: ArchivoSubidoWhereInput[]
    NOT?: ArchivoSubidoWhereInput | ArchivoSubidoWhereInput[]
    id?: IntFilter<"ArchivoSubido"> | number
    materialId?: IntFilter<"ArchivoSubido"> | number
    nombreArchivo?: StringFilter<"ArchivoSubido"> | string
    urlNube?: StringFilter<"ArchivoSubido"> | string
    material?: XOR<MaterialEducativoScalarRelationFilter, MaterialEducativoWhereInput>
  }

  export type ArchivoSubidoOrderByWithRelationInput = {
    id?: SortOrder
    materialId?: SortOrder
    nombreArchivo?: SortOrder
    urlNube?: SortOrder
    material?: MaterialEducativoOrderByWithRelationInput
    _relevance?: ArchivoSubidoOrderByRelevanceInput
  }

  export type ArchivoSubidoWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: ArchivoSubidoWhereInput | ArchivoSubidoWhereInput[]
    OR?: ArchivoSubidoWhereInput[]
    NOT?: ArchivoSubidoWhereInput | ArchivoSubidoWhereInput[]
    materialId?: IntFilter<"ArchivoSubido"> | number
    nombreArchivo?: StringFilter<"ArchivoSubido"> | string
    urlNube?: StringFilter<"ArchivoSubido"> | string
    material?: XOR<MaterialEducativoScalarRelationFilter, MaterialEducativoWhereInput>
  }, "id">

  export type ArchivoSubidoOrderByWithAggregationInput = {
    id?: SortOrder
    materialId?: SortOrder
    nombreArchivo?: SortOrder
    urlNube?: SortOrder
    _count?: ArchivoSubidoCountOrderByAggregateInput
    _avg?: ArchivoSubidoAvgOrderByAggregateInput
    _max?: ArchivoSubidoMaxOrderByAggregateInput
    _min?: ArchivoSubidoMinOrderByAggregateInput
    _sum?: ArchivoSubidoSumOrderByAggregateInput
  }

  export type ArchivoSubidoScalarWhereWithAggregatesInput = {
    AND?: ArchivoSubidoScalarWhereWithAggregatesInput | ArchivoSubidoScalarWhereWithAggregatesInput[]
    OR?: ArchivoSubidoScalarWhereWithAggregatesInput[]
    NOT?: ArchivoSubidoScalarWhereWithAggregatesInput | ArchivoSubidoScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"ArchivoSubido"> | number
    materialId?: IntWithAggregatesFilter<"ArchivoSubido"> | number
    nombreArchivo?: StringWithAggregatesFilter<"ArchivoSubido"> | string
    urlNube?: StringWithAggregatesFilter<"ArchivoSubido"> | string
  }

  export type MateriaWhereInput = {
    AND?: MateriaWhereInput | MateriaWhereInput[]
    OR?: MateriaWhereInput[]
    NOT?: MateriaWhereInput | MateriaWhereInput[]
    id?: IntFilter<"Materia"> | number
    nombre?: StringFilter<"Materia"> | string
    profesorId?: IntFilter<"Materia"> | number
    profesor?: XOR<ProfesorScalarRelationFilter, ProfesorWhereInput>
    Calificacion?: CalificacionListRelationFilter
    Asistencia?: AsistenciaListRelationFilter
  }

  export type MateriaOrderByWithRelationInput = {
    id?: SortOrder
    nombre?: SortOrder
    profesorId?: SortOrder
    profesor?: ProfesorOrderByWithRelationInput
    Calificacion?: CalificacionOrderByRelationAggregateInput
    Asistencia?: AsistenciaOrderByRelationAggregateInput
    _relevance?: MateriaOrderByRelevanceInput
  }

  export type MateriaWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: MateriaWhereInput | MateriaWhereInput[]
    OR?: MateriaWhereInput[]
    NOT?: MateriaWhereInput | MateriaWhereInput[]
    nombre?: StringFilter<"Materia"> | string
    profesorId?: IntFilter<"Materia"> | number
    profesor?: XOR<ProfesorScalarRelationFilter, ProfesorWhereInput>
    Calificacion?: CalificacionListRelationFilter
    Asistencia?: AsistenciaListRelationFilter
  }, "id">

  export type MateriaOrderByWithAggregationInput = {
    id?: SortOrder
    nombre?: SortOrder
    profesorId?: SortOrder
    _count?: MateriaCountOrderByAggregateInput
    _avg?: MateriaAvgOrderByAggregateInput
    _max?: MateriaMaxOrderByAggregateInput
    _min?: MateriaMinOrderByAggregateInput
    _sum?: MateriaSumOrderByAggregateInput
  }

  export type MateriaScalarWhereWithAggregatesInput = {
    AND?: MateriaScalarWhereWithAggregatesInput | MateriaScalarWhereWithAggregatesInput[]
    OR?: MateriaScalarWhereWithAggregatesInput[]
    NOT?: MateriaScalarWhereWithAggregatesInput | MateriaScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"Materia"> | number
    nombre?: StringWithAggregatesFilter<"Materia"> | string
    profesorId?: IntWithAggregatesFilter<"Materia"> | number
  }

  export type CalificacionWhereInput = {
    AND?: CalificacionWhereInput | CalificacionWhereInput[]
    OR?: CalificacionWhereInput[]
    NOT?: CalificacionWhereInput | CalificacionWhereInput[]
    id?: IntFilter<"Calificacion"> | number
    estudianteId?: IntFilter<"Calificacion"> | number
    materiaId?: IntFilter<"Calificacion"> | number
    parcial1?: FloatFilter<"Calificacion"> | number
    parcial2?: FloatFilter<"Calificacion"> | number
    ordinario?: FloatFilter<"Calificacion"> | number
    final?: FloatFilter<"Calificacion"> | number
    fecha?: DateTimeFilter<"Calificacion"> | Date | string
    estudiante?: XOR<EstudianteScalarRelationFilter, EstudianteWhereInput>
    materia?: XOR<MateriaScalarRelationFilter, MateriaWhereInput>
  }

  export type CalificacionOrderByWithRelationInput = {
    id?: SortOrder
    estudianteId?: SortOrder
    materiaId?: SortOrder
    parcial1?: SortOrder
    parcial2?: SortOrder
    ordinario?: SortOrder
    final?: SortOrder
    fecha?: SortOrder
    estudiante?: EstudianteOrderByWithRelationInput
    materia?: MateriaOrderByWithRelationInput
  }

  export type CalificacionWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: CalificacionWhereInput | CalificacionWhereInput[]
    OR?: CalificacionWhereInput[]
    NOT?: CalificacionWhereInput | CalificacionWhereInput[]
    estudianteId?: IntFilter<"Calificacion"> | number
    materiaId?: IntFilter<"Calificacion"> | number
    parcial1?: FloatFilter<"Calificacion"> | number
    parcial2?: FloatFilter<"Calificacion"> | number
    ordinario?: FloatFilter<"Calificacion"> | number
    final?: FloatFilter<"Calificacion"> | number
    fecha?: DateTimeFilter<"Calificacion"> | Date | string
    estudiante?: XOR<EstudianteScalarRelationFilter, EstudianteWhereInput>
    materia?: XOR<MateriaScalarRelationFilter, MateriaWhereInput>
  }, "id">

  export type CalificacionOrderByWithAggregationInput = {
    id?: SortOrder
    estudianteId?: SortOrder
    materiaId?: SortOrder
    parcial1?: SortOrder
    parcial2?: SortOrder
    ordinario?: SortOrder
    final?: SortOrder
    fecha?: SortOrder
    _count?: CalificacionCountOrderByAggregateInput
    _avg?: CalificacionAvgOrderByAggregateInput
    _max?: CalificacionMaxOrderByAggregateInput
    _min?: CalificacionMinOrderByAggregateInput
    _sum?: CalificacionSumOrderByAggregateInput
  }

  export type CalificacionScalarWhereWithAggregatesInput = {
    AND?: CalificacionScalarWhereWithAggregatesInput | CalificacionScalarWhereWithAggregatesInput[]
    OR?: CalificacionScalarWhereWithAggregatesInput[]
    NOT?: CalificacionScalarWhereWithAggregatesInput | CalificacionScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"Calificacion"> | number
    estudianteId?: IntWithAggregatesFilter<"Calificacion"> | number
    materiaId?: IntWithAggregatesFilter<"Calificacion"> | number
    parcial1?: FloatWithAggregatesFilter<"Calificacion"> | number
    parcial2?: FloatWithAggregatesFilter<"Calificacion"> | number
    ordinario?: FloatWithAggregatesFilter<"Calificacion"> | number
    final?: FloatWithAggregatesFilter<"Calificacion"> | number
    fecha?: DateTimeWithAggregatesFilter<"Calificacion"> | Date | string
  }

  export type AsistenciaWhereInput = {
    AND?: AsistenciaWhereInput | AsistenciaWhereInput[]
    OR?: AsistenciaWhereInput[]
    NOT?: AsistenciaWhereInput | AsistenciaWhereInput[]
    id?: IntFilter<"Asistencia"> | number
    estudianteId?: IntFilter<"Asistencia"> | number
    materiaId?: IntFilter<"Asistencia"> | number
    parcial1?: IntFilter<"Asistencia"> | number
    parcial2?: IntFilter<"Asistencia"> | number
    final?: IntFilter<"Asistencia"> | number
    fecha?: DateTimeFilter<"Asistencia"> | Date | string
    estudiante?: XOR<EstudianteScalarRelationFilter, EstudianteWhereInput>
    materia?: XOR<MateriaScalarRelationFilter, MateriaWhereInput>
  }

  export type AsistenciaOrderByWithRelationInput = {
    id?: SortOrder
    estudianteId?: SortOrder
    materiaId?: SortOrder
    parcial1?: SortOrder
    parcial2?: SortOrder
    final?: SortOrder
    fecha?: SortOrder
    estudiante?: EstudianteOrderByWithRelationInput
    materia?: MateriaOrderByWithRelationInput
  }

  export type AsistenciaWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: AsistenciaWhereInput | AsistenciaWhereInput[]
    OR?: AsistenciaWhereInput[]
    NOT?: AsistenciaWhereInput | AsistenciaWhereInput[]
    estudianteId?: IntFilter<"Asistencia"> | number
    materiaId?: IntFilter<"Asistencia"> | number
    parcial1?: IntFilter<"Asistencia"> | number
    parcial2?: IntFilter<"Asistencia"> | number
    final?: IntFilter<"Asistencia"> | number
    fecha?: DateTimeFilter<"Asistencia"> | Date | string
    estudiante?: XOR<EstudianteScalarRelationFilter, EstudianteWhereInput>
    materia?: XOR<MateriaScalarRelationFilter, MateriaWhereInput>
  }, "id">

  export type AsistenciaOrderByWithAggregationInput = {
    id?: SortOrder
    estudianteId?: SortOrder
    materiaId?: SortOrder
    parcial1?: SortOrder
    parcial2?: SortOrder
    final?: SortOrder
    fecha?: SortOrder
    _count?: AsistenciaCountOrderByAggregateInput
    _avg?: AsistenciaAvgOrderByAggregateInput
    _max?: AsistenciaMaxOrderByAggregateInput
    _min?: AsistenciaMinOrderByAggregateInput
    _sum?: AsistenciaSumOrderByAggregateInput
  }

  export type AsistenciaScalarWhereWithAggregatesInput = {
    AND?: AsistenciaScalarWhereWithAggregatesInput | AsistenciaScalarWhereWithAggregatesInput[]
    OR?: AsistenciaScalarWhereWithAggregatesInput[]
    NOT?: AsistenciaScalarWhereWithAggregatesInput | AsistenciaScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"Asistencia"> | number
    estudianteId?: IntWithAggregatesFilter<"Asistencia"> | number
    materiaId?: IntWithAggregatesFilter<"Asistencia"> | number
    parcial1?: IntWithAggregatesFilter<"Asistencia"> | number
    parcial2?: IntWithAggregatesFilter<"Asistencia"> | number
    final?: IntWithAggregatesFilter<"Asistencia"> | number
    fecha?: DateTimeWithAggregatesFilter<"Asistencia"> | Date | string
  }

  export type UsuarioCreateInput = {
    nombre: string
    correo: string
    telefono: string
    contrasena: string
    puesto: $Enums.RolUsuario
    fechaCreacion?: Date | string
    Estudiante?: EstudianteCreateNestedOneWithoutUsuarioInput
    Profesor?: ProfesorCreateNestedOneWithoutUsuarioInput
    PadreFamilia?: PadreFamiliaCreateNestedManyWithoutUsuarioInput
  }

  export type UsuarioUncheckedCreateInput = {
    id?: number
    nombre: string
    correo: string
    telefono: string
    contrasena: string
    puesto: $Enums.RolUsuario
    fechaCreacion?: Date | string
    Estudiante?: EstudianteUncheckedCreateNestedOneWithoutUsuarioInput
    Profesor?: ProfesorUncheckedCreateNestedOneWithoutUsuarioInput
    PadreFamilia?: PadreFamiliaUncheckedCreateNestedManyWithoutUsuarioInput
  }

  export type UsuarioUpdateInput = {
    nombre?: StringFieldUpdateOperationsInput | string
    correo?: StringFieldUpdateOperationsInput | string
    telefono?: StringFieldUpdateOperationsInput | string
    contrasena?: StringFieldUpdateOperationsInput | string
    puesto?: EnumRolUsuarioFieldUpdateOperationsInput | $Enums.RolUsuario
    fechaCreacion?: DateTimeFieldUpdateOperationsInput | Date | string
    Estudiante?: EstudianteUpdateOneWithoutUsuarioNestedInput
    Profesor?: ProfesorUpdateOneWithoutUsuarioNestedInput
    PadreFamilia?: PadreFamiliaUpdateManyWithoutUsuarioNestedInput
  }

  export type UsuarioUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    nombre?: StringFieldUpdateOperationsInput | string
    correo?: StringFieldUpdateOperationsInput | string
    telefono?: StringFieldUpdateOperationsInput | string
    contrasena?: StringFieldUpdateOperationsInput | string
    puesto?: EnumRolUsuarioFieldUpdateOperationsInput | $Enums.RolUsuario
    fechaCreacion?: DateTimeFieldUpdateOperationsInput | Date | string
    Estudiante?: EstudianteUncheckedUpdateOneWithoutUsuarioNestedInput
    Profesor?: ProfesorUncheckedUpdateOneWithoutUsuarioNestedInput
    PadreFamilia?: PadreFamiliaUncheckedUpdateManyWithoutUsuarioNestedInput
  }

  export type UsuarioCreateManyInput = {
    id?: number
    nombre: string
    correo: string
    telefono: string
    contrasena: string
    puesto: $Enums.RolUsuario
    fechaCreacion?: Date | string
  }

  export type UsuarioUpdateManyMutationInput = {
    nombre?: StringFieldUpdateOperationsInput | string
    correo?: StringFieldUpdateOperationsInput | string
    telefono?: StringFieldUpdateOperationsInput | string
    contrasena?: StringFieldUpdateOperationsInput | string
    puesto?: EnumRolUsuarioFieldUpdateOperationsInput | $Enums.RolUsuario
    fechaCreacion?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UsuarioUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    nombre?: StringFieldUpdateOperationsInput | string
    correo?: StringFieldUpdateOperationsInput | string
    telefono?: StringFieldUpdateOperationsInput | string
    contrasena?: StringFieldUpdateOperationsInput | string
    puesto?: EnumRolUsuarioFieldUpdateOperationsInput | $Enums.RolUsuario
    fechaCreacion?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type EstudianteCreateInput = {
    estado?: $Enums.EstadoEstudiante
    tramites?: TramiteCreateNestedManyWithoutEstudianteInput
    grupo?: GrupoCreateNestedOneWithoutEstudiantesInput
    usuario: UsuarioCreateNestedOneWithoutEstudianteInput
    PadreFamilia?: PadreFamiliaCreateNestedOneWithoutEstudiantesInput
    Calificacion?: CalificacionCreateNestedManyWithoutEstudianteInput
    Asistencia?: AsistenciaCreateNestedManyWithoutEstudianteInput
  }

  export type EstudianteUncheckedCreateInput = {
    usuarioId: number
    grupoId?: number | null
    padreFamiliaId?: number | null
    estado?: $Enums.EstadoEstudiante
    tramites?: TramiteUncheckedCreateNestedManyWithoutEstudianteInput
    Calificacion?: CalificacionUncheckedCreateNestedManyWithoutEstudianteInput
    Asistencia?: AsistenciaUncheckedCreateNestedManyWithoutEstudianteInput
  }

  export type EstudianteUpdateInput = {
    estado?: EnumEstadoEstudianteFieldUpdateOperationsInput | $Enums.EstadoEstudiante
    tramites?: TramiteUpdateManyWithoutEstudianteNestedInput
    grupo?: GrupoUpdateOneWithoutEstudiantesNestedInput
    usuario?: UsuarioUpdateOneRequiredWithoutEstudianteNestedInput
    PadreFamilia?: PadreFamiliaUpdateOneWithoutEstudiantesNestedInput
    Calificacion?: CalificacionUpdateManyWithoutEstudianteNestedInput
    Asistencia?: AsistenciaUpdateManyWithoutEstudianteNestedInput
  }

  export type EstudianteUncheckedUpdateInput = {
    usuarioId?: IntFieldUpdateOperationsInput | number
    grupoId?: NullableIntFieldUpdateOperationsInput | number | null
    padreFamiliaId?: NullableIntFieldUpdateOperationsInput | number | null
    estado?: EnumEstadoEstudianteFieldUpdateOperationsInput | $Enums.EstadoEstudiante
    tramites?: TramiteUncheckedUpdateManyWithoutEstudianteNestedInput
    Calificacion?: CalificacionUncheckedUpdateManyWithoutEstudianteNestedInput
    Asistencia?: AsistenciaUncheckedUpdateManyWithoutEstudianteNestedInput
  }

  export type EstudianteCreateManyInput = {
    usuarioId: number
    grupoId?: number | null
    padreFamiliaId?: number | null
    estado?: $Enums.EstadoEstudiante
  }

  export type EstudianteUpdateManyMutationInput = {
    estado?: EnumEstadoEstudianteFieldUpdateOperationsInput | $Enums.EstadoEstudiante
  }

  export type EstudianteUncheckedUpdateManyInput = {
    usuarioId?: IntFieldUpdateOperationsInput | number
    grupoId?: NullableIntFieldUpdateOperationsInput | number | null
    padreFamiliaId?: NullableIntFieldUpdateOperationsInput | number | null
    estado?: EnumEstadoEstudianteFieldUpdateOperationsInput | $Enums.EstadoEstudiante
  }

  export type ProfesorCreateInput = {
    usuario: UsuarioCreateNestedOneWithoutProfesorInput
    materiales?: MaterialEducativoCreateNestedManyWithoutProfesorInput
    Materia?: MateriaCreateNestedManyWithoutProfesorInput
  }

  export type ProfesorUncheckedCreateInput = {
    usuarioId: number
    materiales?: MaterialEducativoUncheckedCreateNestedManyWithoutProfesorInput
    Materia?: MateriaUncheckedCreateNestedManyWithoutProfesorInput
  }

  export type ProfesorUpdateInput = {
    usuario?: UsuarioUpdateOneRequiredWithoutProfesorNestedInput
    materiales?: MaterialEducativoUpdateManyWithoutProfesorNestedInput
    Materia?: MateriaUpdateManyWithoutProfesorNestedInput
  }

  export type ProfesorUncheckedUpdateInput = {
    usuarioId?: IntFieldUpdateOperationsInput | number
    materiales?: MaterialEducativoUncheckedUpdateManyWithoutProfesorNestedInput
    Materia?: MateriaUncheckedUpdateManyWithoutProfesorNestedInput
  }

  export type ProfesorCreateManyInput = {
    usuarioId: number
  }

  export type ProfesorUpdateManyMutationInput = {

  }

  export type ProfesorUncheckedUpdateManyInput = {
    usuarioId?: IntFieldUpdateOperationsInput | number
  }

  export type PadreFamiliaCreateInput = {
    domicilio: string
    usuario: UsuarioCreateNestedOneWithoutPadreFamiliaInput
    estudiantes?: EstudianteCreateNestedManyWithoutPadreFamiliaInput
  }

  export type PadreFamiliaUncheckedCreateInput = {
    usuarioId: number
    domicilio: string
    estudiantes?: EstudianteUncheckedCreateNestedManyWithoutPadreFamiliaInput
  }

  export type PadreFamiliaUpdateInput = {
    domicilio?: StringFieldUpdateOperationsInput | string
    usuario?: UsuarioUpdateOneRequiredWithoutPadreFamiliaNestedInput
    estudiantes?: EstudianteUpdateManyWithoutPadreFamiliaNestedInput
  }

  export type PadreFamiliaUncheckedUpdateInput = {
    usuarioId?: IntFieldUpdateOperationsInput | number
    domicilio?: StringFieldUpdateOperationsInput | string
    estudiantes?: EstudianteUncheckedUpdateManyWithoutPadreFamiliaNestedInput
  }

  export type PadreFamiliaCreateManyInput = {
    usuarioId: number
    domicilio: string
  }

  export type PadreFamiliaUpdateManyMutationInput = {
    domicilio?: StringFieldUpdateOperationsInput | string
  }

  export type PadreFamiliaUncheckedUpdateManyInput = {
    usuarioId?: IntFieldUpdateOperationsInput | number
    domicilio?: StringFieldUpdateOperationsInput | string
  }

  export type GrupoCreateInput = {
    nombre: string
    grado: number
    estudiantes?: EstudianteCreateNestedManyWithoutGrupoInput
    inscripciones?: InscripcionCreateNestedManyWithoutGrupoInput
    materiales?: MaterialEducativoCreateNestedManyWithoutGrupoInput
  }

  export type GrupoUncheckedCreateInput = {
    id?: number
    nombre: string
    grado: number
    estudiantes?: EstudianteUncheckedCreateNestedManyWithoutGrupoInput
    inscripciones?: InscripcionUncheckedCreateNestedManyWithoutGrupoInput
    materiales?: MaterialEducativoUncheckedCreateNestedManyWithoutGrupoInput
  }

  export type GrupoUpdateInput = {
    nombre?: StringFieldUpdateOperationsInput | string
    grado?: IntFieldUpdateOperationsInput | number
    estudiantes?: EstudianteUpdateManyWithoutGrupoNestedInput
    inscripciones?: InscripcionUpdateManyWithoutGrupoNestedInput
    materiales?: MaterialEducativoUpdateManyWithoutGrupoNestedInput
  }

  export type GrupoUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    nombre?: StringFieldUpdateOperationsInput | string
    grado?: IntFieldUpdateOperationsInput | number
    estudiantes?: EstudianteUncheckedUpdateManyWithoutGrupoNestedInput
    inscripciones?: InscripcionUncheckedUpdateManyWithoutGrupoNestedInput
    materiales?: MaterialEducativoUncheckedUpdateManyWithoutGrupoNestedInput
  }

  export type GrupoCreateManyInput = {
    id?: number
    nombre: string
    grado: number
  }

  export type GrupoUpdateManyMutationInput = {
    nombre?: StringFieldUpdateOperationsInput | string
    grado?: IntFieldUpdateOperationsInput | number
  }

  export type GrupoUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    nombre?: StringFieldUpdateOperationsInput | string
    grado?: IntFieldUpdateOperationsInput | number
  }

  export type TramiteCreateInput = {
    tipo: $Enums.TipoTramite
    estado: $Enums.EstadoTramite
    fecha?: Date | string
    inscripcion?: InscripcionCreateNestedOneWithoutTramiteInput
    Pago?: PagoCreateNestedOneWithoutTramiteInput
    estudiante: EstudianteCreateNestedOneWithoutTramitesInput
  }

  export type TramiteUncheckedCreateInput = {
    id?: number
    estudianteId: number
    tipo: $Enums.TipoTramite
    estado: $Enums.EstadoTramite
    fecha?: Date | string
    inscripcion?: InscripcionUncheckedCreateNestedOneWithoutTramiteInput
    Pago?: PagoUncheckedCreateNestedOneWithoutTramiteInput
  }

  export type TramiteUpdateInput = {
    tipo?: EnumTipoTramiteFieldUpdateOperationsInput | $Enums.TipoTramite
    estado?: EnumEstadoTramiteFieldUpdateOperationsInput | $Enums.EstadoTramite
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    inscripcion?: InscripcionUpdateOneWithoutTramiteNestedInput
    Pago?: PagoUpdateOneWithoutTramiteNestedInput
    estudiante?: EstudianteUpdateOneRequiredWithoutTramitesNestedInput
  }

  export type TramiteUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    estudianteId?: IntFieldUpdateOperationsInput | number
    tipo?: EnumTipoTramiteFieldUpdateOperationsInput | $Enums.TipoTramite
    estado?: EnumEstadoTramiteFieldUpdateOperationsInput | $Enums.EstadoTramite
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    inscripcion?: InscripcionUncheckedUpdateOneWithoutTramiteNestedInput
    Pago?: PagoUncheckedUpdateOneWithoutTramiteNestedInput
  }

  export type TramiteCreateManyInput = {
    id?: number
    estudianteId: number
    tipo: $Enums.TipoTramite
    estado: $Enums.EstadoTramite
    fecha?: Date | string
  }

  export type TramiteUpdateManyMutationInput = {
    tipo?: EnumTipoTramiteFieldUpdateOperationsInput | $Enums.TipoTramite
    estado?: EnumEstadoTramiteFieldUpdateOperationsInput | $Enums.EstadoTramite
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type TramiteUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    estudianteId?: IntFieldUpdateOperationsInput | number
    tipo?: EnumTipoTramiteFieldUpdateOperationsInput | $Enums.TipoTramite
    estado?: EnumEstadoTramiteFieldUpdateOperationsInput | $Enums.EstadoTramite
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type InscripcionCreateInput = {
    tramite: TramiteCreateNestedOneWithoutInscripcionInput
    grupo: GrupoCreateNestedOneWithoutInscripcionesInput
  }

  export type InscripcionUncheckedCreateInput = {
    tramiteId: number
    grupoId: number
  }

  export type InscripcionUpdateInput = {
    tramite?: TramiteUpdateOneRequiredWithoutInscripcionNestedInput
    grupo?: GrupoUpdateOneRequiredWithoutInscripcionesNestedInput
  }

  export type InscripcionUncheckedUpdateInput = {
    tramiteId?: IntFieldUpdateOperationsInput | number
    grupoId?: IntFieldUpdateOperationsInput | number
  }

  export type InscripcionCreateManyInput = {
    tramiteId: number
    grupoId: number
  }

  export type InscripcionUpdateManyMutationInput = {

  }

  export type InscripcionUncheckedUpdateManyInput = {
    tramiteId?: IntFieldUpdateOperationsInput | number
    grupoId?: IntFieldUpdateOperationsInput | number
  }

  export type PagoCreateInput = {
    concepto: string
    monto: number
    recibos?: ReciboCreateNestedManyWithoutPagoInput
    tramite: TramiteCreateNestedOneWithoutPagoInput
  }

  export type PagoUncheckedCreateInput = {
    tramiteId: number
    concepto: string
    monto: number
    recibos?: ReciboUncheckedCreateNestedManyWithoutPagoInput
  }

  export type PagoUpdateInput = {
    concepto?: StringFieldUpdateOperationsInput | string
    monto?: FloatFieldUpdateOperationsInput | number
    recibos?: ReciboUpdateManyWithoutPagoNestedInput
    tramite?: TramiteUpdateOneRequiredWithoutPagoNestedInput
  }

  export type PagoUncheckedUpdateInput = {
    tramiteId?: IntFieldUpdateOperationsInput | number
    concepto?: StringFieldUpdateOperationsInput | string
    monto?: FloatFieldUpdateOperationsInput | number
    recibos?: ReciboUncheckedUpdateManyWithoutPagoNestedInput
  }

  export type PagoCreateManyInput = {
    tramiteId: number
    concepto: string
    monto: number
  }

  export type PagoUpdateManyMutationInput = {
    concepto?: StringFieldUpdateOperationsInput | string
    monto?: FloatFieldUpdateOperationsInput | number
  }

  export type PagoUncheckedUpdateManyInput = {
    tramiteId?: IntFieldUpdateOperationsInput | number
    concepto?: StringFieldUpdateOperationsInput | string
    monto?: FloatFieldUpdateOperationsInput | number
  }

  export type ReciboCreateInput = {
    monto: number
    fecha?: Date | string
    pago: PagoCreateNestedOneWithoutRecibosInput
  }

  export type ReciboUncheckedCreateInput = {
    id?: number
    pagoId: number
    monto: number
    fecha?: Date | string
  }

  export type ReciboUpdateInput = {
    monto?: FloatFieldUpdateOperationsInput | number
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    pago?: PagoUpdateOneRequiredWithoutRecibosNestedInput
  }

  export type ReciboUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    pagoId?: IntFieldUpdateOperationsInput | number
    monto?: FloatFieldUpdateOperationsInput | number
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ReciboCreateManyInput = {
    id?: number
    pagoId: number
    monto: number
    fecha?: Date | string
  }

  export type ReciboUpdateManyMutationInput = {
    monto?: FloatFieldUpdateOperationsInput | number
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ReciboUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    pagoId?: IntFieldUpdateOperationsInput | number
    monto?: FloatFieldUpdateOperationsInput | number
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MaterialEducativoCreateInput = {
    titulo: string
    descripcion: string
    categoria: string
    existencia?: boolean
    fecha?: Date | string
    tipoArchivo: string
    profesor: ProfesorCreateNestedOneWithoutMaterialesInput
    grupo: GrupoCreateNestedOneWithoutMaterialesInput
    archivo?: ArchivoSubidoCreateNestedManyWithoutMaterialInput
  }

  export type MaterialEducativoUncheckedCreateInput = {
    id?: number
    titulo: string
    descripcion: string
    categoria: string
    existencia?: boolean
    fecha?: Date | string
    tipoArchivo: string
    profesorId: number
    grupoId: number
    archivo?: ArchivoSubidoUncheckedCreateNestedManyWithoutMaterialInput
  }

  export type MaterialEducativoUpdateInput = {
    titulo?: StringFieldUpdateOperationsInput | string
    descripcion?: StringFieldUpdateOperationsInput | string
    categoria?: StringFieldUpdateOperationsInput | string
    existencia?: BoolFieldUpdateOperationsInput | boolean
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    tipoArchivo?: StringFieldUpdateOperationsInput | string
    profesor?: ProfesorUpdateOneRequiredWithoutMaterialesNestedInput
    grupo?: GrupoUpdateOneRequiredWithoutMaterialesNestedInput
    archivo?: ArchivoSubidoUpdateManyWithoutMaterialNestedInput
  }

  export type MaterialEducativoUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    titulo?: StringFieldUpdateOperationsInput | string
    descripcion?: StringFieldUpdateOperationsInput | string
    categoria?: StringFieldUpdateOperationsInput | string
    existencia?: BoolFieldUpdateOperationsInput | boolean
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    tipoArchivo?: StringFieldUpdateOperationsInput | string
    profesorId?: IntFieldUpdateOperationsInput | number
    grupoId?: IntFieldUpdateOperationsInput | number
    archivo?: ArchivoSubidoUncheckedUpdateManyWithoutMaterialNestedInput
  }

  export type MaterialEducativoCreateManyInput = {
    id?: number
    titulo: string
    descripcion: string
    categoria: string
    existencia?: boolean
    fecha?: Date | string
    tipoArchivo: string
    profesorId: number
    grupoId: number
  }

  export type MaterialEducativoUpdateManyMutationInput = {
    titulo?: StringFieldUpdateOperationsInput | string
    descripcion?: StringFieldUpdateOperationsInput | string
    categoria?: StringFieldUpdateOperationsInput | string
    existencia?: BoolFieldUpdateOperationsInput | boolean
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    tipoArchivo?: StringFieldUpdateOperationsInput | string
  }

  export type MaterialEducativoUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    titulo?: StringFieldUpdateOperationsInput | string
    descripcion?: StringFieldUpdateOperationsInput | string
    categoria?: StringFieldUpdateOperationsInput | string
    existencia?: BoolFieldUpdateOperationsInput | boolean
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    tipoArchivo?: StringFieldUpdateOperationsInput | string
    profesorId?: IntFieldUpdateOperationsInput | number
    grupoId?: IntFieldUpdateOperationsInput | number
  }

  export type ArchivoSubidoCreateInput = {
    nombreArchivo: string
    urlNube: string
    material: MaterialEducativoCreateNestedOneWithoutArchivoInput
  }

  export type ArchivoSubidoUncheckedCreateInput = {
    id?: number
    materialId: number
    nombreArchivo: string
    urlNube: string
  }

  export type ArchivoSubidoUpdateInput = {
    nombreArchivo?: StringFieldUpdateOperationsInput | string
    urlNube?: StringFieldUpdateOperationsInput | string
    material?: MaterialEducativoUpdateOneRequiredWithoutArchivoNestedInput
  }

  export type ArchivoSubidoUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    materialId?: IntFieldUpdateOperationsInput | number
    nombreArchivo?: StringFieldUpdateOperationsInput | string
    urlNube?: StringFieldUpdateOperationsInput | string
  }

  export type ArchivoSubidoCreateManyInput = {
    id?: number
    materialId: number
    nombreArchivo: string
    urlNube: string
  }

  export type ArchivoSubidoUpdateManyMutationInput = {
    nombreArchivo?: StringFieldUpdateOperationsInput | string
    urlNube?: StringFieldUpdateOperationsInput | string
  }

  export type ArchivoSubidoUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    materialId?: IntFieldUpdateOperationsInput | number
    nombreArchivo?: StringFieldUpdateOperationsInput | string
    urlNube?: StringFieldUpdateOperationsInput | string
  }

  export type MateriaCreateInput = {
    nombre: string
    profesor: ProfesorCreateNestedOneWithoutMateriaInput
    Calificacion?: CalificacionCreateNestedManyWithoutMateriaInput
    Asistencia?: AsistenciaCreateNestedManyWithoutMateriaInput
  }

  export type MateriaUncheckedCreateInput = {
    id?: number
    nombre: string
    profesorId: number
    Calificacion?: CalificacionUncheckedCreateNestedManyWithoutMateriaInput
    Asistencia?: AsistenciaUncheckedCreateNestedManyWithoutMateriaInput
  }

  export type MateriaUpdateInput = {
    nombre?: StringFieldUpdateOperationsInput | string
    profesor?: ProfesorUpdateOneRequiredWithoutMateriaNestedInput
    Calificacion?: CalificacionUpdateManyWithoutMateriaNestedInput
    Asistencia?: AsistenciaUpdateManyWithoutMateriaNestedInput
  }

  export type MateriaUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    nombre?: StringFieldUpdateOperationsInput | string
    profesorId?: IntFieldUpdateOperationsInput | number
    Calificacion?: CalificacionUncheckedUpdateManyWithoutMateriaNestedInput
    Asistencia?: AsistenciaUncheckedUpdateManyWithoutMateriaNestedInput
  }

  export type MateriaCreateManyInput = {
    id?: number
    nombre: string
    profesorId: number
  }

  export type MateriaUpdateManyMutationInput = {
    nombre?: StringFieldUpdateOperationsInput | string
  }

  export type MateriaUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    nombre?: StringFieldUpdateOperationsInput | string
    profesorId?: IntFieldUpdateOperationsInput | number
  }

  export type CalificacionCreateInput = {
    parcial1?: number
    parcial2?: number
    ordinario?: number
    final?: number
    fecha?: Date | string
    estudiante: EstudianteCreateNestedOneWithoutCalificacionInput
    materia: MateriaCreateNestedOneWithoutCalificacionInput
  }

  export type CalificacionUncheckedCreateInput = {
    id?: number
    estudianteId: number
    materiaId: number
    parcial1?: number
    parcial2?: number
    ordinario?: number
    final?: number
    fecha?: Date | string
  }

  export type CalificacionUpdateInput = {
    parcial1?: FloatFieldUpdateOperationsInput | number
    parcial2?: FloatFieldUpdateOperationsInput | number
    ordinario?: FloatFieldUpdateOperationsInput | number
    final?: FloatFieldUpdateOperationsInput | number
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    estudiante?: EstudianteUpdateOneRequiredWithoutCalificacionNestedInput
    materia?: MateriaUpdateOneRequiredWithoutCalificacionNestedInput
  }

  export type CalificacionUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    estudianteId?: IntFieldUpdateOperationsInput | number
    materiaId?: IntFieldUpdateOperationsInput | number
    parcial1?: FloatFieldUpdateOperationsInput | number
    parcial2?: FloatFieldUpdateOperationsInput | number
    ordinario?: FloatFieldUpdateOperationsInput | number
    final?: FloatFieldUpdateOperationsInput | number
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CalificacionCreateManyInput = {
    id?: number
    estudianteId: number
    materiaId: number
    parcial1?: number
    parcial2?: number
    ordinario?: number
    final?: number
    fecha?: Date | string
  }

  export type CalificacionUpdateManyMutationInput = {
    parcial1?: FloatFieldUpdateOperationsInput | number
    parcial2?: FloatFieldUpdateOperationsInput | number
    ordinario?: FloatFieldUpdateOperationsInput | number
    final?: FloatFieldUpdateOperationsInput | number
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CalificacionUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    estudianteId?: IntFieldUpdateOperationsInput | number
    materiaId?: IntFieldUpdateOperationsInput | number
    parcial1?: FloatFieldUpdateOperationsInput | number
    parcial2?: FloatFieldUpdateOperationsInput | number
    ordinario?: FloatFieldUpdateOperationsInput | number
    final?: FloatFieldUpdateOperationsInput | number
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AsistenciaCreateInput = {
    parcial1?: number
    parcial2?: number
    final?: number
    fecha?: Date | string
    estudiante: EstudianteCreateNestedOneWithoutAsistenciaInput
    materia: MateriaCreateNestedOneWithoutAsistenciaInput
  }

  export type AsistenciaUncheckedCreateInput = {
    id?: number
    estudianteId: number
    materiaId: number
    parcial1?: number
    parcial2?: number
    final?: number
    fecha?: Date | string
  }

  export type AsistenciaUpdateInput = {
    parcial1?: IntFieldUpdateOperationsInput | number
    parcial2?: IntFieldUpdateOperationsInput | number
    final?: IntFieldUpdateOperationsInput | number
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    estudiante?: EstudianteUpdateOneRequiredWithoutAsistenciaNestedInput
    materia?: MateriaUpdateOneRequiredWithoutAsistenciaNestedInput
  }

  export type AsistenciaUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    estudianteId?: IntFieldUpdateOperationsInput | number
    materiaId?: IntFieldUpdateOperationsInput | number
    parcial1?: IntFieldUpdateOperationsInput | number
    parcial2?: IntFieldUpdateOperationsInput | number
    final?: IntFieldUpdateOperationsInput | number
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AsistenciaCreateManyInput = {
    id?: number
    estudianteId: number
    materiaId: number
    parcial1?: number
    parcial2?: number
    final?: number
    fecha?: Date | string
  }

  export type AsistenciaUpdateManyMutationInput = {
    parcial1?: IntFieldUpdateOperationsInput | number
    parcial2?: IntFieldUpdateOperationsInput | number
    final?: IntFieldUpdateOperationsInput | number
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AsistenciaUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    estudianteId?: IntFieldUpdateOperationsInput | number
    materiaId?: IntFieldUpdateOperationsInput | number
    parcial1?: IntFieldUpdateOperationsInput | number
    parcial2?: IntFieldUpdateOperationsInput | number
    final?: IntFieldUpdateOperationsInput | number
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type IntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type EnumRolUsuarioFilter<$PrismaModel = never> = {
    equals?: $Enums.RolUsuario | EnumRolUsuarioFieldRefInput<$PrismaModel>
    in?: $Enums.RolUsuario[]
    notIn?: $Enums.RolUsuario[]
    not?: NestedEnumRolUsuarioFilter<$PrismaModel> | $Enums.RolUsuario
  }

  export type DateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type EstudianteNullableScalarRelationFilter = {
    is?: EstudianteWhereInput | null
    isNot?: EstudianteWhereInput | null
  }

  export type ProfesorNullableScalarRelationFilter = {
    is?: ProfesorWhereInput | null
    isNot?: ProfesorWhereInput | null
  }

  export type PadreFamiliaListRelationFilter = {
    every?: PadreFamiliaWhereInput
    some?: PadreFamiliaWhereInput
    none?: PadreFamiliaWhereInput
  }

  export type PadreFamiliaOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type UsuarioOrderByRelevanceInput = {
    fields: UsuarioOrderByRelevanceFieldEnum | UsuarioOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type UsuarioCountOrderByAggregateInput = {
    id?: SortOrder
    nombre?: SortOrder
    correo?: SortOrder
    telefono?: SortOrder
    contrasena?: SortOrder
    puesto?: SortOrder
    fechaCreacion?: SortOrder
  }

  export type UsuarioAvgOrderByAggregateInput = {
    id?: SortOrder
  }

  export type UsuarioMaxOrderByAggregateInput = {
    id?: SortOrder
    nombre?: SortOrder
    correo?: SortOrder
    telefono?: SortOrder
    contrasena?: SortOrder
    puesto?: SortOrder
    fechaCreacion?: SortOrder
  }

  export type UsuarioMinOrderByAggregateInput = {
    id?: SortOrder
    nombre?: SortOrder
    correo?: SortOrder
    telefono?: SortOrder
    contrasena?: SortOrder
    puesto?: SortOrder
    fechaCreacion?: SortOrder
  }

  export type UsuarioSumOrderByAggregateInput = {
    id?: SortOrder
  }

  export type IntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type EnumRolUsuarioWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.RolUsuario | EnumRolUsuarioFieldRefInput<$PrismaModel>
    in?: $Enums.RolUsuario[]
    notIn?: $Enums.RolUsuario[]
    not?: NestedEnumRolUsuarioWithAggregatesFilter<$PrismaModel> | $Enums.RolUsuario
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumRolUsuarioFilter<$PrismaModel>
    _max?: NestedEnumRolUsuarioFilter<$PrismaModel>
  }

  export type DateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type IntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type EnumEstadoEstudianteFilter<$PrismaModel = never> = {
    equals?: $Enums.EstadoEstudiante | EnumEstadoEstudianteFieldRefInput<$PrismaModel>
    in?: $Enums.EstadoEstudiante[]
    notIn?: $Enums.EstadoEstudiante[]
    not?: NestedEnumEstadoEstudianteFilter<$PrismaModel> | $Enums.EstadoEstudiante
  }

  export type TramiteListRelationFilter = {
    every?: TramiteWhereInput
    some?: TramiteWhereInput
    none?: TramiteWhereInput
  }

  export type GrupoNullableScalarRelationFilter = {
    is?: GrupoWhereInput | null
    isNot?: GrupoWhereInput | null
  }

  export type UsuarioScalarRelationFilter = {
    is?: UsuarioWhereInput
    isNot?: UsuarioWhereInput
  }

  export type PadreFamiliaNullableScalarRelationFilter = {
    is?: PadreFamiliaWhereInput | null
    isNot?: PadreFamiliaWhereInput | null
  }

  export type CalificacionListRelationFilter = {
    every?: CalificacionWhereInput
    some?: CalificacionWhereInput
    none?: CalificacionWhereInput
  }

  export type AsistenciaListRelationFilter = {
    every?: AsistenciaWhereInput
    some?: AsistenciaWhereInput
    none?: AsistenciaWhereInput
  }

  export type SortOrderInput = {
    sort: SortOrder
    nulls?: NullsOrder
  }

  export type TramiteOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type CalificacionOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type AsistenciaOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type EstudianteCountOrderByAggregateInput = {
    usuarioId?: SortOrder
    grupoId?: SortOrder
    padreFamiliaId?: SortOrder
    estado?: SortOrder
  }

  export type EstudianteAvgOrderByAggregateInput = {
    usuarioId?: SortOrder
    grupoId?: SortOrder
    padreFamiliaId?: SortOrder
  }

  export type EstudianteMaxOrderByAggregateInput = {
    usuarioId?: SortOrder
    grupoId?: SortOrder
    padreFamiliaId?: SortOrder
    estado?: SortOrder
  }

  export type EstudianteMinOrderByAggregateInput = {
    usuarioId?: SortOrder
    grupoId?: SortOrder
    padreFamiliaId?: SortOrder
    estado?: SortOrder
  }

  export type EstudianteSumOrderByAggregateInput = {
    usuarioId?: SortOrder
    grupoId?: SortOrder
    padreFamiliaId?: SortOrder
  }

  export type IntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type EnumEstadoEstudianteWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.EstadoEstudiante | EnumEstadoEstudianteFieldRefInput<$PrismaModel>
    in?: $Enums.EstadoEstudiante[]
    notIn?: $Enums.EstadoEstudiante[]
    not?: NestedEnumEstadoEstudianteWithAggregatesFilter<$PrismaModel> | $Enums.EstadoEstudiante
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumEstadoEstudianteFilter<$PrismaModel>
    _max?: NestedEnumEstadoEstudianteFilter<$PrismaModel>
  }

  export type MaterialEducativoListRelationFilter = {
    every?: MaterialEducativoWhereInput
    some?: MaterialEducativoWhereInput
    none?: MaterialEducativoWhereInput
  }

  export type MateriaListRelationFilter = {
    every?: MateriaWhereInput
    some?: MateriaWhereInput
    none?: MateriaWhereInput
  }

  export type MaterialEducativoOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type MateriaOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type ProfesorCountOrderByAggregateInput = {
    usuarioId?: SortOrder
  }

  export type ProfesorAvgOrderByAggregateInput = {
    usuarioId?: SortOrder
  }

  export type ProfesorMaxOrderByAggregateInput = {
    usuarioId?: SortOrder
  }

  export type ProfesorMinOrderByAggregateInput = {
    usuarioId?: SortOrder
  }

  export type ProfesorSumOrderByAggregateInput = {
    usuarioId?: SortOrder
  }

  export type EstudianteListRelationFilter = {
    every?: EstudianteWhereInput
    some?: EstudianteWhereInput
    none?: EstudianteWhereInput
  }

  export type EstudianteOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type PadreFamiliaOrderByRelevanceInput = {
    fields: PadreFamiliaOrderByRelevanceFieldEnum | PadreFamiliaOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type PadreFamiliaCountOrderByAggregateInput = {
    usuarioId?: SortOrder
    domicilio?: SortOrder
  }

  export type PadreFamiliaAvgOrderByAggregateInput = {
    usuarioId?: SortOrder
  }

  export type PadreFamiliaMaxOrderByAggregateInput = {
    usuarioId?: SortOrder
    domicilio?: SortOrder
  }

  export type PadreFamiliaMinOrderByAggregateInput = {
    usuarioId?: SortOrder
    domicilio?: SortOrder
  }

  export type PadreFamiliaSumOrderByAggregateInput = {
    usuarioId?: SortOrder
  }

  export type InscripcionListRelationFilter = {
    every?: InscripcionWhereInput
    some?: InscripcionWhereInput
    none?: InscripcionWhereInput
  }

  export type InscripcionOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type GrupoOrderByRelevanceInput = {
    fields: GrupoOrderByRelevanceFieldEnum | GrupoOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type GrupoCountOrderByAggregateInput = {
    id?: SortOrder
    nombre?: SortOrder
    grado?: SortOrder
  }

  export type GrupoAvgOrderByAggregateInput = {
    id?: SortOrder
    grado?: SortOrder
  }

  export type GrupoMaxOrderByAggregateInput = {
    id?: SortOrder
    nombre?: SortOrder
    grado?: SortOrder
  }

  export type GrupoMinOrderByAggregateInput = {
    id?: SortOrder
    nombre?: SortOrder
    grado?: SortOrder
  }

  export type GrupoSumOrderByAggregateInput = {
    id?: SortOrder
    grado?: SortOrder
  }

  export type EnumTipoTramiteFilter<$PrismaModel = never> = {
    equals?: $Enums.TipoTramite | EnumTipoTramiteFieldRefInput<$PrismaModel>
    in?: $Enums.TipoTramite[]
    notIn?: $Enums.TipoTramite[]
    not?: NestedEnumTipoTramiteFilter<$PrismaModel> | $Enums.TipoTramite
  }

  export type EnumEstadoTramiteFilter<$PrismaModel = never> = {
    equals?: $Enums.EstadoTramite | EnumEstadoTramiteFieldRefInput<$PrismaModel>
    in?: $Enums.EstadoTramite[]
    notIn?: $Enums.EstadoTramite[]
    not?: NestedEnumEstadoTramiteFilter<$PrismaModel> | $Enums.EstadoTramite
  }

  export type InscripcionNullableScalarRelationFilter = {
    is?: InscripcionWhereInput | null
    isNot?: InscripcionWhereInput | null
  }

  export type PagoNullableScalarRelationFilter = {
    is?: PagoWhereInput | null
    isNot?: PagoWhereInput | null
  }

  export type EstudianteScalarRelationFilter = {
    is?: EstudianteWhereInput
    isNot?: EstudianteWhereInput
  }

  export type TramiteCountOrderByAggregateInput = {
    id?: SortOrder
    estudianteId?: SortOrder
    tipo?: SortOrder
    estado?: SortOrder
    fecha?: SortOrder
  }

  export type TramiteAvgOrderByAggregateInput = {
    id?: SortOrder
    estudianteId?: SortOrder
  }

  export type TramiteMaxOrderByAggregateInput = {
    id?: SortOrder
    estudianteId?: SortOrder
    tipo?: SortOrder
    estado?: SortOrder
    fecha?: SortOrder
  }

  export type TramiteMinOrderByAggregateInput = {
    id?: SortOrder
    estudianteId?: SortOrder
    tipo?: SortOrder
    estado?: SortOrder
    fecha?: SortOrder
  }

  export type TramiteSumOrderByAggregateInput = {
    id?: SortOrder
    estudianteId?: SortOrder
  }

  export type EnumTipoTramiteWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.TipoTramite | EnumTipoTramiteFieldRefInput<$PrismaModel>
    in?: $Enums.TipoTramite[]
    notIn?: $Enums.TipoTramite[]
    not?: NestedEnumTipoTramiteWithAggregatesFilter<$PrismaModel> | $Enums.TipoTramite
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumTipoTramiteFilter<$PrismaModel>
    _max?: NestedEnumTipoTramiteFilter<$PrismaModel>
  }

  export type EnumEstadoTramiteWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.EstadoTramite | EnumEstadoTramiteFieldRefInput<$PrismaModel>
    in?: $Enums.EstadoTramite[]
    notIn?: $Enums.EstadoTramite[]
    not?: NestedEnumEstadoTramiteWithAggregatesFilter<$PrismaModel> | $Enums.EstadoTramite
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumEstadoTramiteFilter<$PrismaModel>
    _max?: NestedEnumEstadoTramiteFilter<$PrismaModel>
  }

  export type TramiteScalarRelationFilter = {
    is?: TramiteWhereInput
    isNot?: TramiteWhereInput
  }

  export type GrupoScalarRelationFilter = {
    is?: GrupoWhereInput
    isNot?: GrupoWhereInput
  }

  export type InscripcionCountOrderByAggregateInput = {
    tramiteId?: SortOrder
    grupoId?: SortOrder
  }

  export type InscripcionAvgOrderByAggregateInput = {
    tramiteId?: SortOrder
    grupoId?: SortOrder
  }

  export type InscripcionMaxOrderByAggregateInput = {
    tramiteId?: SortOrder
    grupoId?: SortOrder
  }

  export type InscripcionMinOrderByAggregateInput = {
    tramiteId?: SortOrder
    grupoId?: SortOrder
  }

  export type InscripcionSumOrderByAggregateInput = {
    tramiteId?: SortOrder
    grupoId?: SortOrder
  }

  export type FloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type ReciboListRelationFilter = {
    every?: ReciboWhereInput
    some?: ReciboWhereInput
    none?: ReciboWhereInput
  }

  export type ReciboOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type PagoOrderByRelevanceInput = {
    fields: PagoOrderByRelevanceFieldEnum | PagoOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type PagoCountOrderByAggregateInput = {
    tramiteId?: SortOrder
    concepto?: SortOrder
    monto?: SortOrder
  }

  export type PagoAvgOrderByAggregateInput = {
    tramiteId?: SortOrder
    monto?: SortOrder
  }

  export type PagoMaxOrderByAggregateInput = {
    tramiteId?: SortOrder
    concepto?: SortOrder
    monto?: SortOrder
  }

  export type PagoMinOrderByAggregateInput = {
    tramiteId?: SortOrder
    concepto?: SortOrder
    monto?: SortOrder
  }

  export type PagoSumOrderByAggregateInput = {
    tramiteId?: SortOrder
    monto?: SortOrder
  }

  export type FloatWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedFloatFilter<$PrismaModel>
    _min?: NestedFloatFilter<$PrismaModel>
    _max?: NestedFloatFilter<$PrismaModel>
  }

  export type PagoScalarRelationFilter = {
    is?: PagoWhereInput
    isNot?: PagoWhereInput
  }

  export type ReciboCountOrderByAggregateInput = {
    id?: SortOrder
    pagoId?: SortOrder
    monto?: SortOrder
    fecha?: SortOrder
  }

  export type ReciboAvgOrderByAggregateInput = {
    id?: SortOrder
    pagoId?: SortOrder
    monto?: SortOrder
  }

  export type ReciboMaxOrderByAggregateInput = {
    id?: SortOrder
    pagoId?: SortOrder
    monto?: SortOrder
    fecha?: SortOrder
  }

  export type ReciboMinOrderByAggregateInput = {
    id?: SortOrder
    pagoId?: SortOrder
    monto?: SortOrder
    fecha?: SortOrder
  }

  export type ReciboSumOrderByAggregateInput = {
    id?: SortOrder
    pagoId?: SortOrder
    monto?: SortOrder
  }

  export type BoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type ProfesorScalarRelationFilter = {
    is?: ProfesorWhereInput
    isNot?: ProfesorWhereInput
  }

  export type ArchivoSubidoListRelationFilter = {
    every?: ArchivoSubidoWhereInput
    some?: ArchivoSubidoWhereInput
    none?: ArchivoSubidoWhereInput
  }

  export type ArchivoSubidoOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type MaterialEducativoOrderByRelevanceInput = {
    fields: MaterialEducativoOrderByRelevanceFieldEnum | MaterialEducativoOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type MaterialEducativoCountOrderByAggregateInput = {
    id?: SortOrder
    titulo?: SortOrder
    descripcion?: SortOrder
    categoria?: SortOrder
    existencia?: SortOrder
    fecha?: SortOrder
    tipoArchivo?: SortOrder
    profesorId?: SortOrder
    grupoId?: SortOrder
  }

  export type MaterialEducativoAvgOrderByAggregateInput = {
    id?: SortOrder
    profesorId?: SortOrder
    grupoId?: SortOrder
  }

  export type MaterialEducativoMaxOrderByAggregateInput = {
    id?: SortOrder
    titulo?: SortOrder
    descripcion?: SortOrder
    categoria?: SortOrder
    existencia?: SortOrder
    fecha?: SortOrder
    tipoArchivo?: SortOrder
    profesorId?: SortOrder
    grupoId?: SortOrder
  }

  export type MaterialEducativoMinOrderByAggregateInput = {
    id?: SortOrder
    titulo?: SortOrder
    descripcion?: SortOrder
    categoria?: SortOrder
    existencia?: SortOrder
    fecha?: SortOrder
    tipoArchivo?: SortOrder
    profesorId?: SortOrder
    grupoId?: SortOrder
  }

  export type MaterialEducativoSumOrderByAggregateInput = {
    id?: SortOrder
    profesorId?: SortOrder
    grupoId?: SortOrder
  }

  export type BoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type MaterialEducativoScalarRelationFilter = {
    is?: MaterialEducativoWhereInput
    isNot?: MaterialEducativoWhereInput
  }

  export type ArchivoSubidoOrderByRelevanceInput = {
    fields: ArchivoSubidoOrderByRelevanceFieldEnum | ArchivoSubidoOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type ArchivoSubidoCountOrderByAggregateInput = {
    id?: SortOrder
    materialId?: SortOrder
    nombreArchivo?: SortOrder
    urlNube?: SortOrder
  }

  export type ArchivoSubidoAvgOrderByAggregateInput = {
    id?: SortOrder
    materialId?: SortOrder
  }

  export type ArchivoSubidoMaxOrderByAggregateInput = {
    id?: SortOrder
    materialId?: SortOrder
    nombreArchivo?: SortOrder
    urlNube?: SortOrder
  }

  export type ArchivoSubidoMinOrderByAggregateInput = {
    id?: SortOrder
    materialId?: SortOrder
    nombreArchivo?: SortOrder
    urlNube?: SortOrder
  }

  export type ArchivoSubidoSumOrderByAggregateInput = {
    id?: SortOrder
    materialId?: SortOrder
  }

  export type MateriaOrderByRelevanceInput = {
    fields: MateriaOrderByRelevanceFieldEnum | MateriaOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type MateriaCountOrderByAggregateInput = {
    id?: SortOrder
    nombre?: SortOrder
    profesorId?: SortOrder
  }

  export type MateriaAvgOrderByAggregateInput = {
    id?: SortOrder
    profesorId?: SortOrder
  }

  export type MateriaMaxOrderByAggregateInput = {
    id?: SortOrder
    nombre?: SortOrder
    profesorId?: SortOrder
  }

  export type MateriaMinOrderByAggregateInput = {
    id?: SortOrder
    nombre?: SortOrder
    profesorId?: SortOrder
  }

  export type MateriaSumOrderByAggregateInput = {
    id?: SortOrder
    profesorId?: SortOrder
  }

  export type MateriaScalarRelationFilter = {
    is?: MateriaWhereInput
    isNot?: MateriaWhereInput
  }

  export type CalificacionCountOrderByAggregateInput = {
    id?: SortOrder
    estudianteId?: SortOrder
    materiaId?: SortOrder
    parcial1?: SortOrder
    parcial2?: SortOrder
    ordinario?: SortOrder
    final?: SortOrder
    fecha?: SortOrder
  }

  export type CalificacionAvgOrderByAggregateInput = {
    id?: SortOrder
    estudianteId?: SortOrder
    materiaId?: SortOrder
    parcial1?: SortOrder
    parcial2?: SortOrder
    ordinario?: SortOrder
    final?: SortOrder
  }

  export type CalificacionMaxOrderByAggregateInput = {
    id?: SortOrder
    estudianteId?: SortOrder
    materiaId?: SortOrder
    parcial1?: SortOrder
    parcial2?: SortOrder
    ordinario?: SortOrder
    final?: SortOrder
    fecha?: SortOrder
  }

  export type CalificacionMinOrderByAggregateInput = {
    id?: SortOrder
    estudianteId?: SortOrder
    materiaId?: SortOrder
    parcial1?: SortOrder
    parcial2?: SortOrder
    ordinario?: SortOrder
    final?: SortOrder
    fecha?: SortOrder
  }

  export type CalificacionSumOrderByAggregateInput = {
    id?: SortOrder
    estudianteId?: SortOrder
    materiaId?: SortOrder
    parcial1?: SortOrder
    parcial2?: SortOrder
    ordinario?: SortOrder
    final?: SortOrder
  }

  export type AsistenciaCountOrderByAggregateInput = {
    id?: SortOrder
    estudianteId?: SortOrder
    materiaId?: SortOrder
    parcial1?: SortOrder
    parcial2?: SortOrder
    final?: SortOrder
    fecha?: SortOrder
  }

  export type AsistenciaAvgOrderByAggregateInput = {
    id?: SortOrder
    estudianteId?: SortOrder
    materiaId?: SortOrder
    parcial1?: SortOrder
    parcial2?: SortOrder
    final?: SortOrder
  }

  export type AsistenciaMaxOrderByAggregateInput = {
    id?: SortOrder
    estudianteId?: SortOrder
    materiaId?: SortOrder
    parcial1?: SortOrder
    parcial2?: SortOrder
    final?: SortOrder
    fecha?: SortOrder
  }

  export type AsistenciaMinOrderByAggregateInput = {
    id?: SortOrder
    estudianteId?: SortOrder
    materiaId?: SortOrder
    parcial1?: SortOrder
    parcial2?: SortOrder
    final?: SortOrder
    fecha?: SortOrder
  }

  export type AsistenciaSumOrderByAggregateInput = {
    id?: SortOrder
    estudianteId?: SortOrder
    materiaId?: SortOrder
    parcial1?: SortOrder
    parcial2?: SortOrder
    final?: SortOrder
  }

  export type EstudianteCreateNestedOneWithoutUsuarioInput = {
    create?: XOR<EstudianteCreateWithoutUsuarioInput, EstudianteUncheckedCreateWithoutUsuarioInput>
    connectOrCreate?: EstudianteCreateOrConnectWithoutUsuarioInput
    connect?: EstudianteWhereUniqueInput
  }

  export type ProfesorCreateNestedOneWithoutUsuarioInput = {
    create?: XOR<ProfesorCreateWithoutUsuarioInput, ProfesorUncheckedCreateWithoutUsuarioInput>
    connectOrCreate?: ProfesorCreateOrConnectWithoutUsuarioInput
    connect?: ProfesorWhereUniqueInput
  }

  export type PadreFamiliaCreateNestedManyWithoutUsuarioInput = {
    create?: XOR<PadreFamiliaCreateWithoutUsuarioInput, PadreFamiliaUncheckedCreateWithoutUsuarioInput> | PadreFamiliaCreateWithoutUsuarioInput[] | PadreFamiliaUncheckedCreateWithoutUsuarioInput[]
    connectOrCreate?: PadreFamiliaCreateOrConnectWithoutUsuarioInput | PadreFamiliaCreateOrConnectWithoutUsuarioInput[]
    createMany?: PadreFamiliaCreateManyUsuarioInputEnvelope
    connect?: PadreFamiliaWhereUniqueInput | PadreFamiliaWhereUniqueInput[]
  }

  export type EstudianteUncheckedCreateNestedOneWithoutUsuarioInput = {
    create?: XOR<EstudianteCreateWithoutUsuarioInput, EstudianteUncheckedCreateWithoutUsuarioInput>
    connectOrCreate?: EstudianteCreateOrConnectWithoutUsuarioInput
    connect?: EstudianteWhereUniqueInput
  }

  export type ProfesorUncheckedCreateNestedOneWithoutUsuarioInput = {
    create?: XOR<ProfesorCreateWithoutUsuarioInput, ProfesorUncheckedCreateWithoutUsuarioInput>
    connectOrCreate?: ProfesorCreateOrConnectWithoutUsuarioInput
    connect?: ProfesorWhereUniqueInput
  }

  export type PadreFamiliaUncheckedCreateNestedManyWithoutUsuarioInput = {
    create?: XOR<PadreFamiliaCreateWithoutUsuarioInput, PadreFamiliaUncheckedCreateWithoutUsuarioInput> | PadreFamiliaCreateWithoutUsuarioInput[] | PadreFamiliaUncheckedCreateWithoutUsuarioInput[]
    connectOrCreate?: PadreFamiliaCreateOrConnectWithoutUsuarioInput | PadreFamiliaCreateOrConnectWithoutUsuarioInput[]
    createMany?: PadreFamiliaCreateManyUsuarioInputEnvelope
    connect?: PadreFamiliaWhereUniqueInput | PadreFamiliaWhereUniqueInput[]
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type EnumRolUsuarioFieldUpdateOperationsInput = {
    set?: $Enums.RolUsuario
  }

  export type DateTimeFieldUpdateOperationsInput = {
    set?: Date | string
  }

  export type EstudianteUpdateOneWithoutUsuarioNestedInput = {
    create?: XOR<EstudianteCreateWithoutUsuarioInput, EstudianteUncheckedCreateWithoutUsuarioInput>
    connectOrCreate?: EstudianteCreateOrConnectWithoutUsuarioInput
    upsert?: EstudianteUpsertWithoutUsuarioInput
    disconnect?: EstudianteWhereInput | boolean
    delete?: EstudianteWhereInput | boolean
    connect?: EstudianteWhereUniqueInput
    update?: XOR<XOR<EstudianteUpdateToOneWithWhereWithoutUsuarioInput, EstudianteUpdateWithoutUsuarioInput>, EstudianteUncheckedUpdateWithoutUsuarioInput>
  }

  export type ProfesorUpdateOneWithoutUsuarioNestedInput = {
    create?: XOR<ProfesorCreateWithoutUsuarioInput, ProfesorUncheckedCreateWithoutUsuarioInput>
    connectOrCreate?: ProfesorCreateOrConnectWithoutUsuarioInput
    upsert?: ProfesorUpsertWithoutUsuarioInput
    disconnect?: ProfesorWhereInput | boolean
    delete?: ProfesorWhereInput | boolean
    connect?: ProfesorWhereUniqueInput
    update?: XOR<XOR<ProfesorUpdateToOneWithWhereWithoutUsuarioInput, ProfesorUpdateWithoutUsuarioInput>, ProfesorUncheckedUpdateWithoutUsuarioInput>
  }

  export type PadreFamiliaUpdateManyWithoutUsuarioNestedInput = {
    create?: XOR<PadreFamiliaCreateWithoutUsuarioInput, PadreFamiliaUncheckedCreateWithoutUsuarioInput> | PadreFamiliaCreateWithoutUsuarioInput[] | PadreFamiliaUncheckedCreateWithoutUsuarioInput[]
    connectOrCreate?: PadreFamiliaCreateOrConnectWithoutUsuarioInput | PadreFamiliaCreateOrConnectWithoutUsuarioInput[]
    upsert?: PadreFamiliaUpsertWithWhereUniqueWithoutUsuarioInput | PadreFamiliaUpsertWithWhereUniqueWithoutUsuarioInput[]
    createMany?: PadreFamiliaCreateManyUsuarioInputEnvelope
    set?: PadreFamiliaWhereUniqueInput | PadreFamiliaWhereUniqueInput[]
    disconnect?: PadreFamiliaWhereUniqueInput | PadreFamiliaWhereUniqueInput[]
    delete?: PadreFamiliaWhereUniqueInput | PadreFamiliaWhereUniqueInput[]
    connect?: PadreFamiliaWhereUniqueInput | PadreFamiliaWhereUniqueInput[]
    update?: PadreFamiliaUpdateWithWhereUniqueWithoutUsuarioInput | PadreFamiliaUpdateWithWhereUniqueWithoutUsuarioInput[]
    updateMany?: PadreFamiliaUpdateManyWithWhereWithoutUsuarioInput | PadreFamiliaUpdateManyWithWhereWithoutUsuarioInput[]
    deleteMany?: PadreFamiliaScalarWhereInput | PadreFamiliaScalarWhereInput[]
  }

  export type IntFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type EstudianteUncheckedUpdateOneWithoutUsuarioNestedInput = {
    create?: XOR<EstudianteCreateWithoutUsuarioInput, EstudianteUncheckedCreateWithoutUsuarioInput>
    connectOrCreate?: EstudianteCreateOrConnectWithoutUsuarioInput
    upsert?: EstudianteUpsertWithoutUsuarioInput
    disconnect?: EstudianteWhereInput | boolean
    delete?: EstudianteWhereInput | boolean
    connect?: EstudianteWhereUniqueInput
    update?: XOR<XOR<EstudianteUpdateToOneWithWhereWithoutUsuarioInput, EstudianteUpdateWithoutUsuarioInput>, EstudianteUncheckedUpdateWithoutUsuarioInput>
  }

  export type ProfesorUncheckedUpdateOneWithoutUsuarioNestedInput = {
    create?: XOR<ProfesorCreateWithoutUsuarioInput, ProfesorUncheckedCreateWithoutUsuarioInput>
    connectOrCreate?: ProfesorCreateOrConnectWithoutUsuarioInput
    upsert?: ProfesorUpsertWithoutUsuarioInput
    disconnect?: ProfesorWhereInput | boolean
    delete?: ProfesorWhereInput | boolean
    connect?: ProfesorWhereUniqueInput
    update?: XOR<XOR<ProfesorUpdateToOneWithWhereWithoutUsuarioInput, ProfesorUpdateWithoutUsuarioInput>, ProfesorUncheckedUpdateWithoutUsuarioInput>
  }

  export type PadreFamiliaUncheckedUpdateManyWithoutUsuarioNestedInput = {
    create?: XOR<PadreFamiliaCreateWithoutUsuarioInput, PadreFamiliaUncheckedCreateWithoutUsuarioInput> | PadreFamiliaCreateWithoutUsuarioInput[] | PadreFamiliaUncheckedCreateWithoutUsuarioInput[]
    connectOrCreate?: PadreFamiliaCreateOrConnectWithoutUsuarioInput | PadreFamiliaCreateOrConnectWithoutUsuarioInput[]
    upsert?: PadreFamiliaUpsertWithWhereUniqueWithoutUsuarioInput | PadreFamiliaUpsertWithWhereUniqueWithoutUsuarioInput[]
    createMany?: PadreFamiliaCreateManyUsuarioInputEnvelope
    set?: PadreFamiliaWhereUniqueInput | PadreFamiliaWhereUniqueInput[]
    disconnect?: PadreFamiliaWhereUniqueInput | PadreFamiliaWhereUniqueInput[]
    delete?: PadreFamiliaWhereUniqueInput | PadreFamiliaWhereUniqueInput[]
    connect?: PadreFamiliaWhereUniqueInput | PadreFamiliaWhereUniqueInput[]
    update?: PadreFamiliaUpdateWithWhereUniqueWithoutUsuarioInput | PadreFamiliaUpdateWithWhereUniqueWithoutUsuarioInput[]
    updateMany?: PadreFamiliaUpdateManyWithWhereWithoutUsuarioInput | PadreFamiliaUpdateManyWithWhereWithoutUsuarioInput[]
    deleteMany?: PadreFamiliaScalarWhereInput | PadreFamiliaScalarWhereInput[]
  }

  export type TramiteCreateNestedManyWithoutEstudianteInput = {
    create?: XOR<TramiteCreateWithoutEstudianteInput, TramiteUncheckedCreateWithoutEstudianteInput> | TramiteCreateWithoutEstudianteInput[] | TramiteUncheckedCreateWithoutEstudianteInput[]
    connectOrCreate?: TramiteCreateOrConnectWithoutEstudianteInput | TramiteCreateOrConnectWithoutEstudianteInput[]
    createMany?: TramiteCreateManyEstudianteInputEnvelope
    connect?: TramiteWhereUniqueInput | TramiteWhereUniqueInput[]
  }

  export type GrupoCreateNestedOneWithoutEstudiantesInput = {
    create?: XOR<GrupoCreateWithoutEstudiantesInput, GrupoUncheckedCreateWithoutEstudiantesInput>
    connectOrCreate?: GrupoCreateOrConnectWithoutEstudiantesInput
    connect?: GrupoWhereUniqueInput
  }

  export type UsuarioCreateNestedOneWithoutEstudianteInput = {
    create?: XOR<UsuarioCreateWithoutEstudianteInput, UsuarioUncheckedCreateWithoutEstudianteInput>
    connectOrCreate?: UsuarioCreateOrConnectWithoutEstudianteInput
    connect?: UsuarioWhereUniqueInput
  }

  export type PadreFamiliaCreateNestedOneWithoutEstudiantesInput = {
    create?: XOR<PadreFamiliaCreateWithoutEstudiantesInput, PadreFamiliaUncheckedCreateWithoutEstudiantesInput>
    connectOrCreate?: PadreFamiliaCreateOrConnectWithoutEstudiantesInput
    connect?: PadreFamiliaWhereUniqueInput
  }

  export type CalificacionCreateNestedManyWithoutEstudianteInput = {
    create?: XOR<CalificacionCreateWithoutEstudianteInput, CalificacionUncheckedCreateWithoutEstudianteInput> | CalificacionCreateWithoutEstudianteInput[] | CalificacionUncheckedCreateWithoutEstudianteInput[]
    connectOrCreate?: CalificacionCreateOrConnectWithoutEstudianteInput | CalificacionCreateOrConnectWithoutEstudianteInput[]
    createMany?: CalificacionCreateManyEstudianteInputEnvelope
    connect?: CalificacionWhereUniqueInput | CalificacionWhereUniqueInput[]
  }

  export type AsistenciaCreateNestedManyWithoutEstudianteInput = {
    create?: XOR<AsistenciaCreateWithoutEstudianteInput, AsistenciaUncheckedCreateWithoutEstudianteInput> | AsistenciaCreateWithoutEstudianteInput[] | AsistenciaUncheckedCreateWithoutEstudianteInput[]
    connectOrCreate?: AsistenciaCreateOrConnectWithoutEstudianteInput | AsistenciaCreateOrConnectWithoutEstudianteInput[]
    createMany?: AsistenciaCreateManyEstudianteInputEnvelope
    connect?: AsistenciaWhereUniqueInput | AsistenciaWhereUniqueInput[]
  }

  export type TramiteUncheckedCreateNestedManyWithoutEstudianteInput = {
    create?: XOR<TramiteCreateWithoutEstudianteInput, TramiteUncheckedCreateWithoutEstudianteInput> | TramiteCreateWithoutEstudianteInput[] | TramiteUncheckedCreateWithoutEstudianteInput[]
    connectOrCreate?: TramiteCreateOrConnectWithoutEstudianteInput | TramiteCreateOrConnectWithoutEstudianteInput[]
    createMany?: TramiteCreateManyEstudianteInputEnvelope
    connect?: TramiteWhereUniqueInput | TramiteWhereUniqueInput[]
  }

  export type CalificacionUncheckedCreateNestedManyWithoutEstudianteInput = {
    create?: XOR<CalificacionCreateWithoutEstudianteInput, CalificacionUncheckedCreateWithoutEstudianteInput> | CalificacionCreateWithoutEstudianteInput[] | CalificacionUncheckedCreateWithoutEstudianteInput[]
    connectOrCreate?: CalificacionCreateOrConnectWithoutEstudianteInput | CalificacionCreateOrConnectWithoutEstudianteInput[]
    createMany?: CalificacionCreateManyEstudianteInputEnvelope
    connect?: CalificacionWhereUniqueInput | CalificacionWhereUniqueInput[]
  }

  export type AsistenciaUncheckedCreateNestedManyWithoutEstudianteInput = {
    create?: XOR<AsistenciaCreateWithoutEstudianteInput, AsistenciaUncheckedCreateWithoutEstudianteInput> | AsistenciaCreateWithoutEstudianteInput[] | AsistenciaUncheckedCreateWithoutEstudianteInput[]
    connectOrCreate?: AsistenciaCreateOrConnectWithoutEstudianteInput | AsistenciaCreateOrConnectWithoutEstudianteInput[]
    createMany?: AsistenciaCreateManyEstudianteInputEnvelope
    connect?: AsistenciaWhereUniqueInput | AsistenciaWhereUniqueInput[]
  }

  export type EnumEstadoEstudianteFieldUpdateOperationsInput = {
    set?: $Enums.EstadoEstudiante
  }

  export type TramiteUpdateManyWithoutEstudianteNestedInput = {
    create?: XOR<TramiteCreateWithoutEstudianteInput, TramiteUncheckedCreateWithoutEstudianteInput> | TramiteCreateWithoutEstudianteInput[] | TramiteUncheckedCreateWithoutEstudianteInput[]
    connectOrCreate?: TramiteCreateOrConnectWithoutEstudianteInput | TramiteCreateOrConnectWithoutEstudianteInput[]
    upsert?: TramiteUpsertWithWhereUniqueWithoutEstudianteInput | TramiteUpsertWithWhereUniqueWithoutEstudianteInput[]
    createMany?: TramiteCreateManyEstudianteInputEnvelope
    set?: TramiteWhereUniqueInput | TramiteWhereUniqueInput[]
    disconnect?: TramiteWhereUniqueInput | TramiteWhereUniqueInput[]
    delete?: TramiteWhereUniqueInput | TramiteWhereUniqueInput[]
    connect?: TramiteWhereUniqueInput | TramiteWhereUniqueInput[]
    update?: TramiteUpdateWithWhereUniqueWithoutEstudianteInput | TramiteUpdateWithWhereUniqueWithoutEstudianteInput[]
    updateMany?: TramiteUpdateManyWithWhereWithoutEstudianteInput | TramiteUpdateManyWithWhereWithoutEstudianteInput[]
    deleteMany?: TramiteScalarWhereInput | TramiteScalarWhereInput[]
  }

  export type GrupoUpdateOneWithoutEstudiantesNestedInput = {
    create?: XOR<GrupoCreateWithoutEstudiantesInput, GrupoUncheckedCreateWithoutEstudiantesInput>
    connectOrCreate?: GrupoCreateOrConnectWithoutEstudiantesInput
    upsert?: GrupoUpsertWithoutEstudiantesInput
    disconnect?: GrupoWhereInput | boolean
    delete?: GrupoWhereInput | boolean
    connect?: GrupoWhereUniqueInput
    update?: XOR<XOR<GrupoUpdateToOneWithWhereWithoutEstudiantesInput, GrupoUpdateWithoutEstudiantesInput>, GrupoUncheckedUpdateWithoutEstudiantesInput>
  }

  export type UsuarioUpdateOneRequiredWithoutEstudianteNestedInput = {
    create?: XOR<UsuarioCreateWithoutEstudianteInput, UsuarioUncheckedCreateWithoutEstudianteInput>
    connectOrCreate?: UsuarioCreateOrConnectWithoutEstudianteInput
    upsert?: UsuarioUpsertWithoutEstudianteInput
    connect?: UsuarioWhereUniqueInput
    update?: XOR<XOR<UsuarioUpdateToOneWithWhereWithoutEstudianteInput, UsuarioUpdateWithoutEstudianteInput>, UsuarioUncheckedUpdateWithoutEstudianteInput>
  }

  export type PadreFamiliaUpdateOneWithoutEstudiantesNestedInput = {
    create?: XOR<PadreFamiliaCreateWithoutEstudiantesInput, PadreFamiliaUncheckedCreateWithoutEstudiantesInput>
    connectOrCreate?: PadreFamiliaCreateOrConnectWithoutEstudiantesInput
    upsert?: PadreFamiliaUpsertWithoutEstudiantesInput
    disconnect?: PadreFamiliaWhereInput | boolean
    delete?: PadreFamiliaWhereInput | boolean
    connect?: PadreFamiliaWhereUniqueInput
    update?: XOR<XOR<PadreFamiliaUpdateToOneWithWhereWithoutEstudiantesInput, PadreFamiliaUpdateWithoutEstudiantesInput>, PadreFamiliaUncheckedUpdateWithoutEstudiantesInput>
  }

  export type CalificacionUpdateManyWithoutEstudianteNestedInput = {
    create?: XOR<CalificacionCreateWithoutEstudianteInput, CalificacionUncheckedCreateWithoutEstudianteInput> | CalificacionCreateWithoutEstudianteInput[] | CalificacionUncheckedCreateWithoutEstudianteInput[]
    connectOrCreate?: CalificacionCreateOrConnectWithoutEstudianteInput | CalificacionCreateOrConnectWithoutEstudianteInput[]
    upsert?: CalificacionUpsertWithWhereUniqueWithoutEstudianteInput | CalificacionUpsertWithWhereUniqueWithoutEstudianteInput[]
    createMany?: CalificacionCreateManyEstudianteInputEnvelope
    set?: CalificacionWhereUniqueInput | CalificacionWhereUniqueInput[]
    disconnect?: CalificacionWhereUniqueInput | CalificacionWhereUniqueInput[]
    delete?: CalificacionWhereUniqueInput | CalificacionWhereUniqueInput[]
    connect?: CalificacionWhereUniqueInput | CalificacionWhereUniqueInput[]
    update?: CalificacionUpdateWithWhereUniqueWithoutEstudianteInput | CalificacionUpdateWithWhereUniqueWithoutEstudianteInput[]
    updateMany?: CalificacionUpdateManyWithWhereWithoutEstudianteInput | CalificacionUpdateManyWithWhereWithoutEstudianteInput[]
    deleteMany?: CalificacionScalarWhereInput | CalificacionScalarWhereInput[]
  }

  export type AsistenciaUpdateManyWithoutEstudianteNestedInput = {
    create?: XOR<AsistenciaCreateWithoutEstudianteInput, AsistenciaUncheckedCreateWithoutEstudianteInput> | AsistenciaCreateWithoutEstudianteInput[] | AsistenciaUncheckedCreateWithoutEstudianteInput[]
    connectOrCreate?: AsistenciaCreateOrConnectWithoutEstudianteInput | AsistenciaCreateOrConnectWithoutEstudianteInput[]
    upsert?: AsistenciaUpsertWithWhereUniqueWithoutEstudianteInput | AsistenciaUpsertWithWhereUniqueWithoutEstudianteInput[]
    createMany?: AsistenciaCreateManyEstudianteInputEnvelope
    set?: AsistenciaWhereUniqueInput | AsistenciaWhereUniqueInput[]
    disconnect?: AsistenciaWhereUniqueInput | AsistenciaWhereUniqueInput[]
    delete?: AsistenciaWhereUniqueInput | AsistenciaWhereUniqueInput[]
    connect?: AsistenciaWhereUniqueInput | AsistenciaWhereUniqueInput[]
    update?: AsistenciaUpdateWithWhereUniqueWithoutEstudianteInput | AsistenciaUpdateWithWhereUniqueWithoutEstudianteInput[]
    updateMany?: AsistenciaUpdateManyWithWhereWithoutEstudianteInput | AsistenciaUpdateManyWithWhereWithoutEstudianteInput[]
    deleteMany?: AsistenciaScalarWhereInput | AsistenciaScalarWhereInput[]
  }

  export type NullableIntFieldUpdateOperationsInput = {
    set?: number | null
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type TramiteUncheckedUpdateManyWithoutEstudianteNestedInput = {
    create?: XOR<TramiteCreateWithoutEstudianteInput, TramiteUncheckedCreateWithoutEstudianteInput> | TramiteCreateWithoutEstudianteInput[] | TramiteUncheckedCreateWithoutEstudianteInput[]
    connectOrCreate?: TramiteCreateOrConnectWithoutEstudianteInput | TramiteCreateOrConnectWithoutEstudianteInput[]
    upsert?: TramiteUpsertWithWhereUniqueWithoutEstudianteInput | TramiteUpsertWithWhereUniqueWithoutEstudianteInput[]
    createMany?: TramiteCreateManyEstudianteInputEnvelope
    set?: TramiteWhereUniqueInput | TramiteWhereUniqueInput[]
    disconnect?: TramiteWhereUniqueInput | TramiteWhereUniqueInput[]
    delete?: TramiteWhereUniqueInput | TramiteWhereUniqueInput[]
    connect?: TramiteWhereUniqueInput | TramiteWhereUniqueInput[]
    update?: TramiteUpdateWithWhereUniqueWithoutEstudianteInput | TramiteUpdateWithWhereUniqueWithoutEstudianteInput[]
    updateMany?: TramiteUpdateManyWithWhereWithoutEstudianteInput | TramiteUpdateManyWithWhereWithoutEstudianteInput[]
    deleteMany?: TramiteScalarWhereInput | TramiteScalarWhereInput[]
  }

  export type CalificacionUncheckedUpdateManyWithoutEstudianteNestedInput = {
    create?: XOR<CalificacionCreateWithoutEstudianteInput, CalificacionUncheckedCreateWithoutEstudianteInput> | CalificacionCreateWithoutEstudianteInput[] | CalificacionUncheckedCreateWithoutEstudianteInput[]
    connectOrCreate?: CalificacionCreateOrConnectWithoutEstudianteInput | CalificacionCreateOrConnectWithoutEstudianteInput[]
    upsert?: CalificacionUpsertWithWhereUniqueWithoutEstudianteInput | CalificacionUpsertWithWhereUniqueWithoutEstudianteInput[]
    createMany?: CalificacionCreateManyEstudianteInputEnvelope
    set?: CalificacionWhereUniqueInput | CalificacionWhereUniqueInput[]
    disconnect?: CalificacionWhereUniqueInput | CalificacionWhereUniqueInput[]
    delete?: CalificacionWhereUniqueInput | CalificacionWhereUniqueInput[]
    connect?: CalificacionWhereUniqueInput | CalificacionWhereUniqueInput[]
    update?: CalificacionUpdateWithWhereUniqueWithoutEstudianteInput | CalificacionUpdateWithWhereUniqueWithoutEstudianteInput[]
    updateMany?: CalificacionUpdateManyWithWhereWithoutEstudianteInput | CalificacionUpdateManyWithWhereWithoutEstudianteInput[]
    deleteMany?: CalificacionScalarWhereInput | CalificacionScalarWhereInput[]
  }

  export type AsistenciaUncheckedUpdateManyWithoutEstudianteNestedInput = {
    create?: XOR<AsistenciaCreateWithoutEstudianteInput, AsistenciaUncheckedCreateWithoutEstudianteInput> | AsistenciaCreateWithoutEstudianteInput[] | AsistenciaUncheckedCreateWithoutEstudianteInput[]
    connectOrCreate?: AsistenciaCreateOrConnectWithoutEstudianteInput | AsistenciaCreateOrConnectWithoutEstudianteInput[]
    upsert?: AsistenciaUpsertWithWhereUniqueWithoutEstudianteInput | AsistenciaUpsertWithWhereUniqueWithoutEstudianteInput[]
    createMany?: AsistenciaCreateManyEstudianteInputEnvelope
    set?: AsistenciaWhereUniqueInput | AsistenciaWhereUniqueInput[]
    disconnect?: AsistenciaWhereUniqueInput | AsistenciaWhereUniqueInput[]
    delete?: AsistenciaWhereUniqueInput | AsistenciaWhereUniqueInput[]
    connect?: AsistenciaWhereUniqueInput | AsistenciaWhereUniqueInput[]
    update?: AsistenciaUpdateWithWhereUniqueWithoutEstudianteInput | AsistenciaUpdateWithWhereUniqueWithoutEstudianteInput[]
    updateMany?: AsistenciaUpdateManyWithWhereWithoutEstudianteInput | AsistenciaUpdateManyWithWhereWithoutEstudianteInput[]
    deleteMany?: AsistenciaScalarWhereInput | AsistenciaScalarWhereInput[]
  }

  export type UsuarioCreateNestedOneWithoutProfesorInput = {
    create?: XOR<UsuarioCreateWithoutProfesorInput, UsuarioUncheckedCreateWithoutProfesorInput>
    connectOrCreate?: UsuarioCreateOrConnectWithoutProfesorInput
    connect?: UsuarioWhereUniqueInput
  }

  export type MaterialEducativoCreateNestedManyWithoutProfesorInput = {
    create?: XOR<MaterialEducativoCreateWithoutProfesorInput, MaterialEducativoUncheckedCreateWithoutProfesorInput> | MaterialEducativoCreateWithoutProfesorInput[] | MaterialEducativoUncheckedCreateWithoutProfesorInput[]
    connectOrCreate?: MaterialEducativoCreateOrConnectWithoutProfesorInput | MaterialEducativoCreateOrConnectWithoutProfesorInput[]
    createMany?: MaterialEducativoCreateManyProfesorInputEnvelope
    connect?: MaterialEducativoWhereUniqueInput | MaterialEducativoWhereUniqueInput[]
  }

  export type MateriaCreateNestedManyWithoutProfesorInput = {
    create?: XOR<MateriaCreateWithoutProfesorInput, MateriaUncheckedCreateWithoutProfesorInput> | MateriaCreateWithoutProfesorInput[] | MateriaUncheckedCreateWithoutProfesorInput[]
    connectOrCreate?: MateriaCreateOrConnectWithoutProfesorInput | MateriaCreateOrConnectWithoutProfesorInput[]
    createMany?: MateriaCreateManyProfesorInputEnvelope
    connect?: MateriaWhereUniqueInput | MateriaWhereUniqueInput[]
  }

  export type MaterialEducativoUncheckedCreateNestedManyWithoutProfesorInput = {
    create?: XOR<MaterialEducativoCreateWithoutProfesorInput, MaterialEducativoUncheckedCreateWithoutProfesorInput> | MaterialEducativoCreateWithoutProfesorInput[] | MaterialEducativoUncheckedCreateWithoutProfesorInput[]
    connectOrCreate?: MaterialEducativoCreateOrConnectWithoutProfesorInput | MaterialEducativoCreateOrConnectWithoutProfesorInput[]
    createMany?: MaterialEducativoCreateManyProfesorInputEnvelope
    connect?: MaterialEducativoWhereUniqueInput | MaterialEducativoWhereUniqueInput[]
  }

  export type MateriaUncheckedCreateNestedManyWithoutProfesorInput = {
    create?: XOR<MateriaCreateWithoutProfesorInput, MateriaUncheckedCreateWithoutProfesorInput> | MateriaCreateWithoutProfesorInput[] | MateriaUncheckedCreateWithoutProfesorInput[]
    connectOrCreate?: MateriaCreateOrConnectWithoutProfesorInput | MateriaCreateOrConnectWithoutProfesorInput[]
    createMany?: MateriaCreateManyProfesorInputEnvelope
    connect?: MateriaWhereUniqueInput | MateriaWhereUniqueInput[]
  }

  export type UsuarioUpdateOneRequiredWithoutProfesorNestedInput = {
    create?: XOR<UsuarioCreateWithoutProfesorInput, UsuarioUncheckedCreateWithoutProfesorInput>
    connectOrCreate?: UsuarioCreateOrConnectWithoutProfesorInput
    upsert?: UsuarioUpsertWithoutProfesorInput
    connect?: UsuarioWhereUniqueInput
    update?: XOR<XOR<UsuarioUpdateToOneWithWhereWithoutProfesorInput, UsuarioUpdateWithoutProfesorInput>, UsuarioUncheckedUpdateWithoutProfesorInput>
  }

  export type MaterialEducativoUpdateManyWithoutProfesorNestedInput = {
    create?: XOR<MaterialEducativoCreateWithoutProfesorInput, MaterialEducativoUncheckedCreateWithoutProfesorInput> | MaterialEducativoCreateWithoutProfesorInput[] | MaterialEducativoUncheckedCreateWithoutProfesorInput[]
    connectOrCreate?: MaterialEducativoCreateOrConnectWithoutProfesorInput | MaterialEducativoCreateOrConnectWithoutProfesorInput[]
    upsert?: MaterialEducativoUpsertWithWhereUniqueWithoutProfesorInput | MaterialEducativoUpsertWithWhereUniqueWithoutProfesorInput[]
    createMany?: MaterialEducativoCreateManyProfesorInputEnvelope
    set?: MaterialEducativoWhereUniqueInput | MaterialEducativoWhereUniqueInput[]
    disconnect?: MaterialEducativoWhereUniqueInput | MaterialEducativoWhereUniqueInput[]
    delete?: MaterialEducativoWhereUniqueInput | MaterialEducativoWhereUniqueInput[]
    connect?: MaterialEducativoWhereUniqueInput | MaterialEducativoWhereUniqueInput[]
    update?: MaterialEducativoUpdateWithWhereUniqueWithoutProfesorInput | MaterialEducativoUpdateWithWhereUniqueWithoutProfesorInput[]
    updateMany?: MaterialEducativoUpdateManyWithWhereWithoutProfesorInput | MaterialEducativoUpdateManyWithWhereWithoutProfesorInput[]
    deleteMany?: MaterialEducativoScalarWhereInput | MaterialEducativoScalarWhereInput[]
  }

  export type MateriaUpdateManyWithoutProfesorNestedInput = {
    create?: XOR<MateriaCreateWithoutProfesorInput, MateriaUncheckedCreateWithoutProfesorInput> | MateriaCreateWithoutProfesorInput[] | MateriaUncheckedCreateWithoutProfesorInput[]
    connectOrCreate?: MateriaCreateOrConnectWithoutProfesorInput | MateriaCreateOrConnectWithoutProfesorInput[]
    upsert?: MateriaUpsertWithWhereUniqueWithoutProfesorInput | MateriaUpsertWithWhereUniqueWithoutProfesorInput[]
    createMany?: MateriaCreateManyProfesorInputEnvelope
    set?: MateriaWhereUniqueInput | MateriaWhereUniqueInput[]
    disconnect?: MateriaWhereUniqueInput | MateriaWhereUniqueInput[]
    delete?: MateriaWhereUniqueInput | MateriaWhereUniqueInput[]
    connect?: MateriaWhereUniqueInput | MateriaWhereUniqueInput[]
    update?: MateriaUpdateWithWhereUniqueWithoutProfesorInput | MateriaUpdateWithWhereUniqueWithoutProfesorInput[]
    updateMany?: MateriaUpdateManyWithWhereWithoutProfesorInput | MateriaUpdateManyWithWhereWithoutProfesorInput[]
    deleteMany?: MateriaScalarWhereInput | MateriaScalarWhereInput[]
  }

  export type MaterialEducativoUncheckedUpdateManyWithoutProfesorNestedInput = {
    create?: XOR<MaterialEducativoCreateWithoutProfesorInput, MaterialEducativoUncheckedCreateWithoutProfesorInput> | MaterialEducativoCreateWithoutProfesorInput[] | MaterialEducativoUncheckedCreateWithoutProfesorInput[]
    connectOrCreate?: MaterialEducativoCreateOrConnectWithoutProfesorInput | MaterialEducativoCreateOrConnectWithoutProfesorInput[]
    upsert?: MaterialEducativoUpsertWithWhereUniqueWithoutProfesorInput | MaterialEducativoUpsertWithWhereUniqueWithoutProfesorInput[]
    createMany?: MaterialEducativoCreateManyProfesorInputEnvelope
    set?: MaterialEducativoWhereUniqueInput | MaterialEducativoWhereUniqueInput[]
    disconnect?: MaterialEducativoWhereUniqueInput | MaterialEducativoWhereUniqueInput[]
    delete?: MaterialEducativoWhereUniqueInput | MaterialEducativoWhereUniqueInput[]
    connect?: MaterialEducativoWhereUniqueInput | MaterialEducativoWhereUniqueInput[]
    update?: MaterialEducativoUpdateWithWhereUniqueWithoutProfesorInput | MaterialEducativoUpdateWithWhereUniqueWithoutProfesorInput[]
    updateMany?: MaterialEducativoUpdateManyWithWhereWithoutProfesorInput | MaterialEducativoUpdateManyWithWhereWithoutProfesorInput[]
    deleteMany?: MaterialEducativoScalarWhereInput | MaterialEducativoScalarWhereInput[]
  }

  export type MateriaUncheckedUpdateManyWithoutProfesorNestedInput = {
    create?: XOR<MateriaCreateWithoutProfesorInput, MateriaUncheckedCreateWithoutProfesorInput> | MateriaCreateWithoutProfesorInput[] | MateriaUncheckedCreateWithoutProfesorInput[]
    connectOrCreate?: MateriaCreateOrConnectWithoutProfesorInput | MateriaCreateOrConnectWithoutProfesorInput[]
    upsert?: MateriaUpsertWithWhereUniqueWithoutProfesorInput | MateriaUpsertWithWhereUniqueWithoutProfesorInput[]
    createMany?: MateriaCreateManyProfesorInputEnvelope
    set?: MateriaWhereUniqueInput | MateriaWhereUniqueInput[]
    disconnect?: MateriaWhereUniqueInput | MateriaWhereUniqueInput[]
    delete?: MateriaWhereUniqueInput | MateriaWhereUniqueInput[]
    connect?: MateriaWhereUniqueInput | MateriaWhereUniqueInput[]
    update?: MateriaUpdateWithWhereUniqueWithoutProfesorInput | MateriaUpdateWithWhereUniqueWithoutProfesorInput[]
    updateMany?: MateriaUpdateManyWithWhereWithoutProfesorInput | MateriaUpdateManyWithWhereWithoutProfesorInput[]
    deleteMany?: MateriaScalarWhereInput | MateriaScalarWhereInput[]
  }

  export type UsuarioCreateNestedOneWithoutPadreFamiliaInput = {
    create?: XOR<UsuarioCreateWithoutPadreFamiliaInput, UsuarioUncheckedCreateWithoutPadreFamiliaInput>
    connectOrCreate?: UsuarioCreateOrConnectWithoutPadreFamiliaInput
    connect?: UsuarioWhereUniqueInput
  }

  export type EstudianteCreateNestedManyWithoutPadreFamiliaInput = {
    create?: XOR<EstudianteCreateWithoutPadreFamiliaInput, EstudianteUncheckedCreateWithoutPadreFamiliaInput> | EstudianteCreateWithoutPadreFamiliaInput[] | EstudianteUncheckedCreateWithoutPadreFamiliaInput[]
    connectOrCreate?: EstudianteCreateOrConnectWithoutPadreFamiliaInput | EstudianteCreateOrConnectWithoutPadreFamiliaInput[]
    createMany?: EstudianteCreateManyPadreFamiliaInputEnvelope
    connect?: EstudianteWhereUniqueInput | EstudianteWhereUniqueInput[]
  }

  export type EstudianteUncheckedCreateNestedManyWithoutPadreFamiliaInput = {
    create?: XOR<EstudianteCreateWithoutPadreFamiliaInput, EstudianteUncheckedCreateWithoutPadreFamiliaInput> | EstudianteCreateWithoutPadreFamiliaInput[] | EstudianteUncheckedCreateWithoutPadreFamiliaInput[]
    connectOrCreate?: EstudianteCreateOrConnectWithoutPadreFamiliaInput | EstudianteCreateOrConnectWithoutPadreFamiliaInput[]
    createMany?: EstudianteCreateManyPadreFamiliaInputEnvelope
    connect?: EstudianteWhereUniqueInput | EstudianteWhereUniqueInput[]
  }

  export type UsuarioUpdateOneRequiredWithoutPadreFamiliaNestedInput = {
    create?: XOR<UsuarioCreateWithoutPadreFamiliaInput, UsuarioUncheckedCreateWithoutPadreFamiliaInput>
    connectOrCreate?: UsuarioCreateOrConnectWithoutPadreFamiliaInput
    upsert?: UsuarioUpsertWithoutPadreFamiliaInput
    connect?: UsuarioWhereUniqueInput
    update?: XOR<XOR<UsuarioUpdateToOneWithWhereWithoutPadreFamiliaInput, UsuarioUpdateWithoutPadreFamiliaInput>, UsuarioUncheckedUpdateWithoutPadreFamiliaInput>
  }

  export type EstudianteUpdateManyWithoutPadreFamiliaNestedInput = {
    create?: XOR<EstudianteCreateWithoutPadreFamiliaInput, EstudianteUncheckedCreateWithoutPadreFamiliaInput> | EstudianteCreateWithoutPadreFamiliaInput[] | EstudianteUncheckedCreateWithoutPadreFamiliaInput[]
    connectOrCreate?: EstudianteCreateOrConnectWithoutPadreFamiliaInput | EstudianteCreateOrConnectWithoutPadreFamiliaInput[]
    upsert?: EstudianteUpsertWithWhereUniqueWithoutPadreFamiliaInput | EstudianteUpsertWithWhereUniqueWithoutPadreFamiliaInput[]
    createMany?: EstudianteCreateManyPadreFamiliaInputEnvelope
    set?: EstudianteWhereUniqueInput | EstudianteWhereUniqueInput[]
    disconnect?: EstudianteWhereUniqueInput | EstudianteWhereUniqueInput[]
    delete?: EstudianteWhereUniqueInput | EstudianteWhereUniqueInput[]
    connect?: EstudianteWhereUniqueInput | EstudianteWhereUniqueInput[]
    update?: EstudianteUpdateWithWhereUniqueWithoutPadreFamiliaInput | EstudianteUpdateWithWhereUniqueWithoutPadreFamiliaInput[]
    updateMany?: EstudianteUpdateManyWithWhereWithoutPadreFamiliaInput | EstudianteUpdateManyWithWhereWithoutPadreFamiliaInput[]
    deleteMany?: EstudianteScalarWhereInput | EstudianteScalarWhereInput[]
  }

  export type EstudianteUncheckedUpdateManyWithoutPadreFamiliaNestedInput = {
    create?: XOR<EstudianteCreateWithoutPadreFamiliaInput, EstudianteUncheckedCreateWithoutPadreFamiliaInput> | EstudianteCreateWithoutPadreFamiliaInput[] | EstudianteUncheckedCreateWithoutPadreFamiliaInput[]
    connectOrCreate?: EstudianteCreateOrConnectWithoutPadreFamiliaInput | EstudianteCreateOrConnectWithoutPadreFamiliaInput[]
    upsert?: EstudianteUpsertWithWhereUniqueWithoutPadreFamiliaInput | EstudianteUpsertWithWhereUniqueWithoutPadreFamiliaInput[]
    createMany?: EstudianteCreateManyPadreFamiliaInputEnvelope
    set?: EstudianteWhereUniqueInput | EstudianteWhereUniqueInput[]
    disconnect?: EstudianteWhereUniqueInput | EstudianteWhereUniqueInput[]
    delete?: EstudianteWhereUniqueInput | EstudianteWhereUniqueInput[]
    connect?: EstudianteWhereUniqueInput | EstudianteWhereUniqueInput[]
    update?: EstudianteUpdateWithWhereUniqueWithoutPadreFamiliaInput | EstudianteUpdateWithWhereUniqueWithoutPadreFamiliaInput[]
    updateMany?: EstudianteUpdateManyWithWhereWithoutPadreFamiliaInput | EstudianteUpdateManyWithWhereWithoutPadreFamiliaInput[]
    deleteMany?: EstudianteScalarWhereInput | EstudianteScalarWhereInput[]
  }

  export type EstudianteCreateNestedManyWithoutGrupoInput = {
    create?: XOR<EstudianteCreateWithoutGrupoInput, EstudianteUncheckedCreateWithoutGrupoInput> | EstudianteCreateWithoutGrupoInput[] | EstudianteUncheckedCreateWithoutGrupoInput[]
    connectOrCreate?: EstudianteCreateOrConnectWithoutGrupoInput | EstudianteCreateOrConnectWithoutGrupoInput[]
    createMany?: EstudianteCreateManyGrupoInputEnvelope
    connect?: EstudianteWhereUniqueInput | EstudianteWhereUniqueInput[]
  }

  export type InscripcionCreateNestedManyWithoutGrupoInput = {
    create?: XOR<InscripcionCreateWithoutGrupoInput, InscripcionUncheckedCreateWithoutGrupoInput> | InscripcionCreateWithoutGrupoInput[] | InscripcionUncheckedCreateWithoutGrupoInput[]
    connectOrCreate?: InscripcionCreateOrConnectWithoutGrupoInput | InscripcionCreateOrConnectWithoutGrupoInput[]
    createMany?: InscripcionCreateManyGrupoInputEnvelope
    connect?: InscripcionWhereUniqueInput | InscripcionWhereUniqueInput[]
  }

  export type MaterialEducativoCreateNestedManyWithoutGrupoInput = {
    create?: XOR<MaterialEducativoCreateWithoutGrupoInput, MaterialEducativoUncheckedCreateWithoutGrupoInput> | MaterialEducativoCreateWithoutGrupoInput[] | MaterialEducativoUncheckedCreateWithoutGrupoInput[]
    connectOrCreate?: MaterialEducativoCreateOrConnectWithoutGrupoInput | MaterialEducativoCreateOrConnectWithoutGrupoInput[]
    createMany?: MaterialEducativoCreateManyGrupoInputEnvelope
    connect?: MaterialEducativoWhereUniqueInput | MaterialEducativoWhereUniqueInput[]
  }

  export type EstudianteUncheckedCreateNestedManyWithoutGrupoInput = {
    create?: XOR<EstudianteCreateWithoutGrupoInput, EstudianteUncheckedCreateWithoutGrupoInput> | EstudianteCreateWithoutGrupoInput[] | EstudianteUncheckedCreateWithoutGrupoInput[]
    connectOrCreate?: EstudianteCreateOrConnectWithoutGrupoInput | EstudianteCreateOrConnectWithoutGrupoInput[]
    createMany?: EstudianteCreateManyGrupoInputEnvelope
    connect?: EstudianteWhereUniqueInput | EstudianteWhereUniqueInput[]
  }

  export type InscripcionUncheckedCreateNestedManyWithoutGrupoInput = {
    create?: XOR<InscripcionCreateWithoutGrupoInput, InscripcionUncheckedCreateWithoutGrupoInput> | InscripcionCreateWithoutGrupoInput[] | InscripcionUncheckedCreateWithoutGrupoInput[]
    connectOrCreate?: InscripcionCreateOrConnectWithoutGrupoInput | InscripcionCreateOrConnectWithoutGrupoInput[]
    createMany?: InscripcionCreateManyGrupoInputEnvelope
    connect?: InscripcionWhereUniqueInput | InscripcionWhereUniqueInput[]
  }

  export type MaterialEducativoUncheckedCreateNestedManyWithoutGrupoInput = {
    create?: XOR<MaterialEducativoCreateWithoutGrupoInput, MaterialEducativoUncheckedCreateWithoutGrupoInput> | MaterialEducativoCreateWithoutGrupoInput[] | MaterialEducativoUncheckedCreateWithoutGrupoInput[]
    connectOrCreate?: MaterialEducativoCreateOrConnectWithoutGrupoInput | MaterialEducativoCreateOrConnectWithoutGrupoInput[]
    createMany?: MaterialEducativoCreateManyGrupoInputEnvelope
    connect?: MaterialEducativoWhereUniqueInput | MaterialEducativoWhereUniqueInput[]
  }

  export type EstudianteUpdateManyWithoutGrupoNestedInput = {
    create?: XOR<EstudianteCreateWithoutGrupoInput, EstudianteUncheckedCreateWithoutGrupoInput> | EstudianteCreateWithoutGrupoInput[] | EstudianteUncheckedCreateWithoutGrupoInput[]
    connectOrCreate?: EstudianteCreateOrConnectWithoutGrupoInput | EstudianteCreateOrConnectWithoutGrupoInput[]
    upsert?: EstudianteUpsertWithWhereUniqueWithoutGrupoInput | EstudianteUpsertWithWhereUniqueWithoutGrupoInput[]
    createMany?: EstudianteCreateManyGrupoInputEnvelope
    set?: EstudianteWhereUniqueInput | EstudianteWhereUniqueInput[]
    disconnect?: EstudianteWhereUniqueInput | EstudianteWhereUniqueInput[]
    delete?: EstudianteWhereUniqueInput | EstudianteWhereUniqueInput[]
    connect?: EstudianteWhereUniqueInput | EstudianteWhereUniqueInput[]
    update?: EstudianteUpdateWithWhereUniqueWithoutGrupoInput | EstudianteUpdateWithWhereUniqueWithoutGrupoInput[]
    updateMany?: EstudianteUpdateManyWithWhereWithoutGrupoInput | EstudianteUpdateManyWithWhereWithoutGrupoInput[]
    deleteMany?: EstudianteScalarWhereInput | EstudianteScalarWhereInput[]
  }

  export type InscripcionUpdateManyWithoutGrupoNestedInput = {
    create?: XOR<InscripcionCreateWithoutGrupoInput, InscripcionUncheckedCreateWithoutGrupoInput> | InscripcionCreateWithoutGrupoInput[] | InscripcionUncheckedCreateWithoutGrupoInput[]
    connectOrCreate?: InscripcionCreateOrConnectWithoutGrupoInput | InscripcionCreateOrConnectWithoutGrupoInput[]
    upsert?: InscripcionUpsertWithWhereUniqueWithoutGrupoInput | InscripcionUpsertWithWhereUniqueWithoutGrupoInput[]
    createMany?: InscripcionCreateManyGrupoInputEnvelope
    set?: InscripcionWhereUniqueInput | InscripcionWhereUniqueInput[]
    disconnect?: InscripcionWhereUniqueInput | InscripcionWhereUniqueInput[]
    delete?: InscripcionWhereUniqueInput | InscripcionWhereUniqueInput[]
    connect?: InscripcionWhereUniqueInput | InscripcionWhereUniqueInput[]
    update?: InscripcionUpdateWithWhereUniqueWithoutGrupoInput | InscripcionUpdateWithWhereUniqueWithoutGrupoInput[]
    updateMany?: InscripcionUpdateManyWithWhereWithoutGrupoInput | InscripcionUpdateManyWithWhereWithoutGrupoInput[]
    deleteMany?: InscripcionScalarWhereInput | InscripcionScalarWhereInput[]
  }

  export type MaterialEducativoUpdateManyWithoutGrupoNestedInput = {
    create?: XOR<MaterialEducativoCreateWithoutGrupoInput, MaterialEducativoUncheckedCreateWithoutGrupoInput> | MaterialEducativoCreateWithoutGrupoInput[] | MaterialEducativoUncheckedCreateWithoutGrupoInput[]
    connectOrCreate?: MaterialEducativoCreateOrConnectWithoutGrupoInput | MaterialEducativoCreateOrConnectWithoutGrupoInput[]
    upsert?: MaterialEducativoUpsertWithWhereUniqueWithoutGrupoInput | MaterialEducativoUpsertWithWhereUniqueWithoutGrupoInput[]
    createMany?: MaterialEducativoCreateManyGrupoInputEnvelope
    set?: MaterialEducativoWhereUniqueInput | MaterialEducativoWhereUniqueInput[]
    disconnect?: MaterialEducativoWhereUniqueInput | MaterialEducativoWhereUniqueInput[]
    delete?: MaterialEducativoWhereUniqueInput | MaterialEducativoWhereUniqueInput[]
    connect?: MaterialEducativoWhereUniqueInput | MaterialEducativoWhereUniqueInput[]
    update?: MaterialEducativoUpdateWithWhereUniqueWithoutGrupoInput | MaterialEducativoUpdateWithWhereUniqueWithoutGrupoInput[]
    updateMany?: MaterialEducativoUpdateManyWithWhereWithoutGrupoInput | MaterialEducativoUpdateManyWithWhereWithoutGrupoInput[]
    deleteMany?: MaterialEducativoScalarWhereInput | MaterialEducativoScalarWhereInput[]
  }

  export type EstudianteUncheckedUpdateManyWithoutGrupoNestedInput = {
    create?: XOR<EstudianteCreateWithoutGrupoInput, EstudianteUncheckedCreateWithoutGrupoInput> | EstudianteCreateWithoutGrupoInput[] | EstudianteUncheckedCreateWithoutGrupoInput[]
    connectOrCreate?: EstudianteCreateOrConnectWithoutGrupoInput | EstudianteCreateOrConnectWithoutGrupoInput[]
    upsert?: EstudianteUpsertWithWhereUniqueWithoutGrupoInput | EstudianteUpsertWithWhereUniqueWithoutGrupoInput[]
    createMany?: EstudianteCreateManyGrupoInputEnvelope
    set?: EstudianteWhereUniqueInput | EstudianteWhereUniqueInput[]
    disconnect?: EstudianteWhereUniqueInput | EstudianteWhereUniqueInput[]
    delete?: EstudianteWhereUniqueInput | EstudianteWhereUniqueInput[]
    connect?: EstudianteWhereUniqueInput | EstudianteWhereUniqueInput[]
    update?: EstudianteUpdateWithWhereUniqueWithoutGrupoInput | EstudianteUpdateWithWhereUniqueWithoutGrupoInput[]
    updateMany?: EstudianteUpdateManyWithWhereWithoutGrupoInput | EstudianteUpdateManyWithWhereWithoutGrupoInput[]
    deleteMany?: EstudianteScalarWhereInput | EstudianteScalarWhereInput[]
  }

  export type InscripcionUncheckedUpdateManyWithoutGrupoNestedInput = {
    create?: XOR<InscripcionCreateWithoutGrupoInput, InscripcionUncheckedCreateWithoutGrupoInput> | InscripcionCreateWithoutGrupoInput[] | InscripcionUncheckedCreateWithoutGrupoInput[]
    connectOrCreate?: InscripcionCreateOrConnectWithoutGrupoInput | InscripcionCreateOrConnectWithoutGrupoInput[]
    upsert?: InscripcionUpsertWithWhereUniqueWithoutGrupoInput | InscripcionUpsertWithWhereUniqueWithoutGrupoInput[]
    createMany?: InscripcionCreateManyGrupoInputEnvelope
    set?: InscripcionWhereUniqueInput | InscripcionWhereUniqueInput[]
    disconnect?: InscripcionWhereUniqueInput | InscripcionWhereUniqueInput[]
    delete?: InscripcionWhereUniqueInput | InscripcionWhereUniqueInput[]
    connect?: InscripcionWhereUniqueInput | InscripcionWhereUniqueInput[]
    update?: InscripcionUpdateWithWhereUniqueWithoutGrupoInput | InscripcionUpdateWithWhereUniqueWithoutGrupoInput[]
    updateMany?: InscripcionUpdateManyWithWhereWithoutGrupoInput | InscripcionUpdateManyWithWhereWithoutGrupoInput[]
    deleteMany?: InscripcionScalarWhereInput | InscripcionScalarWhereInput[]
  }

  export type MaterialEducativoUncheckedUpdateManyWithoutGrupoNestedInput = {
    create?: XOR<MaterialEducativoCreateWithoutGrupoInput, MaterialEducativoUncheckedCreateWithoutGrupoInput> | MaterialEducativoCreateWithoutGrupoInput[] | MaterialEducativoUncheckedCreateWithoutGrupoInput[]
    connectOrCreate?: MaterialEducativoCreateOrConnectWithoutGrupoInput | MaterialEducativoCreateOrConnectWithoutGrupoInput[]
    upsert?: MaterialEducativoUpsertWithWhereUniqueWithoutGrupoInput | MaterialEducativoUpsertWithWhereUniqueWithoutGrupoInput[]
    createMany?: MaterialEducativoCreateManyGrupoInputEnvelope
    set?: MaterialEducativoWhereUniqueInput | MaterialEducativoWhereUniqueInput[]
    disconnect?: MaterialEducativoWhereUniqueInput | MaterialEducativoWhereUniqueInput[]
    delete?: MaterialEducativoWhereUniqueInput | MaterialEducativoWhereUniqueInput[]
    connect?: MaterialEducativoWhereUniqueInput | MaterialEducativoWhereUniqueInput[]
    update?: MaterialEducativoUpdateWithWhereUniqueWithoutGrupoInput | MaterialEducativoUpdateWithWhereUniqueWithoutGrupoInput[]
    updateMany?: MaterialEducativoUpdateManyWithWhereWithoutGrupoInput | MaterialEducativoUpdateManyWithWhereWithoutGrupoInput[]
    deleteMany?: MaterialEducativoScalarWhereInput | MaterialEducativoScalarWhereInput[]
  }

  export type InscripcionCreateNestedOneWithoutTramiteInput = {
    create?: XOR<InscripcionCreateWithoutTramiteInput, InscripcionUncheckedCreateWithoutTramiteInput>
    connectOrCreate?: InscripcionCreateOrConnectWithoutTramiteInput
    connect?: InscripcionWhereUniqueInput
  }

  export type PagoCreateNestedOneWithoutTramiteInput = {
    create?: XOR<PagoCreateWithoutTramiteInput, PagoUncheckedCreateWithoutTramiteInput>
    connectOrCreate?: PagoCreateOrConnectWithoutTramiteInput
    connect?: PagoWhereUniqueInput
  }

  export type EstudianteCreateNestedOneWithoutTramitesInput = {
    create?: XOR<EstudianteCreateWithoutTramitesInput, EstudianteUncheckedCreateWithoutTramitesInput>
    connectOrCreate?: EstudianteCreateOrConnectWithoutTramitesInput
    connect?: EstudianteWhereUniqueInput
  }

  export type InscripcionUncheckedCreateNestedOneWithoutTramiteInput = {
    create?: XOR<InscripcionCreateWithoutTramiteInput, InscripcionUncheckedCreateWithoutTramiteInput>
    connectOrCreate?: InscripcionCreateOrConnectWithoutTramiteInput
    connect?: InscripcionWhereUniqueInput
  }

  export type PagoUncheckedCreateNestedOneWithoutTramiteInput = {
    create?: XOR<PagoCreateWithoutTramiteInput, PagoUncheckedCreateWithoutTramiteInput>
    connectOrCreate?: PagoCreateOrConnectWithoutTramiteInput
    connect?: PagoWhereUniqueInput
  }

  export type EnumTipoTramiteFieldUpdateOperationsInput = {
    set?: $Enums.TipoTramite
  }

  export type EnumEstadoTramiteFieldUpdateOperationsInput = {
    set?: $Enums.EstadoTramite
  }

  export type InscripcionUpdateOneWithoutTramiteNestedInput = {
    create?: XOR<InscripcionCreateWithoutTramiteInput, InscripcionUncheckedCreateWithoutTramiteInput>
    connectOrCreate?: InscripcionCreateOrConnectWithoutTramiteInput
    upsert?: InscripcionUpsertWithoutTramiteInput
    disconnect?: InscripcionWhereInput | boolean
    delete?: InscripcionWhereInput | boolean
    connect?: InscripcionWhereUniqueInput
    update?: XOR<XOR<InscripcionUpdateToOneWithWhereWithoutTramiteInput, InscripcionUpdateWithoutTramiteInput>, InscripcionUncheckedUpdateWithoutTramiteInput>
  }

  export type PagoUpdateOneWithoutTramiteNestedInput = {
    create?: XOR<PagoCreateWithoutTramiteInput, PagoUncheckedCreateWithoutTramiteInput>
    connectOrCreate?: PagoCreateOrConnectWithoutTramiteInput
    upsert?: PagoUpsertWithoutTramiteInput
    disconnect?: PagoWhereInput | boolean
    delete?: PagoWhereInput | boolean
    connect?: PagoWhereUniqueInput
    update?: XOR<XOR<PagoUpdateToOneWithWhereWithoutTramiteInput, PagoUpdateWithoutTramiteInput>, PagoUncheckedUpdateWithoutTramiteInput>
  }

  export type EstudianteUpdateOneRequiredWithoutTramitesNestedInput = {
    create?: XOR<EstudianteCreateWithoutTramitesInput, EstudianteUncheckedCreateWithoutTramitesInput>
    connectOrCreate?: EstudianteCreateOrConnectWithoutTramitesInput
    upsert?: EstudianteUpsertWithoutTramitesInput
    connect?: EstudianteWhereUniqueInput
    update?: XOR<XOR<EstudianteUpdateToOneWithWhereWithoutTramitesInput, EstudianteUpdateWithoutTramitesInput>, EstudianteUncheckedUpdateWithoutTramitesInput>
  }

  export type InscripcionUncheckedUpdateOneWithoutTramiteNestedInput = {
    create?: XOR<InscripcionCreateWithoutTramiteInput, InscripcionUncheckedCreateWithoutTramiteInput>
    connectOrCreate?: InscripcionCreateOrConnectWithoutTramiteInput
    upsert?: InscripcionUpsertWithoutTramiteInput
    disconnect?: InscripcionWhereInput | boolean
    delete?: InscripcionWhereInput | boolean
    connect?: InscripcionWhereUniqueInput
    update?: XOR<XOR<InscripcionUpdateToOneWithWhereWithoutTramiteInput, InscripcionUpdateWithoutTramiteInput>, InscripcionUncheckedUpdateWithoutTramiteInput>
  }

  export type PagoUncheckedUpdateOneWithoutTramiteNestedInput = {
    create?: XOR<PagoCreateWithoutTramiteInput, PagoUncheckedCreateWithoutTramiteInput>
    connectOrCreate?: PagoCreateOrConnectWithoutTramiteInput
    upsert?: PagoUpsertWithoutTramiteInput
    disconnect?: PagoWhereInput | boolean
    delete?: PagoWhereInput | boolean
    connect?: PagoWhereUniqueInput
    update?: XOR<XOR<PagoUpdateToOneWithWhereWithoutTramiteInput, PagoUpdateWithoutTramiteInput>, PagoUncheckedUpdateWithoutTramiteInput>
  }

  export type TramiteCreateNestedOneWithoutInscripcionInput = {
    create?: XOR<TramiteCreateWithoutInscripcionInput, TramiteUncheckedCreateWithoutInscripcionInput>
    connectOrCreate?: TramiteCreateOrConnectWithoutInscripcionInput
    connect?: TramiteWhereUniqueInput
  }

  export type GrupoCreateNestedOneWithoutInscripcionesInput = {
    create?: XOR<GrupoCreateWithoutInscripcionesInput, GrupoUncheckedCreateWithoutInscripcionesInput>
    connectOrCreate?: GrupoCreateOrConnectWithoutInscripcionesInput
    connect?: GrupoWhereUniqueInput
  }

  export type TramiteUpdateOneRequiredWithoutInscripcionNestedInput = {
    create?: XOR<TramiteCreateWithoutInscripcionInput, TramiteUncheckedCreateWithoutInscripcionInput>
    connectOrCreate?: TramiteCreateOrConnectWithoutInscripcionInput
    upsert?: TramiteUpsertWithoutInscripcionInput
    connect?: TramiteWhereUniqueInput
    update?: XOR<XOR<TramiteUpdateToOneWithWhereWithoutInscripcionInput, TramiteUpdateWithoutInscripcionInput>, TramiteUncheckedUpdateWithoutInscripcionInput>
  }

  export type GrupoUpdateOneRequiredWithoutInscripcionesNestedInput = {
    create?: XOR<GrupoCreateWithoutInscripcionesInput, GrupoUncheckedCreateWithoutInscripcionesInput>
    connectOrCreate?: GrupoCreateOrConnectWithoutInscripcionesInput
    upsert?: GrupoUpsertWithoutInscripcionesInput
    connect?: GrupoWhereUniqueInput
    update?: XOR<XOR<GrupoUpdateToOneWithWhereWithoutInscripcionesInput, GrupoUpdateWithoutInscripcionesInput>, GrupoUncheckedUpdateWithoutInscripcionesInput>
  }

  export type ReciboCreateNestedManyWithoutPagoInput = {
    create?: XOR<ReciboCreateWithoutPagoInput, ReciboUncheckedCreateWithoutPagoInput> | ReciboCreateWithoutPagoInput[] | ReciboUncheckedCreateWithoutPagoInput[]
    connectOrCreate?: ReciboCreateOrConnectWithoutPagoInput | ReciboCreateOrConnectWithoutPagoInput[]
    createMany?: ReciboCreateManyPagoInputEnvelope
    connect?: ReciboWhereUniqueInput | ReciboWhereUniqueInput[]
  }

  export type TramiteCreateNestedOneWithoutPagoInput = {
    create?: XOR<TramiteCreateWithoutPagoInput, TramiteUncheckedCreateWithoutPagoInput>
    connectOrCreate?: TramiteCreateOrConnectWithoutPagoInput
    connect?: TramiteWhereUniqueInput
  }

  export type ReciboUncheckedCreateNestedManyWithoutPagoInput = {
    create?: XOR<ReciboCreateWithoutPagoInput, ReciboUncheckedCreateWithoutPagoInput> | ReciboCreateWithoutPagoInput[] | ReciboUncheckedCreateWithoutPagoInput[]
    connectOrCreate?: ReciboCreateOrConnectWithoutPagoInput | ReciboCreateOrConnectWithoutPagoInput[]
    createMany?: ReciboCreateManyPagoInputEnvelope
    connect?: ReciboWhereUniqueInput | ReciboWhereUniqueInput[]
  }

  export type FloatFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type ReciboUpdateManyWithoutPagoNestedInput = {
    create?: XOR<ReciboCreateWithoutPagoInput, ReciboUncheckedCreateWithoutPagoInput> | ReciboCreateWithoutPagoInput[] | ReciboUncheckedCreateWithoutPagoInput[]
    connectOrCreate?: ReciboCreateOrConnectWithoutPagoInput | ReciboCreateOrConnectWithoutPagoInput[]
    upsert?: ReciboUpsertWithWhereUniqueWithoutPagoInput | ReciboUpsertWithWhereUniqueWithoutPagoInput[]
    createMany?: ReciboCreateManyPagoInputEnvelope
    set?: ReciboWhereUniqueInput | ReciboWhereUniqueInput[]
    disconnect?: ReciboWhereUniqueInput | ReciboWhereUniqueInput[]
    delete?: ReciboWhereUniqueInput | ReciboWhereUniqueInput[]
    connect?: ReciboWhereUniqueInput | ReciboWhereUniqueInput[]
    update?: ReciboUpdateWithWhereUniqueWithoutPagoInput | ReciboUpdateWithWhereUniqueWithoutPagoInput[]
    updateMany?: ReciboUpdateManyWithWhereWithoutPagoInput | ReciboUpdateManyWithWhereWithoutPagoInput[]
    deleteMany?: ReciboScalarWhereInput | ReciboScalarWhereInput[]
  }

  export type TramiteUpdateOneRequiredWithoutPagoNestedInput = {
    create?: XOR<TramiteCreateWithoutPagoInput, TramiteUncheckedCreateWithoutPagoInput>
    connectOrCreate?: TramiteCreateOrConnectWithoutPagoInput
    upsert?: TramiteUpsertWithoutPagoInput
    connect?: TramiteWhereUniqueInput
    update?: XOR<XOR<TramiteUpdateToOneWithWhereWithoutPagoInput, TramiteUpdateWithoutPagoInput>, TramiteUncheckedUpdateWithoutPagoInput>
  }

  export type ReciboUncheckedUpdateManyWithoutPagoNestedInput = {
    create?: XOR<ReciboCreateWithoutPagoInput, ReciboUncheckedCreateWithoutPagoInput> | ReciboCreateWithoutPagoInput[] | ReciboUncheckedCreateWithoutPagoInput[]
    connectOrCreate?: ReciboCreateOrConnectWithoutPagoInput | ReciboCreateOrConnectWithoutPagoInput[]
    upsert?: ReciboUpsertWithWhereUniqueWithoutPagoInput | ReciboUpsertWithWhereUniqueWithoutPagoInput[]
    createMany?: ReciboCreateManyPagoInputEnvelope
    set?: ReciboWhereUniqueInput | ReciboWhereUniqueInput[]
    disconnect?: ReciboWhereUniqueInput | ReciboWhereUniqueInput[]
    delete?: ReciboWhereUniqueInput | ReciboWhereUniqueInput[]
    connect?: ReciboWhereUniqueInput | ReciboWhereUniqueInput[]
    update?: ReciboUpdateWithWhereUniqueWithoutPagoInput | ReciboUpdateWithWhereUniqueWithoutPagoInput[]
    updateMany?: ReciboUpdateManyWithWhereWithoutPagoInput | ReciboUpdateManyWithWhereWithoutPagoInput[]
    deleteMany?: ReciboScalarWhereInput | ReciboScalarWhereInput[]
  }

  export type PagoCreateNestedOneWithoutRecibosInput = {
    create?: XOR<PagoCreateWithoutRecibosInput, PagoUncheckedCreateWithoutRecibosInput>
    connectOrCreate?: PagoCreateOrConnectWithoutRecibosInput
    connect?: PagoWhereUniqueInput
  }

  export type PagoUpdateOneRequiredWithoutRecibosNestedInput = {
    create?: XOR<PagoCreateWithoutRecibosInput, PagoUncheckedCreateWithoutRecibosInput>
    connectOrCreate?: PagoCreateOrConnectWithoutRecibosInput
    upsert?: PagoUpsertWithoutRecibosInput
    connect?: PagoWhereUniqueInput
    update?: XOR<XOR<PagoUpdateToOneWithWhereWithoutRecibosInput, PagoUpdateWithoutRecibosInput>, PagoUncheckedUpdateWithoutRecibosInput>
  }

  export type ProfesorCreateNestedOneWithoutMaterialesInput = {
    create?: XOR<ProfesorCreateWithoutMaterialesInput, ProfesorUncheckedCreateWithoutMaterialesInput>
    connectOrCreate?: ProfesorCreateOrConnectWithoutMaterialesInput
    connect?: ProfesorWhereUniqueInput
  }

  export type GrupoCreateNestedOneWithoutMaterialesInput = {
    create?: XOR<GrupoCreateWithoutMaterialesInput, GrupoUncheckedCreateWithoutMaterialesInput>
    connectOrCreate?: GrupoCreateOrConnectWithoutMaterialesInput
    connect?: GrupoWhereUniqueInput
  }

  export type ArchivoSubidoCreateNestedManyWithoutMaterialInput = {
    create?: XOR<ArchivoSubidoCreateWithoutMaterialInput, ArchivoSubidoUncheckedCreateWithoutMaterialInput> | ArchivoSubidoCreateWithoutMaterialInput[] | ArchivoSubidoUncheckedCreateWithoutMaterialInput[]
    connectOrCreate?: ArchivoSubidoCreateOrConnectWithoutMaterialInput | ArchivoSubidoCreateOrConnectWithoutMaterialInput[]
    createMany?: ArchivoSubidoCreateManyMaterialInputEnvelope
    connect?: ArchivoSubidoWhereUniqueInput | ArchivoSubidoWhereUniqueInput[]
  }

  export type ArchivoSubidoUncheckedCreateNestedManyWithoutMaterialInput = {
    create?: XOR<ArchivoSubidoCreateWithoutMaterialInput, ArchivoSubidoUncheckedCreateWithoutMaterialInput> | ArchivoSubidoCreateWithoutMaterialInput[] | ArchivoSubidoUncheckedCreateWithoutMaterialInput[]
    connectOrCreate?: ArchivoSubidoCreateOrConnectWithoutMaterialInput | ArchivoSubidoCreateOrConnectWithoutMaterialInput[]
    createMany?: ArchivoSubidoCreateManyMaterialInputEnvelope
    connect?: ArchivoSubidoWhereUniqueInput | ArchivoSubidoWhereUniqueInput[]
  }

  export type BoolFieldUpdateOperationsInput = {
    set?: boolean
  }

  export type ProfesorUpdateOneRequiredWithoutMaterialesNestedInput = {
    create?: XOR<ProfesorCreateWithoutMaterialesInput, ProfesorUncheckedCreateWithoutMaterialesInput>
    connectOrCreate?: ProfesorCreateOrConnectWithoutMaterialesInput
    upsert?: ProfesorUpsertWithoutMaterialesInput
    connect?: ProfesorWhereUniqueInput
    update?: XOR<XOR<ProfesorUpdateToOneWithWhereWithoutMaterialesInput, ProfesorUpdateWithoutMaterialesInput>, ProfesorUncheckedUpdateWithoutMaterialesInput>
  }

  export type GrupoUpdateOneRequiredWithoutMaterialesNestedInput = {
    create?: XOR<GrupoCreateWithoutMaterialesInput, GrupoUncheckedCreateWithoutMaterialesInput>
    connectOrCreate?: GrupoCreateOrConnectWithoutMaterialesInput
    upsert?: GrupoUpsertWithoutMaterialesInput
    connect?: GrupoWhereUniqueInput
    update?: XOR<XOR<GrupoUpdateToOneWithWhereWithoutMaterialesInput, GrupoUpdateWithoutMaterialesInput>, GrupoUncheckedUpdateWithoutMaterialesInput>
  }

  export type ArchivoSubidoUpdateManyWithoutMaterialNestedInput = {
    create?: XOR<ArchivoSubidoCreateWithoutMaterialInput, ArchivoSubidoUncheckedCreateWithoutMaterialInput> | ArchivoSubidoCreateWithoutMaterialInput[] | ArchivoSubidoUncheckedCreateWithoutMaterialInput[]
    connectOrCreate?: ArchivoSubidoCreateOrConnectWithoutMaterialInput | ArchivoSubidoCreateOrConnectWithoutMaterialInput[]
    upsert?: ArchivoSubidoUpsertWithWhereUniqueWithoutMaterialInput | ArchivoSubidoUpsertWithWhereUniqueWithoutMaterialInput[]
    createMany?: ArchivoSubidoCreateManyMaterialInputEnvelope
    set?: ArchivoSubidoWhereUniqueInput | ArchivoSubidoWhereUniqueInput[]
    disconnect?: ArchivoSubidoWhereUniqueInput | ArchivoSubidoWhereUniqueInput[]
    delete?: ArchivoSubidoWhereUniqueInput | ArchivoSubidoWhereUniqueInput[]
    connect?: ArchivoSubidoWhereUniqueInput | ArchivoSubidoWhereUniqueInput[]
    update?: ArchivoSubidoUpdateWithWhereUniqueWithoutMaterialInput | ArchivoSubidoUpdateWithWhereUniqueWithoutMaterialInput[]
    updateMany?: ArchivoSubidoUpdateManyWithWhereWithoutMaterialInput | ArchivoSubidoUpdateManyWithWhereWithoutMaterialInput[]
    deleteMany?: ArchivoSubidoScalarWhereInput | ArchivoSubidoScalarWhereInput[]
  }

  export type ArchivoSubidoUncheckedUpdateManyWithoutMaterialNestedInput = {
    create?: XOR<ArchivoSubidoCreateWithoutMaterialInput, ArchivoSubidoUncheckedCreateWithoutMaterialInput> | ArchivoSubidoCreateWithoutMaterialInput[] | ArchivoSubidoUncheckedCreateWithoutMaterialInput[]
    connectOrCreate?: ArchivoSubidoCreateOrConnectWithoutMaterialInput | ArchivoSubidoCreateOrConnectWithoutMaterialInput[]
    upsert?: ArchivoSubidoUpsertWithWhereUniqueWithoutMaterialInput | ArchivoSubidoUpsertWithWhereUniqueWithoutMaterialInput[]
    createMany?: ArchivoSubidoCreateManyMaterialInputEnvelope
    set?: ArchivoSubidoWhereUniqueInput | ArchivoSubidoWhereUniqueInput[]
    disconnect?: ArchivoSubidoWhereUniqueInput | ArchivoSubidoWhereUniqueInput[]
    delete?: ArchivoSubidoWhereUniqueInput | ArchivoSubidoWhereUniqueInput[]
    connect?: ArchivoSubidoWhereUniqueInput | ArchivoSubidoWhereUniqueInput[]
    update?: ArchivoSubidoUpdateWithWhereUniqueWithoutMaterialInput | ArchivoSubidoUpdateWithWhereUniqueWithoutMaterialInput[]
    updateMany?: ArchivoSubidoUpdateManyWithWhereWithoutMaterialInput | ArchivoSubidoUpdateManyWithWhereWithoutMaterialInput[]
    deleteMany?: ArchivoSubidoScalarWhereInput | ArchivoSubidoScalarWhereInput[]
  }

  export type MaterialEducativoCreateNestedOneWithoutArchivoInput = {
    create?: XOR<MaterialEducativoCreateWithoutArchivoInput, MaterialEducativoUncheckedCreateWithoutArchivoInput>
    connectOrCreate?: MaterialEducativoCreateOrConnectWithoutArchivoInput
    connect?: MaterialEducativoWhereUniqueInput
  }

  export type MaterialEducativoUpdateOneRequiredWithoutArchivoNestedInput = {
    create?: XOR<MaterialEducativoCreateWithoutArchivoInput, MaterialEducativoUncheckedCreateWithoutArchivoInput>
    connectOrCreate?: MaterialEducativoCreateOrConnectWithoutArchivoInput
    upsert?: MaterialEducativoUpsertWithoutArchivoInput
    connect?: MaterialEducativoWhereUniqueInput
    update?: XOR<XOR<MaterialEducativoUpdateToOneWithWhereWithoutArchivoInput, MaterialEducativoUpdateWithoutArchivoInput>, MaterialEducativoUncheckedUpdateWithoutArchivoInput>
  }

  export type ProfesorCreateNestedOneWithoutMateriaInput = {
    create?: XOR<ProfesorCreateWithoutMateriaInput, ProfesorUncheckedCreateWithoutMateriaInput>
    connectOrCreate?: ProfesorCreateOrConnectWithoutMateriaInput
    connect?: ProfesorWhereUniqueInput
  }

  export type CalificacionCreateNestedManyWithoutMateriaInput = {
    create?: XOR<CalificacionCreateWithoutMateriaInput, CalificacionUncheckedCreateWithoutMateriaInput> | CalificacionCreateWithoutMateriaInput[] | CalificacionUncheckedCreateWithoutMateriaInput[]
    connectOrCreate?: CalificacionCreateOrConnectWithoutMateriaInput | CalificacionCreateOrConnectWithoutMateriaInput[]
    createMany?: CalificacionCreateManyMateriaInputEnvelope
    connect?: CalificacionWhereUniqueInput | CalificacionWhereUniqueInput[]
  }

  export type AsistenciaCreateNestedManyWithoutMateriaInput = {
    create?: XOR<AsistenciaCreateWithoutMateriaInput, AsistenciaUncheckedCreateWithoutMateriaInput> | AsistenciaCreateWithoutMateriaInput[] | AsistenciaUncheckedCreateWithoutMateriaInput[]
    connectOrCreate?: AsistenciaCreateOrConnectWithoutMateriaInput | AsistenciaCreateOrConnectWithoutMateriaInput[]
    createMany?: AsistenciaCreateManyMateriaInputEnvelope
    connect?: AsistenciaWhereUniqueInput | AsistenciaWhereUniqueInput[]
  }

  export type CalificacionUncheckedCreateNestedManyWithoutMateriaInput = {
    create?: XOR<CalificacionCreateWithoutMateriaInput, CalificacionUncheckedCreateWithoutMateriaInput> | CalificacionCreateWithoutMateriaInput[] | CalificacionUncheckedCreateWithoutMateriaInput[]
    connectOrCreate?: CalificacionCreateOrConnectWithoutMateriaInput | CalificacionCreateOrConnectWithoutMateriaInput[]
    createMany?: CalificacionCreateManyMateriaInputEnvelope
    connect?: CalificacionWhereUniqueInput | CalificacionWhereUniqueInput[]
  }

  export type AsistenciaUncheckedCreateNestedManyWithoutMateriaInput = {
    create?: XOR<AsistenciaCreateWithoutMateriaInput, AsistenciaUncheckedCreateWithoutMateriaInput> | AsistenciaCreateWithoutMateriaInput[] | AsistenciaUncheckedCreateWithoutMateriaInput[]
    connectOrCreate?: AsistenciaCreateOrConnectWithoutMateriaInput | AsistenciaCreateOrConnectWithoutMateriaInput[]
    createMany?: AsistenciaCreateManyMateriaInputEnvelope
    connect?: AsistenciaWhereUniqueInput | AsistenciaWhereUniqueInput[]
  }

  export type ProfesorUpdateOneRequiredWithoutMateriaNestedInput = {
    create?: XOR<ProfesorCreateWithoutMateriaInput, ProfesorUncheckedCreateWithoutMateriaInput>
    connectOrCreate?: ProfesorCreateOrConnectWithoutMateriaInput
    upsert?: ProfesorUpsertWithoutMateriaInput
    connect?: ProfesorWhereUniqueInput
    update?: XOR<XOR<ProfesorUpdateToOneWithWhereWithoutMateriaInput, ProfesorUpdateWithoutMateriaInput>, ProfesorUncheckedUpdateWithoutMateriaInput>
  }

  export type CalificacionUpdateManyWithoutMateriaNestedInput = {
    create?: XOR<CalificacionCreateWithoutMateriaInput, CalificacionUncheckedCreateWithoutMateriaInput> | CalificacionCreateWithoutMateriaInput[] | CalificacionUncheckedCreateWithoutMateriaInput[]
    connectOrCreate?: CalificacionCreateOrConnectWithoutMateriaInput | CalificacionCreateOrConnectWithoutMateriaInput[]
    upsert?: CalificacionUpsertWithWhereUniqueWithoutMateriaInput | CalificacionUpsertWithWhereUniqueWithoutMateriaInput[]
    createMany?: CalificacionCreateManyMateriaInputEnvelope
    set?: CalificacionWhereUniqueInput | CalificacionWhereUniqueInput[]
    disconnect?: CalificacionWhereUniqueInput | CalificacionWhereUniqueInput[]
    delete?: CalificacionWhereUniqueInput | CalificacionWhereUniqueInput[]
    connect?: CalificacionWhereUniqueInput | CalificacionWhereUniqueInput[]
    update?: CalificacionUpdateWithWhereUniqueWithoutMateriaInput | CalificacionUpdateWithWhereUniqueWithoutMateriaInput[]
    updateMany?: CalificacionUpdateManyWithWhereWithoutMateriaInput | CalificacionUpdateManyWithWhereWithoutMateriaInput[]
    deleteMany?: CalificacionScalarWhereInput | CalificacionScalarWhereInput[]
  }

  export type AsistenciaUpdateManyWithoutMateriaNestedInput = {
    create?: XOR<AsistenciaCreateWithoutMateriaInput, AsistenciaUncheckedCreateWithoutMateriaInput> | AsistenciaCreateWithoutMateriaInput[] | AsistenciaUncheckedCreateWithoutMateriaInput[]
    connectOrCreate?: AsistenciaCreateOrConnectWithoutMateriaInput | AsistenciaCreateOrConnectWithoutMateriaInput[]
    upsert?: AsistenciaUpsertWithWhereUniqueWithoutMateriaInput | AsistenciaUpsertWithWhereUniqueWithoutMateriaInput[]
    createMany?: AsistenciaCreateManyMateriaInputEnvelope
    set?: AsistenciaWhereUniqueInput | AsistenciaWhereUniqueInput[]
    disconnect?: AsistenciaWhereUniqueInput | AsistenciaWhereUniqueInput[]
    delete?: AsistenciaWhereUniqueInput | AsistenciaWhereUniqueInput[]
    connect?: AsistenciaWhereUniqueInput | AsistenciaWhereUniqueInput[]
    update?: AsistenciaUpdateWithWhereUniqueWithoutMateriaInput | AsistenciaUpdateWithWhereUniqueWithoutMateriaInput[]
    updateMany?: AsistenciaUpdateManyWithWhereWithoutMateriaInput | AsistenciaUpdateManyWithWhereWithoutMateriaInput[]
    deleteMany?: AsistenciaScalarWhereInput | AsistenciaScalarWhereInput[]
  }

  export type CalificacionUncheckedUpdateManyWithoutMateriaNestedInput = {
    create?: XOR<CalificacionCreateWithoutMateriaInput, CalificacionUncheckedCreateWithoutMateriaInput> | CalificacionCreateWithoutMateriaInput[] | CalificacionUncheckedCreateWithoutMateriaInput[]
    connectOrCreate?: CalificacionCreateOrConnectWithoutMateriaInput | CalificacionCreateOrConnectWithoutMateriaInput[]
    upsert?: CalificacionUpsertWithWhereUniqueWithoutMateriaInput | CalificacionUpsertWithWhereUniqueWithoutMateriaInput[]
    createMany?: CalificacionCreateManyMateriaInputEnvelope
    set?: CalificacionWhereUniqueInput | CalificacionWhereUniqueInput[]
    disconnect?: CalificacionWhereUniqueInput | CalificacionWhereUniqueInput[]
    delete?: CalificacionWhereUniqueInput | CalificacionWhereUniqueInput[]
    connect?: CalificacionWhereUniqueInput | CalificacionWhereUniqueInput[]
    update?: CalificacionUpdateWithWhereUniqueWithoutMateriaInput | CalificacionUpdateWithWhereUniqueWithoutMateriaInput[]
    updateMany?: CalificacionUpdateManyWithWhereWithoutMateriaInput | CalificacionUpdateManyWithWhereWithoutMateriaInput[]
    deleteMany?: CalificacionScalarWhereInput | CalificacionScalarWhereInput[]
  }

  export type AsistenciaUncheckedUpdateManyWithoutMateriaNestedInput = {
    create?: XOR<AsistenciaCreateWithoutMateriaInput, AsistenciaUncheckedCreateWithoutMateriaInput> | AsistenciaCreateWithoutMateriaInput[] | AsistenciaUncheckedCreateWithoutMateriaInput[]
    connectOrCreate?: AsistenciaCreateOrConnectWithoutMateriaInput | AsistenciaCreateOrConnectWithoutMateriaInput[]
    upsert?: AsistenciaUpsertWithWhereUniqueWithoutMateriaInput | AsistenciaUpsertWithWhereUniqueWithoutMateriaInput[]
    createMany?: AsistenciaCreateManyMateriaInputEnvelope
    set?: AsistenciaWhereUniqueInput | AsistenciaWhereUniqueInput[]
    disconnect?: AsistenciaWhereUniqueInput | AsistenciaWhereUniqueInput[]
    delete?: AsistenciaWhereUniqueInput | AsistenciaWhereUniqueInput[]
    connect?: AsistenciaWhereUniqueInput | AsistenciaWhereUniqueInput[]
    update?: AsistenciaUpdateWithWhereUniqueWithoutMateriaInput | AsistenciaUpdateWithWhereUniqueWithoutMateriaInput[]
    updateMany?: AsistenciaUpdateManyWithWhereWithoutMateriaInput | AsistenciaUpdateManyWithWhereWithoutMateriaInput[]
    deleteMany?: AsistenciaScalarWhereInput | AsistenciaScalarWhereInput[]
  }

  export type EstudianteCreateNestedOneWithoutCalificacionInput = {
    create?: XOR<EstudianteCreateWithoutCalificacionInput, EstudianteUncheckedCreateWithoutCalificacionInput>
    connectOrCreate?: EstudianteCreateOrConnectWithoutCalificacionInput
    connect?: EstudianteWhereUniqueInput
  }

  export type MateriaCreateNestedOneWithoutCalificacionInput = {
    create?: XOR<MateriaCreateWithoutCalificacionInput, MateriaUncheckedCreateWithoutCalificacionInput>
    connectOrCreate?: MateriaCreateOrConnectWithoutCalificacionInput
    connect?: MateriaWhereUniqueInput
  }

  export type EstudianteUpdateOneRequiredWithoutCalificacionNestedInput = {
    create?: XOR<EstudianteCreateWithoutCalificacionInput, EstudianteUncheckedCreateWithoutCalificacionInput>
    connectOrCreate?: EstudianteCreateOrConnectWithoutCalificacionInput
    upsert?: EstudianteUpsertWithoutCalificacionInput
    connect?: EstudianteWhereUniqueInput
    update?: XOR<XOR<EstudianteUpdateToOneWithWhereWithoutCalificacionInput, EstudianteUpdateWithoutCalificacionInput>, EstudianteUncheckedUpdateWithoutCalificacionInput>
  }

  export type MateriaUpdateOneRequiredWithoutCalificacionNestedInput = {
    create?: XOR<MateriaCreateWithoutCalificacionInput, MateriaUncheckedCreateWithoutCalificacionInput>
    connectOrCreate?: MateriaCreateOrConnectWithoutCalificacionInput
    upsert?: MateriaUpsertWithoutCalificacionInput
    connect?: MateriaWhereUniqueInput
    update?: XOR<XOR<MateriaUpdateToOneWithWhereWithoutCalificacionInput, MateriaUpdateWithoutCalificacionInput>, MateriaUncheckedUpdateWithoutCalificacionInput>
  }

  export type EstudianteCreateNestedOneWithoutAsistenciaInput = {
    create?: XOR<EstudianteCreateWithoutAsistenciaInput, EstudianteUncheckedCreateWithoutAsistenciaInput>
    connectOrCreate?: EstudianteCreateOrConnectWithoutAsistenciaInput
    connect?: EstudianteWhereUniqueInput
  }

  export type MateriaCreateNestedOneWithoutAsistenciaInput = {
    create?: XOR<MateriaCreateWithoutAsistenciaInput, MateriaUncheckedCreateWithoutAsistenciaInput>
    connectOrCreate?: MateriaCreateOrConnectWithoutAsistenciaInput
    connect?: MateriaWhereUniqueInput
  }

  export type EstudianteUpdateOneRequiredWithoutAsistenciaNestedInput = {
    create?: XOR<EstudianteCreateWithoutAsistenciaInput, EstudianteUncheckedCreateWithoutAsistenciaInput>
    connectOrCreate?: EstudianteCreateOrConnectWithoutAsistenciaInput
    upsert?: EstudianteUpsertWithoutAsistenciaInput
    connect?: EstudianteWhereUniqueInput
    update?: XOR<XOR<EstudianteUpdateToOneWithWhereWithoutAsistenciaInput, EstudianteUpdateWithoutAsistenciaInput>, EstudianteUncheckedUpdateWithoutAsistenciaInput>
  }

  export type MateriaUpdateOneRequiredWithoutAsistenciaNestedInput = {
    create?: XOR<MateriaCreateWithoutAsistenciaInput, MateriaUncheckedCreateWithoutAsistenciaInput>
    connectOrCreate?: MateriaCreateOrConnectWithoutAsistenciaInput
    upsert?: MateriaUpsertWithoutAsistenciaInput
    connect?: MateriaWhereUniqueInput
    update?: XOR<XOR<MateriaUpdateToOneWithWhereWithoutAsistenciaInput, MateriaUpdateWithoutAsistenciaInput>, MateriaUncheckedUpdateWithoutAsistenciaInput>
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedEnumRolUsuarioFilter<$PrismaModel = never> = {
    equals?: $Enums.RolUsuario | EnumRolUsuarioFieldRefInput<$PrismaModel>
    in?: $Enums.RolUsuario[]
    notIn?: $Enums.RolUsuario[]
    not?: NestedEnumRolUsuarioFilter<$PrismaModel> | $Enums.RolUsuario
  }

  export type NestedDateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type NestedIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type NestedFloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedEnumRolUsuarioWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.RolUsuario | EnumRolUsuarioFieldRefInput<$PrismaModel>
    in?: $Enums.RolUsuario[]
    notIn?: $Enums.RolUsuario[]
    not?: NestedEnumRolUsuarioWithAggregatesFilter<$PrismaModel> | $Enums.RolUsuario
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumRolUsuarioFilter<$PrismaModel>
    _max?: NestedEnumRolUsuarioFilter<$PrismaModel>
  }

  export type NestedDateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type NestedIntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type NestedEnumEstadoEstudianteFilter<$PrismaModel = never> = {
    equals?: $Enums.EstadoEstudiante | EnumEstadoEstudianteFieldRefInput<$PrismaModel>
    in?: $Enums.EstadoEstudiante[]
    notIn?: $Enums.EstadoEstudiante[]
    not?: NestedEnumEstadoEstudianteFilter<$PrismaModel> | $Enums.EstadoEstudiante
  }

  export type NestedIntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type NestedFloatNullableFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableFilter<$PrismaModel> | number | null
  }

  export type NestedEnumEstadoEstudianteWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.EstadoEstudiante | EnumEstadoEstudianteFieldRefInput<$PrismaModel>
    in?: $Enums.EstadoEstudiante[]
    notIn?: $Enums.EstadoEstudiante[]
    not?: NestedEnumEstadoEstudianteWithAggregatesFilter<$PrismaModel> | $Enums.EstadoEstudiante
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumEstadoEstudianteFilter<$PrismaModel>
    _max?: NestedEnumEstadoEstudianteFilter<$PrismaModel>
  }

  export type NestedEnumTipoTramiteFilter<$PrismaModel = never> = {
    equals?: $Enums.TipoTramite | EnumTipoTramiteFieldRefInput<$PrismaModel>
    in?: $Enums.TipoTramite[]
    notIn?: $Enums.TipoTramite[]
    not?: NestedEnumTipoTramiteFilter<$PrismaModel> | $Enums.TipoTramite
  }

  export type NestedEnumEstadoTramiteFilter<$PrismaModel = never> = {
    equals?: $Enums.EstadoTramite | EnumEstadoTramiteFieldRefInput<$PrismaModel>
    in?: $Enums.EstadoTramite[]
    notIn?: $Enums.EstadoTramite[]
    not?: NestedEnumEstadoTramiteFilter<$PrismaModel> | $Enums.EstadoTramite
  }

  export type NestedEnumTipoTramiteWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.TipoTramite | EnumTipoTramiteFieldRefInput<$PrismaModel>
    in?: $Enums.TipoTramite[]
    notIn?: $Enums.TipoTramite[]
    not?: NestedEnumTipoTramiteWithAggregatesFilter<$PrismaModel> | $Enums.TipoTramite
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumTipoTramiteFilter<$PrismaModel>
    _max?: NestedEnumTipoTramiteFilter<$PrismaModel>
  }

  export type NestedEnumEstadoTramiteWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.EstadoTramite | EnumEstadoTramiteFieldRefInput<$PrismaModel>
    in?: $Enums.EstadoTramite[]
    notIn?: $Enums.EstadoTramite[]
    not?: NestedEnumEstadoTramiteWithAggregatesFilter<$PrismaModel> | $Enums.EstadoTramite
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumEstadoTramiteFilter<$PrismaModel>
    _max?: NestedEnumEstadoTramiteFilter<$PrismaModel>
  }

  export type NestedFloatWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedFloatFilter<$PrismaModel>
    _min?: NestedFloatFilter<$PrismaModel>
    _max?: NestedFloatFilter<$PrismaModel>
  }

  export type NestedBoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type NestedBoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type EstudianteCreateWithoutUsuarioInput = {
    estado?: $Enums.EstadoEstudiante
    tramites?: TramiteCreateNestedManyWithoutEstudianteInput
    grupo?: GrupoCreateNestedOneWithoutEstudiantesInput
    PadreFamilia?: PadreFamiliaCreateNestedOneWithoutEstudiantesInput
    Calificacion?: CalificacionCreateNestedManyWithoutEstudianteInput
    Asistencia?: AsistenciaCreateNestedManyWithoutEstudianteInput
  }

  export type EstudianteUncheckedCreateWithoutUsuarioInput = {
    grupoId?: number | null
    padreFamiliaId?: number | null
    estado?: $Enums.EstadoEstudiante
    tramites?: TramiteUncheckedCreateNestedManyWithoutEstudianteInput
    Calificacion?: CalificacionUncheckedCreateNestedManyWithoutEstudianteInput
    Asistencia?: AsistenciaUncheckedCreateNestedManyWithoutEstudianteInput
  }

  export type EstudianteCreateOrConnectWithoutUsuarioInput = {
    where: EstudianteWhereUniqueInput
    create: XOR<EstudianteCreateWithoutUsuarioInput, EstudianteUncheckedCreateWithoutUsuarioInput>
  }

  export type ProfesorCreateWithoutUsuarioInput = {
    materiales?: MaterialEducativoCreateNestedManyWithoutProfesorInput
    Materia?: MateriaCreateNestedManyWithoutProfesorInput
  }

  export type ProfesorUncheckedCreateWithoutUsuarioInput = {
    materiales?: MaterialEducativoUncheckedCreateNestedManyWithoutProfesorInput
    Materia?: MateriaUncheckedCreateNestedManyWithoutProfesorInput
  }

  export type ProfesorCreateOrConnectWithoutUsuarioInput = {
    where: ProfesorWhereUniqueInput
    create: XOR<ProfesorCreateWithoutUsuarioInput, ProfesorUncheckedCreateWithoutUsuarioInput>
  }

  export type PadreFamiliaCreateWithoutUsuarioInput = {
    domicilio: string
    estudiantes?: EstudianteCreateNestedManyWithoutPadreFamiliaInput
  }

  export type PadreFamiliaUncheckedCreateWithoutUsuarioInput = {
    domicilio: string
    estudiantes?: EstudianteUncheckedCreateNestedManyWithoutPadreFamiliaInput
  }

  export type PadreFamiliaCreateOrConnectWithoutUsuarioInput = {
    where: PadreFamiliaWhereUniqueInput
    create: XOR<PadreFamiliaCreateWithoutUsuarioInput, PadreFamiliaUncheckedCreateWithoutUsuarioInput>
  }

  export type PadreFamiliaCreateManyUsuarioInputEnvelope = {
    data: PadreFamiliaCreateManyUsuarioInput | PadreFamiliaCreateManyUsuarioInput[]
    skipDuplicates?: boolean
  }

  export type EstudianteUpsertWithoutUsuarioInput = {
    update: XOR<EstudianteUpdateWithoutUsuarioInput, EstudianteUncheckedUpdateWithoutUsuarioInput>
    create: XOR<EstudianteCreateWithoutUsuarioInput, EstudianteUncheckedCreateWithoutUsuarioInput>
    where?: EstudianteWhereInput
  }

  export type EstudianteUpdateToOneWithWhereWithoutUsuarioInput = {
    where?: EstudianteWhereInput
    data: XOR<EstudianteUpdateWithoutUsuarioInput, EstudianteUncheckedUpdateWithoutUsuarioInput>
  }

  export type EstudianteUpdateWithoutUsuarioInput = {
    estado?: EnumEstadoEstudianteFieldUpdateOperationsInput | $Enums.EstadoEstudiante
    tramites?: TramiteUpdateManyWithoutEstudianteNestedInput
    grupo?: GrupoUpdateOneWithoutEstudiantesNestedInput
    PadreFamilia?: PadreFamiliaUpdateOneWithoutEstudiantesNestedInput
    Calificacion?: CalificacionUpdateManyWithoutEstudianteNestedInput
    Asistencia?: AsistenciaUpdateManyWithoutEstudianteNestedInput
  }

  export type EstudianteUncheckedUpdateWithoutUsuarioInput = {
    grupoId?: NullableIntFieldUpdateOperationsInput | number | null
    padreFamiliaId?: NullableIntFieldUpdateOperationsInput | number | null
    estado?: EnumEstadoEstudianteFieldUpdateOperationsInput | $Enums.EstadoEstudiante
    tramites?: TramiteUncheckedUpdateManyWithoutEstudianteNestedInput
    Calificacion?: CalificacionUncheckedUpdateManyWithoutEstudianteNestedInput
    Asistencia?: AsistenciaUncheckedUpdateManyWithoutEstudianteNestedInput
  }

  export type ProfesorUpsertWithoutUsuarioInput = {
    update: XOR<ProfesorUpdateWithoutUsuarioInput, ProfesorUncheckedUpdateWithoutUsuarioInput>
    create: XOR<ProfesorCreateWithoutUsuarioInput, ProfesorUncheckedCreateWithoutUsuarioInput>
    where?: ProfesorWhereInput
  }

  export type ProfesorUpdateToOneWithWhereWithoutUsuarioInput = {
    where?: ProfesorWhereInput
    data: XOR<ProfesorUpdateWithoutUsuarioInput, ProfesorUncheckedUpdateWithoutUsuarioInput>
  }

  export type ProfesorUpdateWithoutUsuarioInput = {
    materiales?: MaterialEducativoUpdateManyWithoutProfesorNestedInput
    Materia?: MateriaUpdateManyWithoutProfesorNestedInput
  }

  export type ProfesorUncheckedUpdateWithoutUsuarioInput = {
    materiales?: MaterialEducativoUncheckedUpdateManyWithoutProfesorNestedInput
    Materia?: MateriaUncheckedUpdateManyWithoutProfesorNestedInput
  }

  export type PadreFamiliaUpsertWithWhereUniqueWithoutUsuarioInput = {
    where: PadreFamiliaWhereUniqueInput
    update: XOR<PadreFamiliaUpdateWithoutUsuarioInput, PadreFamiliaUncheckedUpdateWithoutUsuarioInput>
    create: XOR<PadreFamiliaCreateWithoutUsuarioInput, PadreFamiliaUncheckedCreateWithoutUsuarioInput>
  }

  export type PadreFamiliaUpdateWithWhereUniqueWithoutUsuarioInput = {
    where: PadreFamiliaWhereUniqueInput
    data: XOR<PadreFamiliaUpdateWithoutUsuarioInput, PadreFamiliaUncheckedUpdateWithoutUsuarioInput>
  }

  export type PadreFamiliaUpdateManyWithWhereWithoutUsuarioInput = {
    where: PadreFamiliaScalarWhereInput
    data: XOR<PadreFamiliaUpdateManyMutationInput, PadreFamiliaUncheckedUpdateManyWithoutUsuarioInput>
  }

  export type PadreFamiliaScalarWhereInput = {
    AND?: PadreFamiliaScalarWhereInput | PadreFamiliaScalarWhereInput[]
    OR?: PadreFamiliaScalarWhereInput[]
    NOT?: PadreFamiliaScalarWhereInput | PadreFamiliaScalarWhereInput[]
    usuarioId?: IntFilter<"PadreFamilia"> | number
    domicilio?: StringFilter<"PadreFamilia"> | string
  }

  export type TramiteCreateWithoutEstudianteInput = {
    tipo: $Enums.TipoTramite
    estado: $Enums.EstadoTramite
    fecha?: Date | string
    inscripcion?: InscripcionCreateNestedOneWithoutTramiteInput
    Pago?: PagoCreateNestedOneWithoutTramiteInput
  }

  export type TramiteUncheckedCreateWithoutEstudianteInput = {
    id?: number
    tipo: $Enums.TipoTramite
    estado: $Enums.EstadoTramite
    fecha?: Date | string
    inscripcion?: InscripcionUncheckedCreateNestedOneWithoutTramiteInput
    Pago?: PagoUncheckedCreateNestedOneWithoutTramiteInput
  }

  export type TramiteCreateOrConnectWithoutEstudianteInput = {
    where: TramiteWhereUniqueInput
    create: XOR<TramiteCreateWithoutEstudianteInput, TramiteUncheckedCreateWithoutEstudianteInput>
  }

  export type TramiteCreateManyEstudianteInputEnvelope = {
    data: TramiteCreateManyEstudianteInput | TramiteCreateManyEstudianteInput[]
    skipDuplicates?: boolean
  }

  export type GrupoCreateWithoutEstudiantesInput = {
    nombre: string
    grado: number
    inscripciones?: InscripcionCreateNestedManyWithoutGrupoInput
    materiales?: MaterialEducativoCreateNestedManyWithoutGrupoInput
  }

  export type GrupoUncheckedCreateWithoutEstudiantesInput = {
    id?: number
    nombre: string
    grado: number
    inscripciones?: InscripcionUncheckedCreateNestedManyWithoutGrupoInput
    materiales?: MaterialEducativoUncheckedCreateNestedManyWithoutGrupoInput
  }

  export type GrupoCreateOrConnectWithoutEstudiantesInput = {
    where: GrupoWhereUniqueInput
    create: XOR<GrupoCreateWithoutEstudiantesInput, GrupoUncheckedCreateWithoutEstudiantesInput>
  }

  export type UsuarioCreateWithoutEstudianteInput = {
    nombre: string
    correo: string
    telefono: string
    contrasena: string
    puesto: $Enums.RolUsuario
    fechaCreacion?: Date | string
    Profesor?: ProfesorCreateNestedOneWithoutUsuarioInput
    PadreFamilia?: PadreFamiliaCreateNestedManyWithoutUsuarioInput
  }

  export type UsuarioUncheckedCreateWithoutEstudianteInput = {
    id?: number
    nombre: string
    correo: string
    telefono: string
    contrasena: string
    puesto: $Enums.RolUsuario
    fechaCreacion?: Date | string
    Profesor?: ProfesorUncheckedCreateNestedOneWithoutUsuarioInput
    PadreFamilia?: PadreFamiliaUncheckedCreateNestedManyWithoutUsuarioInput
  }

  export type UsuarioCreateOrConnectWithoutEstudianteInput = {
    where: UsuarioWhereUniqueInput
    create: XOR<UsuarioCreateWithoutEstudianteInput, UsuarioUncheckedCreateWithoutEstudianteInput>
  }

  export type PadreFamiliaCreateWithoutEstudiantesInput = {
    domicilio: string
    usuario: UsuarioCreateNestedOneWithoutPadreFamiliaInput
  }

  export type PadreFamiliaUncheckedCreateWithoutEstudiantesInput = {
    usuarioId: number
    domicilio: string
  }

  export type PadreFamiliaCreateOrConnectWithoutEstudiantesInput = {
    where: PadreFamiliaWhereUniqueInput
    create: XOR<PadreFamiliaCreateWithoutEstudiantesInput, PadreFamiliaUncheckedCreateWithoutEstudiantesInput>
  }

  export type CalificacionCreateWithoutEstudianteInput = {
    parcial1?: number
    parcial2?: number
    ordinario?: number
    final?: number
    fecha?: Date | string
    materia: MateriaCreateNestedOneWithoutCalificacionInput
  }

  export type CalificacionUncheckedCreateWithoutEstudianteInput = {
    id?: number
    materiaId: number
    parcial1?: number
    parcial2?: number
    ordinario?: number
    final?: number
    fecha?: Date | string
  }

  export type CalificacionCreateOrConnectWithoutEstudianteInput = {
    where: CalificacionWhereUniqueInput
    create: XOR<CalificacionCreateWithoutEstudianteInput, CalificacionUncheckedCreateWithoutEstudianteInput>
  }

  export type CalificacionCreateManyEstudianteInputEnvelope = {
    data: CalificacionCreateManyEstudianteInput | CalificacionCreateManyEstudianteInput[]
    skipDuplicates?: boolean
  }

  export type AsistenciaCreateWithoutEstudianteInput = {
    parcial1?: number
    parcial2?: number
    final?: number
    fecha?: Date | string
    materia: MateriaCreateNestedOneWithoutAsistenciaInput
  }

  export type AsistenciaUncheckedCreateWithoutEstudianteInput = {
    id?: number
    materiaId: number
    parcial1?: number
    parcial2?: number
    final?: number
    fecha?: Date | string
  }

  export type AsistenciaCreateOrConnectWithoutEstudianteInput = {
    where: AsistenciaWhereUniqueInput
    create: XOR<AsistenciaCreateWithoutEstudianteInput, AsistenciaUncheckedCreateWithoutEstudianteInput>
  }

  export type AsistenciaCreateManyEstudianteInputEnvelope = {
    data: AsistenciaCreateManyEstudianteInput | AsistenciaCreateManyEstudianteInput[]
    skipDuplicates?: boolean
  }

  export type TramiteUpsertWithWhereUniqueWithoutEstudianteInput = {
    where: TramiteWhereUniqueInput
    update: XOR<TramiteUpdateWithoutEstudianteInput, TramiteUncheckedUpdateWithoutEstudianteInput>
    create: XOR<TramiteCreateWithoutEstudianteInput, TramiteUncheckedCreateWithoutEstudianteInput>
  }

  export type TramiteUpdateWithWhereUniqueWithoutEstudianteInput = {
    where: TramiteWhereUniqueInput
    data: XOR<TramiteUpdateWithoutEstudianteInput, TramiteUncheckedUpdateWithoutEstudianteInput>
  }

  export type TramiteUpdateManyWithWhereWithoutEstudianteInput = {
    where: TramiteScalarWhereInput
    data: XOR<TramiteUpdateManyMutationInput, TramiteUncheckedUpdateManyWithoutEstudianteInput>
  }

  export type TramiteScalarWhereInput = {
    AND?: TramiteScalarWhereInput | TramiteScalarWhereInput[]
    OR?: TramiteScalarWhereInput[]
    NOT?: TramiteScalarWhereInput | TramiteScalarWhereInput[]
    id?: IntFilter<"Tramite"> | number
    estudianteId?: IntFilter<"Tramite"> | number
    tipo?: EnumTipoTramiteFilter<"Tramite"> | $Enums.TipoTramite
    estado?: EnumEstadoTramiteFilter<"Tramite"> | $Enums.EstadoTramite
    fecha?: DateTimeFilter<"Tramite"> | Date | string
  }

  export type GrupoUpsertWithoutEstudiantesInput = {
    update: XOR<GrupoUpdateWithoutEstudiantesInput, GrupoUncheckedUpdateWithoutEstudiantesInput>
    create: XOR<GrupoCreateWithoutEstudiantesInput, GrupoUncheckedCreateWithoutEstudiantesInput>
    where?: GrupoWhereInput
  }

  export type GrupoUpdateToOneWithWhereWithoutEstudiantesInput = {
    where?: GrupoWhereInput
    data: XOR<GrupoUpdateWithoutEstudiantesInput, GrupoUncheckedUpdateWithoutEstudiantesInput>
  }

  export type GrupoUpdateWithoutEstudiantesInput = {
    nombre?: StringFieldUpdateOperationsInput | string
    grado?: IntFieldUpdateOperationsInput | number
    inscripciones?: InscripcionUpdateManyWithoutGrupoNestedInput
    materiales?: MaterialEducativoUpdateManyWithoutGrupoNestedInput
  }

  export type GrupoUncheckedUpdateWithoutEstudiantesInput = {
    id?: IntFieldUpdateOperationsInput | number
    nombre?: StringFieldUpdateOperationsInput | string
    grado?: IntFieldUpdateOperationsInput | number
    inscripciones?: InscripcionUncheckedUpdateManyWithoutGrupoNestedInput
    materiales?: MaterialEducativoUncheckedUpdateManyWithoutGrupoNestedInput
  }

  export type UsuarioUpsertWithoutEstudianteInput = {
    update: XOR<UsuarioUpdateWithoutEstudianteInput, UsuarioUncheckedUpdateWithoutEstudianteInput>
    create: XOR<UsuarioCreateWithoutEstudianteInput, UsuarioUncheckedCreateWithoutEstudianteInput>
    where?: UsuarioWhereInput
  }

  export type UsuarioUpdateToOneWithWhereWithoutEstudianteInput = {
    where?: UsuarioWhereInput
    data: XOR<UsuarioUpdateWithoutEstudianteInput, UsuarioUncheckedUpdateWithoutEstudianteInput>
  }

  export type UsuarioUpdateWithoutEstudianteInput = {
    nombre?: StringFieldUpdateOperationsInput | string
    correo?: StringFieldUpdateOperationsInput | string
    telefono?: StringFieldUpdateOperationsInput | string
    contrasena?: StringFieldUpdateOperationsInput | string
    puesto?: EnumRolUsuarioFieldUpdateOperationsInput | $Enums.RolUsuario
    fechaCreacion?: DateTimeFieldUpdateOperationsInput | Date | string
    Profesor?: ProfesorUpdateOneWithoutUsuarioNestedInput
    PadreFamilia?: PadreFamiliaUpdateManyWithoutUsuarioNestedInput
  }

  export type UsuarioUncheckedUpdateWithoutEstudianteInput = {
    id?: IntFieldUpdateOperationsInput | number
    nombre?: StringFieldUpdateOperationsInput | string
    correo?: StringFieldUpdateOperationsInput | string
    telefono?: StringFieldUpdateOperationsInput | string
    contrasena?: StringFieldUpdateOperationsInput | string
    puesto?: EnumRolUsuarioFieldUpdateOperationsInput | $Enums.RolUsuario
    fechaCreacion?: DateTimeFieldUpdateOperationsInput | Date | string
    Profesor?: ProfesorUncheckedUpdateOneWithoutUsuarioNestedInput
    PadreFamilia?: PadreFamiliaUncheckedUpdateManyWithoutUsuarioNestedInput
  }

  export type PadreFamiliaUpsertWithoutEstudiantesInput = {
    update: XOR<PadreFamiliaUpdateWithoutEstudiantesInput, PadreFamiliaUncheckedUpdateWithoutEstudiantesInput>
    create: XOR<PadreFamiliaCreateWithoutEstudiantesInput, PadreFamiliaUncheckedCreateWithoutEstudiantesInput>
    where?: PadreFamiliaWhereInput
  }

  export type PadreFamiliaUpdateToOneWithWhereWithoutEstudiantesInput = {
    where?: PadreFamiliaWhereInput
    data: XOR<PadreFamiliaUpdateWithoutEstudiantesInput, PadreFamiliaUncheckedUpdateWithoutEstudiantesInput>
  }

  export type PadreFamiliaUpdateWithoutEstudiantesInput = {
    domicilio?: StringFieldUpdateOperationsInput | string
    usuario?: UsuarioUpdateOneRequiredWithoutPadreFamiliaNestedInput
  }

  export type PadreFamiliaUncheckedUpdateWithoutEstudiantesInput = {
    usuarioId?: IntFieldUpdateOperationsInput | number
    domicilio?: StringFieldUpdateOperationsInput | string
  }

  export type CalificacionUpsertWithWhereUniqueWithoutEstudianteInput = {
    where: CalificacionWhereUniqueInput
    update: XOR<CalificacionUpdateWithoutEstudianteInput, CalificacionUncheckedUpdateWithoutEstudianteInput>
    create: XOR<CalificacionCreateWithoutEstudianteInput, CalificacionUncheckedCreateWithoutEstudianteInput>
  }

  export type CalificacionUpdateWithWhereUniqueWithoutEstudianteInput = {
    where: CalificacionWhereUniqueInput
    data: XOR<CalificacionUpdateWithoutEstudianteInput, CalificacionUncheckedUpdateWithoutEstudianteInput>
  }

  export type CalificacionUpdateManyWithWhereWithoutEstudianteInput = {
    where: CalificacionScalarWhereInput
    data: XOR<CalificacionUpdateManyMutationInput, CalificacionUncheckedUpdateManyWithoutEstudianteInput>
  }

  export type CalificacionScalarWhereInput = {
    AND?: CalificacionScalarWhereInput | CalificacionScalarWhereInput[]
    OR?: CalificacionScalarWhereInput[]
    NOT?: CalificacionScalarWhereInput | CalificacionScalarWhereInput[]
    id?: IntFilter<"Calificacion"> | number
    estudianteId?: IntFilter<"Calificacion"> | number
    materiaId?: IntFilter<"Calificacion"> | number
    parcial1?: FloatFilter<"Calificacion"> | number
    parcial2?: FloatFilter<"Calificacion"> | number
    ordinario?: FloatFilter<"Calificacion"> | number
    final?: FloatFilter<"Calificacion"> | number
    fecha?: DateTimeFilter<"Calificacion"> | Date | string
  }

  export type AsistenciaUpsertWithWhereUniqueWithoutEstudianteInput = {
    where: AsistenciaWhereUniqueInput
    update: XOR<AsistenciaUpdateWithoutEstudianteInput, AsistenciaUncheckedUpdateWithoutEstudianteInput>
    create: XOR<AsistenciaCreateWithoutEstudianteInput, AsistenciaUncheckedCreateWithoutEstudianteInput>
  }

  export type AsistenciaUpdateWithWhereUniqueWithoutEstudianteInput = {
    where: AsistenciaWhereUniqueInput
    data: XOR<AsistenciaUpdateWithoutEstudianteInput, AsistenciaUncheckedUpdateWithoutEstudianteInput>
  }

  export type AsistenciaUpdateManyWithWhereWithoutEstudianteInput = {
    where: AsistenciaScalarWhereInput
    data: XOR<AsistenciaUpdateManyMutationInput, AsistenciaUncheckedUpdateManyWithoutEstudianteInput>
  }

  export type AsistenciaScalarWhereInput = {
    AND?: AsistenciaScalarWhereInput | AsistenciaScalarWhereInput[]
    OR?: AsistenciaScalarWhereInput[]
    NOT?: AsistenciaScalarWhereInput | AsistenciaScalarWhereInput[]
    id?: IntFilter<"Asistencia"> | number
    estudianteId?: IntFilter<"Asistencia"> | number
    materiaId?: IntFilter<"Asistencia"> | number
    parcial1?: IntFilter<"Asistencia"> | number
    parcial2?: IntFilter<"Asistencia"> | number
    final?: IntFilter<"Asistencia"> | number
    fecha?: DateTimeFilter<"Asistencia"> | Date | string
  }

  export type UsuarioCreateWithoutProfesorInput = {
    nombre: string
    correo: string
    telefono: string
    contrasena: string
    puesto: $Enums.RolUsuario
    fechaCreacion?: Date | string
    Estudiante?: EstudianteCreateNestedOneWithoutUsuarioInput
    PadreFamilia?: PadreFamiliaCreateNestedManyWithoutUsuarioInput
  }

  export type UsuarioUncheckedCreateWithoutProfesorInput = {
    id?: number
    nombre: string
    correo: string
    telefono: string
    contrasena: string
    puesto: $Enums.RolUsuario
    fechaCreacion?: Date | string
    Estudiante?: EstudianteUncheckedCreateNestedOneWithoutUsuarioInput
    PadreFamilia?: PadreFamiliaUncheckedCreateNestedManyWithoutUsuarioInput
  }

  export type UsuarioCreateOrConnectWithoutProfesorInput = {
    where: UsuarioWhereUniqueInput
    create: XOR<UsuarioCreateWithoutProfesorInput, UsuarioUncheckedCreateWithoutProfesorInput>
  }

  export type MaterialEducativoCreateWithoutProfesorInput = {
    titulo: string
    descripcion: string
    categoria: string
    existencia?: boolean
    fecha?: Date | string
    tipoArchivo: string
    grupo: GrupoCreateNestedOneWithoutMaterialesInput
    archivo?: ArchivoSubidoCreateNestedManyWithoutMaterialInput
  }

  export type MaterialEducativoUncheckedCreateWithoutProfesorInput = {
    id?: number
    titulo: string
    descripcion: string
    categoria: string
    existencia?: boolean
    fecha?: Date | string
    tipoArchivo: string
    grupoId: number
    archivo?: ArchivoSubidoUncheckedCreateNestedManyWithoutMaterialInput
  }

  export type MaterialEducativoCreateOrConnectWithoutProfesorInput = {
    where: MaterialEducativoWhereUniqueInput
    create: XOR<MaterialEducativoCreateWithoutProfesorInput, MaterialEducativoUncheckedCreateWithoutProfesorInput>
  }

  export type MaterialEducativoCreateManyProfesorInputEnvelope = {
    data: MaterialEducativoCreateManyProfesorInput | MaterialEducativoCreateManyProfesorInput[]
    skipDuplicates?: boolean
  }

  export type MateriaCreateWithoutProfesorInput = {
    nombre: string
    Calificacion?: CalificacionCreateNestedManyWithoutMateriaInput
    Asistencia?: AsistenciaCreateNestedManyWithoutMateriaInput
  }

  export type MateriaUncheckedCreateWithoutProfesorInput = {
    id?: number
    nombre: string
    Calificacion?: CalificacionUncheckedCreateNestedManyWithoutMateriaInput
    Asistencia?: AsistenciaUncheckedCreateNestedManyWithoutMateriaInput
  }

  export type MateriaCreateOrConnectWithoutProfesorInput = {
    where: MateriaWhereUniqueInput
    create: XOR<MateriaCreateWithoutProfesorInput, MateriaUncheckedCreateWithoutProfesorInput>
  }

  export type MateriaCreateManyProfesorInputEnvelope = {
    data: MateriaCreateManyProfesorInput | MateriaCreateManyProfesorInput[]
    skipDuplicates?: boolean
  }

  export type UsuarioUpsertWithoutProfesorInput = {
    update: XOR<UsuarioUpdateWithoutProfesorInput, UsuarioUncheckedUpdateWithoutProfesorInput>
    create: XOR<UsuarioCreateWithoutProfesorInput, UsuarioUncheckedCreateWithoutProfesorInput>
    where?: UsuarioWhereInput
  }

  export type UsuarioUpdateToOneWithWhereWithoutProfesorInput = {
    where?: UsuarioWhereInput
    data: XOR<UsuarioUpdateWithoutProfesorInput, UsuarioUncheckedUpdateWithoutProfesorInput>
  }

  export type UsuarioUpdateWithoutProfesorInput = {
    nombre?: StringFieldUpdateOperationsInput | string
    correo?: StringFieldUpdateOperationsInput | string
    telefono?: StringFieldUpdateOperationsInput | string
    contrasena?: StringFieldUpdateOperationsInput | string
    puesto?: EnumRolUsuarioFieldUpdateOperationsInput | $Enums.RolUsuario
    fechaCreacion?: DateTimeFieldUpdateOperationsInput | Date | string
    Estudiante?: EstudianteUpdateOneWithoutUsuarioNestedInput
    PadreFamilia?: PadreFamiliaUpdateManyWithoutUsuarioNestedInput
  }

  export type UsuarioUncheckedUpdateWithoutProfesorInput = {
    id?: IntFieldUpdateOperationsInput | number
    nombre?: StringFieldUpdateOperationsInput | string
    correo?: StringFieldUpdateOperationsInput | string
    telefono?: StringFieldUpdateOperationsInput | string
    contrasena?: StringFieldUpdateOperationsInput | string
    puesto?: EnumRolUsuarioFieldUpdateOperationsInput | $Enums.RolUsuario
    fechaCreacion?: DateTimeFieldUpdateOperationsInput | Date | string
    Estudiante?: EstudianteUncheckedUpdateOneWithoutUsuarioNestedInput
    PadreFamilia?: PadreFamiliaUncheckedUpdateManyWithoutUsuarioNestedInput
  }

  export type MaterialEducativoUpsertWithWhereUniqueWithoutProfesorInput = {
    where: MaterialEducativoWhereUniqueInput
    update: XOR<MaterialEducativoUpdateWithoutProfesorInput, MaterialEducativoUncheckedUpdateWithoutProfesorInput>
    create: XOR<MaterialEducativoCreateWithoutProfesorInput, MaterialEducativoUncheckedCreateWithoutProfesorInput>
  }

  export type MaterialEducativoUpdateWithWhereUniqueWithoutProfesorInput = {
    where: MaterialEducativoWhereUniqueInput
    data: XOR<MaterialEducativoUpdateWithoutProfesorInput, MaterialEducativoUncheckedUpdateWithoutProfesorInput>
  }

  export type MaterialEducativoUpdateManyWithWhereWithoutProfesorInput = {
    where: MaterialEducativoScalarWhereInput
    data: XOR<MaterialEducativoUpdateManyMutationInput, MaterialEducativoUncheckedUpdateManyWithoutProfesorInput>
  }

  export type MaterialEducativoScalarWhereInput = {
    AND?: MaterialEducativoScalarWhereInput | MaterialEducativoScalarWhereInput[]
    OR?: MaterialEducativoScalarWhereInput[]
    NOT?: MaterialEducativoScalarWhereInput | MaterialEducativoScalarWhereInput[]
    id?: IntFilter<"MaterialEducativo"> | number
    titulo?: StringFilter<"MaterialEducativo"> | string
    descripcion?: StringFilter<"MaterialEducativo"> | string
    categoria?: StringFilter<"MaterialEducativo"> | string
    existencia?: BoolFilter<"MaterialEducativo"> | boolean
    fecha?: DateTimeFilter<"MaterialEducativo"> | Date | string
    tipoArchivo?: StringFilter<"MaterialEducativo"> | string
    profesorId?: IntFilter<"MaterialEducativo"> | number
    grupoId?: IntFilter<"MaterialEducativo"> | number
  }

  export type MateriaUpsertWithWhereUniqueWithoutProfesorInput = {
    where: MateriaWhereUniqueInput
    update: XOR<MateriaUpdateWithoutProfesorInput, MateriaUncheckedUpdateWithoutProfesorInput>
    create: XOR<MateriaCreateWithoutProfesorInput, MateriaUncheckedCreateWithoutProfesorInput>
  }

  export type MateriaUpdateWithWhereUniqueWithoutProfesorInput = {
    where: MateriaWhereUniqueInput
    data: XOR<MateriaUpdateWithoutProfesorInput, MateriaUncheckedUpdateWithoutProfesorInput>
  }

  export type MateriaUpdateManyWithWhereWithoutProfesorInput = {
    where: MateriaScalarWhereInput
    data: XOR<MateriaUpdateManyMutationInput, MateriaUncheckedUpdateManyWithoutProfesorInput>
  }

  export type MateriaScalarWhereInput = {
    AND?: MateriaScalarWhereInput | MateriaScalarWhereInput[]
    OR?: MateriaScalarWhereInput[]
    NOT?: MateriaScalarWhereInput | MateriaScalarWhereInput[]
    id?: IntFilter<"Materia"> | number
    nombre?: StringFilter<"Materia"> | string
    profesorId?: IntFilter<"Materia"> | number
  }

  export type UsuarioCreateWithoutPadreFamiliaInput = {
    nombre: string
    correo: string
    telefono: string
    contrasena: string
    puesto: $Enums.RolUsuario
    fechaCreacion?: Date | string
    Estudiante?: EstudianteCreateNestedOneWithoutUsuarioInput
    Profesor?: ProfesorCreateNestedOneWithoutUsuarioInput
  }

  export type UsuarioUncheckedCreateWithoutPadreFamiliaInput = {
    id?: number
    nombre: string
    correo: string
    telefono: string
    contrasena: string
    puesto: $Enums.RolUsuario
    fechaCreacion?: Date | string
    Estudiante?: EstudianteUncheckedCreateNestedOneWithoutUsuarioInput
    Profesor?: ProfesorUncheckedCreateNestedOneWithoutUsuarioInput
  }

  export type UsuarioCreateOrConnectWithoutPadreFamiliaInput = {
    where: UsuarioWhereUniqueInput
    create: XOR<UsuarioCreateWithoutPadreFamiliaInput, UsuarioUncheckedCreateWithoutPadreFamiliaInput>
  }

  export type EstudianteCreateWithoutPadreFamiliaInput = {
    estado?: $Enums.EstadoEstudiante
    tramites?: TramiteCreateNestedManyWithoutEstudianteInput
    grupo?: GrupoCreateNestedOneWithoutEstudiantesInput
    usuario: UsuarioCreateNestedOneWithoutEstudianteInput
    Calificacion?: CalificacionCreateNestedManyWithoutEstudianteInput
    Asistencia?: AsistenciaCreateNestedManyWithoutEstudianteInput
  }

  export type EstudianteUncheckedCreateWithoutPadreFamiliaInput = {
    usuarioId: number
    grupoId?: number | null
    estado?: $Enums.EstadoEstudiante
    tramites?: TramiteUncheckedCreateNestedManyWithoutEstudianteInput
    Calificacion?: CalificacionUncheckedCreateNestedManyWithoutEstudianteInput
    Asistencia?: AsistenciaUncheckedCreateNestedManyWithoutEstudianteInput
  }

  export type EstudianteCreateOrConnectWithoutPadreFamiliaInput = {
    where: EstudianteWhereUniqueInput
    create: XOR<EstudianteCreateWithoutPadreFamiliaInput, EstudianteUncheckedCreateWithoutPadreFamiliaInput>
  }

  export type EstudianteCreateManyPadreFamiliaInputEnvelope = {
    data: EstudianteCreateManyPadreFamiliaInput | EstudianteCreateManyPadreFamiliaInput[]
    skipDuplicates?: boolean
  }

  export type UsuarioUpsertWithoutPadreFamiliaInput = {
    update: XOR<UsuarioUpdateWithoutPadreFamiliaInput, UsuarioUncheckedUpdateWithoutPadreFamiliaInput>
    create: XOR<UsuarioCreateWithoutPadreFamiliaInput, UsuarioUncheckedCreateWithoutPadreFamiliaInput>
    where?: UsuarioWhereInput
  }

  export type UsuarioUpdateToOneWithWhereWithoutPadreFamiliaInput = {
    where?: UsuarioWhereInput
    data: XOR<UsuarioUpdateWithoutPadreFamiliaInput, UsuarioUncheckedUpdateWithoutPadreFamiliaInput>
  }

  export type UsuarioUpdateWithoutPadreFamiliaInput = {
    nombre?: StringFieldUpdateOperationsInput | string
    correo?: StringFieldUpdateOperationsInput | string
    telefono?: StringFieldUpdateOperationsInput | string
    contrasena?: StringFieldUpdateOperationsInput | string
    puesto?: EnumRolUsuarioFieldUpdateOperationsInput | $Enums.RolUsuario
    fechaCreacion?: DateTimeFieldUpdateOperationsInput | Date | string
    Estudiante?: EstudianteUpdateOneWithoutUsuarioNestedInput
    Profesor?: ProfesorUpdateOneWithoutUsuarioNestedInput
  }

  export type UsuarioUncheckedUpdateWithoutPadreFamiliaInput = {
    id?: IntFieldUpdateOperationsInput | number
    nombre?: StringFieldUpdateOperationsInput | string
    correo?: StringFieldUpdateOperationsInput | string
    telefono?: StringFieldUpdateOperationsInput | string
    contrasena?: StringFieldUpdateOperationsInput | string
    puesto?: EnumRolUsuarioFieldUpdateOperationsInput | $Enums.RolUsuario
    fechaCreacion?: DateTimeFieldUpdateOperationsInput | Date | string
    Estudiante?: EstudianteUncheckedUpdateOneWithoutUsuarioNestedInput
    Profesor?: ProfesorUncheckedUpdateOneWithoutUsuarioNestedInput
  }

  export type EstudianteUpsertWithWhereUniqueWithoutPadreFamiliaInput = {
    where: EstudianteWhereUniqueInput
    update: XOR<EstudianteUpdateWithoutPadreFamiliaInput, EstudianteUncheckedUpdateWithoutPadreFamiliaInput>
    create: XOR<EstudianteCreateWithoutPadreFamiliaInput, EstudianteUncheckedCreateWithoutPadreFamiliaInput>
  }

  export type EstudianteUpdateWithWhereUniqueWithoutPadreFamiliaInput = {
    where: EstudianteWhereUniqueInput
    data: XOR<EstudianteUpdateWithoutPadreFamiliaInput, EstudianteUncheckedUpdateWithoutPadreFamiliaInput>
  }

  export type EstudianteUpdateManyWithWhereWithoutPadreFamiliaInput = {
    where: EstudianteScalarWhereInput
    data: XOR<EstudianteUpdateManyMutationInput, EstudianteUncheckedUpdateManyWithoutPadreFamiliaInput>
  }

  export type EstudianteScalarWhereInput = {
    AND?: EstudianteScalarWhereInput | EstudianteScalarWhereInput[]
    OR?: EstudianteScalarWhereInput[]
    NOT?: EstudianteScalarWhereInput | EstudianteScalarWhereInput[]
    usuarioId?: IntFilter<"Estudiante"> | number
    grupoId?: IntNullableFilter<"Estudiante"> | number | null
    padreFamiliaId?: IntNullableFilter<"Estudiante"> | number | null
    estado?: EnumEstadoEstudianteFilter<"Estudiante"> | $Enums.EstadoEstudiante
  }

  export type EstudianteCreateWithoutGrupoInput = {
    estado?: $Enums.EstadoEstudiante
    tramites?: TramiteCreateNestedManyWithoutEstudianteInput
    usuario: UsuarioCreateNestedOneWithoutEstudianteInput
    PadreFamilia?: PadreFamiliaCreateNestedOneWithoutEstudiantesInput
    Calificacion?: CalificacionCreateNestedManyWithoutEstudianteInput
    Asistencia?: AsistenciaCreateNestedManyWithoutEstudianteInput
  }

  export type EstudianteUncheckedCreateWithoutGrupoInput = {
    usuarioId: number
    padreFamiliaId?: number | null
    estado?: $Enums.EstadoEstudiante
    tramites?: TramiteUncheckedCreateNestedManyWithoutEstudianteInput
    Calificacion?: CalificacionUncheckedCreateNestedManyWithoutEstudianteInput
    Asistencia?: AsistenciaUncheckedCreateNestedManyWithoutEstudianteInput
  }

  export type EstudianteCreateOrConnectWithoutGrupoInput = {
    where: EstudianteWhereUniqueInput
    create: XOR<EstudianteCreateWithoutGrupoInput, EstudianteUncheckedCreateWithoutGrupoInput>
  }

  export type EstudianteCreateManyGrupoInputEnvelope = {
    data: EstudianteCreateManyGrupoInput | EstudianteCreateManyGrupoInput[]
    skipDuplicates?: boolean
  }

  export type InscripcionCreateWithoutGrupoInput = {
    tramite: TramiteCreateNestedOneWithoutInscripcionInput
  }

  export type InscripcionUncheckedCreateWithoutGrupoInput = {
    tramiteId: number
  }

  export type InscripcionCreateOrConnectWithoutGrupoInput = {
    where: InscripcionWhereUniqueInput
    create: XOR<InscripcionCreateWithoutGrupoInput, InscripcionUncheckedCreateWithoutGrupoInput>
  }

  export type InscripcionCreateManyGrupoInputEnvelope = {
    data: InscripcionCreateManyGrupoInput | InscripcionCreateManyGrupoInput[]
    skipDuplicates?: boolean
  }

  export type MaterialEducativoCreateWithoutGrupoInput = {
    titulo: string
    descripcion: string
    categoria: string
    existencia?: boolean
    fecha?: Date | string
    tipoArchivo: string
    profesor: ProfesorCreateNestedOneWithoutMaterialesInput
    archivo?: ArchivoSubidoCreateNestedManyWithoutMaterialInput
  }

  export type MaterialEducativoUncheckedCreateWithoutGrupoInput = {
    id?: number
    titulo: string
    descripcion: string
    categoria: string
    existencia?: boolean
    fecha?: Date | string
    tipoArchivo: string
    profesorId: number
    archivo?: ArchivoSubidoUncheckedCreateNestedManyWithoutMaterialInput
  }

  export type MaterialEducativoCreateOrConnectWithoutGrupoInput = {
    where: MaterialEducativoWhereUniqueInput
    create: XOR<MaterialEducativoCreateWithoutGrupoInput, MaterialEducativoUncheckedCreateWithoutGrupoInput>
  }

  export type MaterialEducativoCreateManyGrupoInputEnvelope = {
    data: MaterialEducativoCreateManyGrupoInput | MaterialEducativoCreateManyGrupoInput[]
    skipDuplicates?: boolean
  }

  export type EstudianteUpsertWithWhereUniqueWithoutGrupoInput = {
    where: EstudianteWhereUniqueInput
    update: XOR<EstudianteUpdateWithoutGrupoInput, EstudianteUncheckedUpdateWithoutGrupoInput>
    create: XOR<EstudianteCreateWithoutGrupoInput, EstudianteUncheckedCreateWithoutGrupoInput>
  }

  export type EstudianteUpdateWithWhereUniqueWithoutGrupoInput = {
    where: EstudianteWhereUniqueInput
    data: XOR<EstudianteUpdateWithoutGrupoInput, EstudianteUncheckedUpdateWithoutGrupoInput>
  }

  export type EstudianteUpdateManyWithWhereWithoutGrupoInput = {
    where: EstudianteScalarWhereInput
    data: XOR<EstudianteUpdateManyMutationInput, EstudianteUncheckedUpdateManyWithoutGrupoInput>
  }

  export type InscripcionUpsertWithWhereUniqueWithoutGrupoInput = {
    where: InscripcionWhereUniqueInput
    update: XOR<InscripcionUpdateWithoutGrupoInput, InscripcionUncheckedUpdateWithoutGrupoInput>
    create: XOR<InscripcionCreateWithoutGrupoInput, InscripcionUncheckedCreateWithoutGrupoInput>
  }

  export type InscripcionUpdateWithWhereUniqueWithoutGrupoInput = {
    where: InscripcionWhereUniqueInput
    data: XOR<InscripcionUpdateWithoutGrupoInput, InscripcionUncheckedUpdateWithoutGrupoInput>
  }

  export type InscripcionUpdateManyWithWhereWithoutGrupoInput = {
    where: InscripcionScalarWhereInput
    data: XOR<InscripcionUpdateManyMutationInput, InscripcionUncheckedUpdateManyWithoutGrupoInput>
  }

  export type InscripcionScalarWhereInput = {
    AND?: InscripcionScalarWhereInput | InscripcionScalarWhereInput[]
    OR?: InscripcionScalarWhereInput[]
    NOT?: InscripcionScalarWhereInput | InscripcionScalarWhereInput[]
    tramiteId?: IntFilter<"Inscripcion"> | number
    grupoId?: IntFilter<"Inscripcion"> | number
  }

  export type MaterialEducativoUpsertWithWhereUniqueWithoutGrupoInput = {
    where: MaterialEducativoWhereUniqueInput
    update: XOR<MaterialEducativoUpdateWithoutGrupoInput, MaterialEducativoUncheckedUpdateWithoutGrupoInput>
    create: XOR<MaterialEducativoCreateWithoutGrupoInput, MaterialEducativoUncheckedCreateWithoutGrupoInput>
  }

  export type MaterialEducativoUpdateWithWhereUniqueWithoutGrupoInput = {
    where: MaterialEducativoWhereUniqueInput
    data: XOR<MaterialEducativoUpdateWithoutGrupoInput, MaterialEducativoUncheckedUpdateWithoutGrupoInput>
  }

  export type MaterialEducativoUpdateManyWithWhereWithoutGrupoInput = {
    where: MaterialEducativoScalarWhereInput
    data: XOR<MaterialEducativoUpdateManyMutationInput, MaterialEducativoUncheckedUpdateManyWithoutGrupoInput>
  }

  export type InscripcionCreateWithoutTramiteInput = {
    grupo: GrupoCreateNestedOneWithoutInscripcionesInput
  }

  export type InscripcionUncheckedCreateWithoutTramiteInput = {
    grupoId: number
  }

  export type InscripcionCreateOrConnectWithoutTramiteInput = {
    where: InscripcionWhereUniqueInput
    create: XOR<InscripcionCreateWithoutTramiteInput, InscripcionUncheckedCreateWithoutTramiteInput>
  }

  export type PagoCreateWithoutTramiteInput = {
    concepto: string
    monto: number
    recibos?: ReciboCreateNestedManyWithoutPagoInput
  }

  export type PagoUncheckedCreateWithoutTramiteInput = {
    concepto: string
    monto: number
    recibos?: ReciboUncheckedCreateNestedManyWithoutPagoInput
  }

  export type PagoCreateOrConnectWithoutTramiteInput = {
    where: PagoWhereUniqueInput
    create: XOR<PagoCreateWithoutTramiteInput, PagoUncheckedCreateWithoutTramiteInput>
  }

  export type EstudianteCreateWithoutTramitesInput = {
    estado?: $Enums.EstadoEstudiante
    grupo?: GrupoCreateNestedOneWithoutEstudiantesInput
    usuario: UsuarioCreateNestedOneWithoutEstudianteInput
    PadreFamilia?: PadreFamiliaCreateNestedOneWithoutEstudiantesInput
    Calificacion?: CalificacionCreateNestedManyWithoutEstudianteInput
    Asistencia?: AsistenciaCreateNestedManyWithoutEstudianteInput
  }

  export type EstudianteUncheckedCreateWithoutTramitesInput = {
    usuarioId: number
    grupoId?: number | null
    padreFamiliaId?: number | null
    estado?: $Enums.EstadoEstudiante
    Calificacion?: CalificacionUncheckedCreateNestedManyWithoutEstudianteInput
    Asistencia?: AsistenciaUncheckedCreateNestedManyWithoutEstudianteInput
  }

  export type EstudianteCreateOrConnectWithoutTramitesInput = {
    where: EstudianteWhereUniqueInput
    create: XOR<EstudianteCreateWithoutTramitesInput, EstudianteUncheckedCreateWithoutTramitesInput>
  }

  export type InscripcionUpsertWithoutTramiteInput = {
    update: XOR<InscripcionUpdateWithoutTramiteInput, InscripcionUncheckedUpdateWithoutTramiteInput>
    create: XOR<InscripcionCreateWithoutTramiteInput, InscripcionUncheckedCreateWithoutTramiteInput>
    where?: InscripcionWhereInput
  }

  export type InscripcionUpdateToOneWithWhereWithoutTramiteInput = {
    where?: InscripcionWhereInput
    data: XOR<InscripcionUpdateWithoutTramiteInput, InscripcionUncheckedUpdateWithoutTramiteInput>
  }

  export type InscripcionUpdateWithoutTramiteInput = {
    grupo?: GrupoUpdateOneRequiredWithoutInscripcionesNestedInput
  }

  export type InscripcionUncheckedUpdateWithoutTramiteInput = {
    grupoId?: IntFieldUpdateOperationsInput | number
  }

  export type PagoUpsertWithoutTramiteInput = {
    update: XOR<PagoUpdateWithoutTramiteInput, PagoUncheckedUpdateWithoutTramiteInput>
    create: XOR<PagoCreateWithoutTramiteInput, PagoUncheckedCreateWithoutTramiteInput>
    where?: PagoWhereInput
  }

  export type PagoUpdateToOneWithWhereWithoutTramiteInput = {
    where?: PagoWhereInput
    data: XOR<PagoUpdateWithoutTramiteInput, PagoUncheckedUpdateWithoutTramiteInput>
  }

  export type PagoUpdateWithoutTramiteInput = {
    concepto?: StringFieldUpdateOperationsInput | string
    monto?: FloatFieldUpdateOperationsInput | number
    recibos?: ReciboUpdateManyWithoutPagoNestedInput
  }

  export type PagoUncheckedUpdateWithoutTramiteInput = {
    concepto?: StringFieldUpdateOperationsInput | string
    monto?: FloatFieldUpdateOperationsInput | number
    recibos?: ReciboUncheckedUpdateManyWithoutPagoNestedInput
  }

  export type EstudianteUpsertWithoutTramitesInput = {
    update: XOR<EstudianteUpdateWithoutTramitesInput, EstudianteUncheckedUpdateWithoutTramitesInput>
    create: XOR<EstudianteCreateWithoutTramitesInput, EstudianteUncheckedCreateWithoutTramitesInput>
    where?: EstudianteWhereInput
  }

  export type EstudianteUpdateToOneWithWhereWithoutTramitesInput = {
    where?: EstudianteWhereInput
    data: XOR<EstudianteUpdateWithoutTramitesInput, EstudianteUncheckedUpdateWithoutTramitesInput>
  }

  export type EstudianteUpdateWithoutTramitesInput = {
    estado?: EnumEstadoEstudianteFieldUpdateOperationsInput | $Enums.EstadoEstudiante
    grupo?: GrupoUpdateOneWithoutEstudiantesNestedInput
    usuario?: UsuarioUpdateOneRequiredWithoutEstudianteNestedInput
    PadreFamilia?: PadreFamiliaUpdateOneWithoutEstudiantesNestedInput
    Calificacion?: CalificacionUpdateManyWithoutEstudianteNestedInput
    Asistencia?: AsistenciaUpdateManyWithoutEstudianteNestedInput
  }

  export type EstudianteUncheckedUpdateWithoutTramitesInput = {
    usuarioId?: IntFieldUpdateOperationsInput | number
    grupoId?: NullableIntFieldUpdateOperationsInput | number | null
    padreFamiliaId?: NullableIntFieldUpdateOperationsInput | number | null
    estado?: EnumEstadoEstudianteFieldUpdateOperationsInput | $Enums.EstadoEstudiante
    Calificacion?: CalificacionUncheckedUpdateManyWithoutEstudianteNestedInput
    Asistencia?: AsistenciaUncheckedUpdateManyWithoutEstudianteNestedInput
  }

  export type TramiteCreateWithoutInscripcionInput = {
    tipo: $Enums.TipoTramite
    estado: $Enums.EstadoTramite
    fecha?: Date | string
    Pago?: PagoCreateNestedOneWithoutTramiteInput
    estudiante: EstudianteCreateNestedOneWithoutTramitesInput
  }

  export type TramiteUncheckedCreateWithoutInscripcionInput = {
    id?: number
    estudianteId: number
    tipo: $Enums.TipoTramite
    estado: $Enums.EstadoTramite
    fecha?: Date | string
    Pago?: PagoUncheckedCreateNestedOneWithoutTramiteInput
  }

  export type TramiteCreateOrConnectWithoutInscripcionInput = {
    where: TramiteWhereUniqueInput
    create: XOR<TramiteCreateWithoutInscripcionInput, TramiteUncheckedCreateWithoutInscripcionInput>
  }

  export type GrupoCreateWithoutInscripcionesInput = {
    nombre: string
    grado: number
    estudiantes?: EstudianteCreateNestedManyWithoutGrupoInput
    materiales?: MaterialEducativoCreateNestedManyWithoutGrupoInput
  }

  export type GrupoUncheckedCreateWithoutInscripcionesInput = {
    id?: number
    nombre: string
    grado: number
    estudiantes?: EstudianteUncheckedCreateNestedManyWithoutGrupoInput
    materiales?: MaterialEducativoUncheckedCreateNestedManyWithoutGrupoInput
  }

  export type GrupoCreateOrConnectWithoutInscripcionesInput = {
    where: GrupoWhereUniqueInput
    create: XOR<GrupoCreateWithoutInscripcionesInput, GrupoUncheckedCreateWithoutInscripcionesInput>
  }

  export type TramiteUpsertWithoutInscripcionInput = {
    update: XOR<TramiteUpdateWithoutInscripcionInput, TramiteUncheckedUpdateWithoutInscripcionInput>
    create: XOR<TramiteCreateWithoutInscripcionInput, TramiteUncheckedCreateWithoutInscripcionInput>
    where?: TramiteWhereInput
  }

  export type TramiteUpdateToOneWithWhereWithoutInscripcionInput = {
    where?: TramiteWhereInput
    data: XOR<TramiteUpdateWithoutInscripcionInput, TramiteUncheckedUpdateWithoutInscripcionInput>
  }

  export type TramiteUpdateWithoutInscripcionInput = {
    tipo?: EnumTipoTramiteFieldUpdateOperationsInput | $Enums.TipoTramite
    estado?: EnumEstadoTramiteFieldUpdateOperationsInput | $Enums.EstadoTramite
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    Pago?: PagoUpdateOneWithoutTramiteNestedInput
    estudiante?: EstudianteUpdateOneRequiredWithoutTramitesNestedInput
  }

  export type TramiteUncheckedUpdateWithoutInscripcionInput = {
    id?: IntFieldUpdateOperationsInput | number
    estudianteId?: IntFieldUpdateOperationsInput | number
    tipo?: EnumTipoTramiteFieldUpdateOperationsInput | $Enums.TipoTramite
    estado?: EnumEstadoTramiteFieldUpdateOperationsInput | $Enums.EstadoTramite
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    Pago?: PagoUncheckedUpdateOneWithoutTramiteNestedInput
  }

  export type GrupoUpsertWithoutInscripcionesInput = {
    update: XOR<GrupoUpdateWithoutInscripcionesInput, GrupoUncheckedUpdateWithoutInscripcionesInput>
    create: XOR<GrupoCreateWithoutInscripcionesInput, GrupoUncheckedCreateWithoutInscripcionesInput>
    where?: GrupoWhereInput
  }

  export type GrupoUpdateToOneWithWhereWithoutInscripcionesInput = {
    where?: GrupoWhereInput
    data: XOR<GrupoUpdateWithoutInscripcionesInput, GrupoUncheckedUpdateWithoutInscripcionesInput>
  }

  export type GrupoUpdateWithoutInscripcionesInput = {
    nombre?: StringFieldUpdateOperationsInput | string
    grado?: IntFieldUpdateOperationsInput | number
    estudiantes?: EstudianteUpdateManyWithoutGrupoNestedInput
    materiales?: MaterialEducativoUpdateManyWithoutGrupoNestedInput
  }

  export type GrupoUncheckedUpdateWithoutInscripcionesInput = {
    id?: IntFieldUpdateOperationsInput | number
    nombre?: StringFieldUpdateOperationsInput | string
    grado?: IntFieldUpdateOperationsInput | number
    estudiantes?: EstudianteUncheckedUpdateManyWithoutGrupoNestedInput
    materiales?: MaterialEducativoUncheckedUpdateManyWithoutGrupoNestedInput
  }

  export type ReciboCreateWithoutPagoInput = {
    monto: number
    fecha?: Date | string
  }

  export type ReciboUncheckedCreateWithoutPagoInput = {
    id?: number
    monto: number
    fecha?: Date | string
  }

  export type ReciboCreateOrConnectWithoutPagoInput = {
    where: ReciboWhereUniqueInput
    create: XOR<ReciboCreateWithoutPagoInput, ReciboUncheckedCreateWithoutPagoInput>
  }

  export type ReciboCreateManyPagoInputEnvelope = {
    data: ReciboCreateManyPagoInput | ReciboCreateManyPagoInput[]
    skipDuplicates?: boolean
  }

  export type TramiteCreateWithoutPagoInput = {
    tipo: $Enums.TipoTramite
    estado: $Enums.EstadoTramite
    fecha?: Date | string
    inscripcion?: InscripcionCreateNestedOneWithoutTramiteInput
    estudiante: EstudianteCreateNestedOneWithoutTramitesInput
  }

  export type TramiteUncheckedCreateWithoutPagoInput = {
    id?: number
    estudianteId: number
    tipo: $Enums.TipoTramite
    estado: $Enums.EstadoTramite
    fecha?: Date | string
    inscripcion?: InscripcionUncheckedCreateNestedOneWithoutTramiteInput
  }

  export type TramiteCreateOrConnectWithoutPagoInput = {
    where: TramiteWhereUniqueInput
    create: XOR<TramiteCreateWithoutPagoInput, TramiteUncheckedCreateWithoutPagoInput>
  }

  export type ReciboUpsertWithWhereUniqueWithoutPagoInput = {
    where: ReciboWhereUniqueInput
    update: XOR<ReciboUpdateWithoutPagoInput, ReciboUncheckedUpdateWithoutPagoInput>
    create: XOR<ReciboCreateWithoutPagoInput, ReciboUncheckedCreateWithoutPagoInput>
  }

  export type ReciboUpdateWithWhereUniqueWithoutPagoInput = {
    where: ReciboWhereUniqueInput
    data: XOR<ReciboUpdateWithoutPagoInput, ReciboUncheckedUpdateWithoutPagoInput>
  }

  export type ReciboUpdateManyWithWhereWithoutPagoInput = {
    where: ReciboScalarWhereInput
    data: XOR<ReciboUpdateManyMutationInput, ReciboUncheckedUpdateManyWithoutPagoInput>
  }

  export type ReciboScalarWhereInput = {
    AND?: ReciboScalarWhereInput | ReciboScalarWhereInput[]
    OR?: ReciboScalarWhereInput[]
    NOT?: ReciboScalarWhereInput | ReciboScalarWhereInput[]
    id?: IntFilter<"Recibo"> | number
    pagoId?: IntFilter<"Recibo"> | number
    monto?: FloatFilter<"Recibo"> | number
    fecha?: DateTimeFilter<"Recibo"> | Date | string
  }

  export type TramiteUpsertWithoutPagoInput = {
    update: XOR<TramiteUpdateWithoutPagoInput, TramiteUncheckedUpdateWithoutPagoInput>
    create: XOR<TramiteCreateWithoutPagoInput, TramiteUncheckedCreateWithoutPagoInput>
    where?: TramiteWhereInput
  }

  export type TramiteUpdateToOneWithWhereWithoutPagoInput = {
    where?: TramiteWhereInput
    data: XOR<TramiteUpdateWithoutPagoInput, TramiteUncheckedUpdateWithoutPagoInput>
  }

  export type TramiteUpdateWithoutPagoInput = {
    tipo?: EnumTipoTramiteFieldUpdateOperationsInput | $Enums.TipoTramite
    estado?: EnumEstadoTramiteFieldUpdateOperationsInput | $Enums.EstadoTramite
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    inscripcion?: InscripcionUpdateOneWithoutTramiteNestedInput
    estudiante?: EstudianteUpdateOneRequiredWithoutTramitesNestedInput
  }

  export type TramiteUncheckedUpdateWithoutPagoInput = {
    id?: IntFieldUpdateOperationsInput | number
    estudianteId?: IntFieldUpdateOperationsInput | number
    tipo?: EnumTipoTramiteFieldUpdateOperationsInput | $Enums.TipoTramite
    estado?: EnumEstadoTramiteFieldUpdateOperationsInput | $Enums.EstadoTramite
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    inscripcion?: InscripcionUncheckedUpdateOneWithoutTramiteNestedInput
  }

  export type PagoCreateWithoutRecibosInput = {
    concepto: string
    monto: number
    tramite: TramiteCreateNestedOneWithoutPagoInput
  }

  export type PagoUncheckedCreateWithoutRecibosInput = {
    tramiteId: number
    concepto: string
    monto: number
  }

  export type PagoCreateOrConnectWithoutRecibosInput = {
    where: PagoWhereUniqueInput
    create: XOR<PagoCreateWithoutRecibosInput, PagoUncheckedCreateWithoutRecibosInput>
  }

  export type PagoUpsertWithoutRecibosInput = {
    update: XOR<PagoUpdateWithoutRecibosInput, PagoUncheckedUpdateWithoutRecibosInput>
    create: XOR<PagoCreateWithoutRecibosInput, PagoUncheckedCreateWithoutRecibosInput>
    where?: PagoWhereInput
  }

  export type PagoUpdateToOneWithWhereWithoutRecibosInput = {
    where?: PagoWhereInput
    data: XOR<PagoUpdateWithoutRecibosInput, PagoUncheckedUpdateWithoutRecibosInput>
  }

  export type PagoUpdateWithoutRecibosInput = {
    concepto?: StringFieldUpdateOperationsInput | string
    monto?: FloatFieldUpdateOperationsInput | number
    tramite?: TramiteUpdateOneRequiredWithoutPagoNestedInput
  }

  export type PagoUncheckedUpdateWithoutRecibosInput = {
    tramiteId?: IntFieldUpdateOperationsInput | number
    concepto?: StringFieldUpdateOperationsInput | string
    monto?: FloatFieldUpdateOperationsInput | number
  }

  export type ProfesorCreateWithoutMaterialesInput = {
    usuario: UsuarioCreateNestedOneWithoutProfesorInput
    Materia?: MateriaCreateNestedManyWithoutProfesorInput
  }

  export type ProfesorUncheckedCreateWithoutMaterialesInput = {
    usuarioId: number
    Materia?: MateriaUncheckedCreateNestedManyWithoutProfesorInput
  }

  export type ProfesorCreateOrConnectWithoutMaterialesInput = {
    where: ProfesorWhereUniqueInput
    create: XOR<ProfesorCreateWithoutMaterialesInput, ProfesorUncheckedCreateWithoutMaterialesInput>
  }

  export type GrupoCreateWithoutMaterialesInput = {
    nombre: string
    grado: number
    estudiantes?: EstudianteCreateNestedManyWithoutGrupoInput
    inscripciones?: InscripcionCreateNestedManyWithoutGrupoInput
  }

  export type GrupoUncheckedCreateWithoutMaterialesInput = {
    id?: number
    nombre: string
    grado: number
    estudiantes?: EstudianteUncheckedCreateNestedManyWithoutGrupoInput
    inscripciones?: InscripcionUncheckedCreateNestedManyWithoutGrupoInput
  }

  export type GrupoCreateOrConnectWithoutMaterialesInput = {
    where: GrupoWhereUniqueInput
    create: XOR<GrupoCreateWithoutMaterialesInput, GrupoUncheckedCreateWithoutMaterialesInput>
  }

  export type ArchivoSubidoCreateWithoutMaterialInput = {
    nombreArchivo: string
    urlNube: string
  }

  export type ArchivoSubidoUncheckedCreateWithoutMaterialInput = {
    id?: number
    nombreArchivo: string
    urlNube: string
  }

  export type ArchivoSubidoCreateOrConnectWithoutMaterialInput = {
    where: ArchivoSubidoWhereUniqueInput
    create: XOR<ArchivoSubidoCreateWithoutMaterialInput, ArchivoSubidoUncheckedCreateWithoutMaterialInput>
  }

  export type ArchivoSubidoCreateManyMaterialInputEnvelope = {
    data: ArchivoSubidoCreateManyMaterialInput | ArchivoSubidoCreateManyMaterialInput[]
    skipDuplicates?: boolean
  }

  export type ProfesorUpsertWithoutMaterialesInput = {
    update: XOR<ProfesorUpdateWithoutMaterialesInput, ProfesorUncheckedUpdateWithoutMaterialesInput>
    create: XOR<ProfesorCreateWithoutMaterialesInput, ProfesorUncheckedCreateWithoutMaterialesInput>
    where?: ProfesorWhereInput
  }

  export type ProfesorUpdateToOneWithWhereWithoutMaterialesInput = {
    where?: ProfesorWhereInput
    data: XOR<ProfesorUpdateWithoutMaterialesInput, ProfesorUncheckedUpdateWithoutMaterialesInput>
  }

  export type ProfesorUpdateWithoutMaterialesInput = {
    usuario?: UsuarioUpdateOneRequiredWithoutProfesorNestedInput
    Materia?: MateriaUpdateManyWithoutProfesorNestedInput
  }

  export type ProfesorUncheckedUpdateWithoutMaterialesInput = {
    usuarioId?: IntFieldUpdateOperationsInput | number
    Materia?: MateriaUncheckedUpdateManyWithoutProfesorNestedInput
  }

  export type GrupoUpsertWithoutMaterialesInput = {
    update: XOR<GrupoUpdateWithoutMaterialesInput, GrupoUncheckedUpdateWithoutMaterialesInput>
    create: XOR<GrupoCreateWithoutMaterialesInput, GrupoUncheckedCreateWithoutMaterialesInput>
    where?: GrupoWhereInput
  }

  export type GrupoUpdateToOneWithWhereWithoutMaterialesInput = {
    where?: GrupoWhereInput
    data: XOR<GrupoUpdateWithoutMaterialesInput, GrupoUncheckedUpdateWithoutMaterialesInput>
  }

  export type GrupoUpdateWithoutMaterialesInput = {
    nombre?: StringFieldUpdateOperationsInput | string
    grado?: IntFieldUpdateOperationsInput | number
    estudiantes?: EstudianteUpdateManyWithoutGrupoNestedInput
    inscripciones?: InscripcionUpdateManyWithoutGrupoNestedInput
  }

  export type GrupoUncheckedUpdateWithoutMaterialesInput = {
    id?: IntFieldUpdateOperationsInput | number
    nombre?: StringFieldUpdateOperationsInput | string
    grado?: IntFieldUpdateOperationsInput | number
    estudiantes?: EstudianteUncheckedUpdateManyWithoutGrupoNestedInput
    inscripciones?: InscripcionUncheckedUpdateManyWithoutGrupoNestedInput
  }

  export type ArchivoSubidoUpsertWithWhereUniqueWithoutMaterialInput = {
    where: ArchivoSubidoWhereUniqueInput
    update: XOR<ArchivoSubidoUpdateWithoutMaterialInput, ArchivoSubidoUncheckedUpdateWithoutMaterialInput>
    create: XOR<ArchivoSubidoCreateWithoutMaterialInput, ArchivoSubidoUncheckedCreateWithoutMaterialInput>
  }

  export type ArchivoSubidoUpdateWithWhereUniqueWithoutMaterialInput = {
    where: ArchivoSubidoWhereUniqueInput
    data: XOR<ArchivoSubidoUpdateWithoutMaterialInput, ArchivoSubidoUncheckedUpdateWithoutMaterialInput>
  }

  export type ArchivoSubidoUpdateManyWithWhereWithoutMaterialInput = {
    where: ArchivoSubidoScalarWhereInput
    data: XOR<ArchivoSubidoUpdateManyMutationInput, ArchivoSubidoUncheckedUpdateManyWithoutMaterialInput>
  }

  export type ArchivoSubidoScalarWhereInput = {
    AND?: ArchivoSubidoScalarWhereInput | ArchivoSubidoScalarWhereInput[]
    OR?: ArchivoSubidoScalarWhereInput[]
    NOT?: ArchivoSubidoScalarWhereInput | ArchivoSubidoScalarWhereInput[]
    id?: IntFilter<"ArchivoSubido"> | number
    materialId?: IntFilter<"ArchivoSubido"> | number
    nombreArchivo?: StringFilter<"ArchivoSubido"> | string
    urlNube?: StringFilter<"ArchivoSubido"> | string
  }

  export type MaterialEducativoCreateWithoutArchivoInput = {
    titulo: string
    descripcion: string
    categoria: string
    existencia?: boolean
    fecha?: Date | string
    tipoArchivo: string
    profesor: ProfesorCreateNestedOneWithoutMaterialesInput
    grupo: GrupoCreateNestedOneWithoutMaterialesInput
  }

  export type MaterialEducativoUncheckedCreateWithoutArchivoInput = {
    id?: number
    titulo: string
    descripcion: string
    categoria: string
    existencia?: boolean
    fecha?: Date | string
    tipoArchivo: string
    profesorId: number
    grupoId: number
  }

  export type MaterialEducativoCreateOrConnectWithoutArchivoInput = {
    where: MaterialEducativoWhereUniqueInput
    create: XOR<MaterialEducativoCreateWithoutArchivoInput, MaterialEducativoUncheckedCreateWithoutArchivoInput>
  }

  export type MaterialEducativoUpsertWithoutArchivoInput = {
    update: XOR<MaterialEducativoUpdateWithoutArchivoInput, MaterialEducativoUncheckedUpdateWithoutArchivoInput>
    create: XOR<MaterialEducativoCreateWithoutArchivoInput, MaterialEducativoUncheckedCreateWithoutArchivoInput>
    where?: MaterialEducativoWhereInput
  }

  export type MaterialEducativoUpdateToOneWithWhereWithoutArchivoInput = {
    where?: MaterialEducativoWhereInput
    data: XOR<MaterialEducativoUpdateWithoutArchivoInput, MaterialEducativoUncheckedUpdateWithoutArchivoInput>
  }

  export type MaterialEducativoUpdateWithoutArchivoInput = {
    titulo?: StringFieldUpdateOperationsInput | string
    descripcion?: StringFieldUpdateOperationsInput | string
    categoria?: StringFieldUpdateOperationsInput | string
    existencia?: BoolFieldUpdateOperationsInput | boolean
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    tipoArchivo?: StringFieldUpdateOperationsInput | string
    profesor?: ProfesorUpdateOneRequiredWithoutMaterialesNestedInput
    grupo?: GrupoUpdateOneRequiredWithoutMaterialesNestedInput
  }

  export type MaterialEducativoUncheckedUpdateWithoutArchivoInput = {
    id?: IntFieldUpdateOperationsInput | number
    titulo?: StringFieldUpdateOperationsInput | string
    descripcion?: StringFieldUpdateOperationsInput | string
    categoria?: StringFieldUpdateOperationsInput | string
    existencia?: BoolFieldUpdateOperationsInput | boolean
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    tipoArchivo?: StringFieldUpdateOperationsInput | string
    profesorId?: IntFieldUpdateOperationsInput | number
    grupoId?: IntFieldUpdateOperationsInput | number
  }

  export type ProfesorCreateWithoutMateriaInput = {
    usuario: UsuarioCreateNestedOneWithoutProfesorInput
    materiales?: MaterialEducativoCreateNestedManyWithoutProfesorInput
  }

  export type ProfesorUncheckedCreateWithoutMateriaInput = {
    usuarioId: number
    materiales?: MaterialEducativoUncheckedCreateNestedManyWithoutProfesorInput
  }

  export type ProfesorCreateOrConnectWithoutMateriaInput = {
    where: ProfesorWhereUniqueInput
    create: XOR<ProfesorCreateWithoutMateriaInput, ProfesorUncheckedCreateWithoutMateriaInput>
  }

  export type CalificacionCreateWithoutMateriaInput = {
    parcial1?: number
    parcial2?: number
    ordinario?: number
    final?: number
    fecha?: Date | string
    estudiante: EstudianteCreateNestedOneWithoutCalificacionInput
  }

  export type CalificacionUncheckedCreateWithoutMateriaInput = {
    id?: number
    estudianteId: number
    parcial1?: number
    parcial2?: number
    ordinario?: number
    final?: number
    fecha?: Date | string
  }

  export type CalificacionCreateOrConnectWithoutMateriaInput = {
    where: CalificacionWhereUniqueInput
    create: XOR<CalificacionCreateWithoutMateriaInput, CalificacionUncheckedCreateWithoutMateriaInput>
  }

  export type CalificacionCreateManyMateriaInputEnvelope = {
    data: CalificacionCreateManyMateriaInput | CalificacionCreateManyMateriaInput[]
    skipDuplicates?: boolean
  }

  export type AsistenciaCreateWithoutMateriaInput = {
    parcial1?: number
    parcial2?: number
    final?: number
    fecha?: Date | string
    estudiante: EstudianteCreateNestedOneWithoutAsistenciaInput
  }

  export type AsistenciaUncheckedCreateWithoutMateriaInput = {
    id?: number
    estudianteId: number
    parcial1?: number
    parcial2?: number
    final?: number
    fecha?: Date | string
  }

  export type AsistenciaCreateOrConnectWithoutMateriaInput = {
    where: AsistenciaWhereUniqueInput
    create: XOR<AsistenciaCreateWithoutMateriaInput, AsistenciaUncheckedCreateWithoutMateriaInput>
  }

  export type AsistenciaCreateManyMateriaInputEnvelope = {
    data: AsistenciaCreateManyMateriaInput | AsistenciaCreateManyMateriaInput[]
    skipDuplicates?: boolean
  }

  export type ProfesorUpsertWithoutMateriaInput = {
    update: XOR<ProfesorUpdateWithoutMateriaInput, ProfesorUncheckedUpdateWithoutMateriaInput>
    create: XOR<ProfesorCreateWithoutMateriaInput, ProfesorUncheckedCreateWithoutMateriaInput>
    where?: ProfesorWhereInput
  }

  export type ProfesorUpdateToOneWithWhereWithoutMateriaInput = {
    where?: ProfesorWhereInput
    data: XOR<ProfesorUpdateWithoutMateriaInput, ProfesorUncheckedUpdateWithoutMateriaInput>
  }

  export type ProfesorUpdateWithoutMateriaInput = {
    usuario?: UsuarioUpdateOneRequiredWithoutProfesorNestedInput
    materiales?: MaterialEducativoUpdateManyWithoutProfesorNestedInput
  }

  export type ProfesorUncheckedUpdateWithoutMateriaInput = {
    usuarioId?: IntFieldUpdateOperationsInput | number
    materiales?: MaterialEducativoUncheckedUpdateManyWithoutProfesorNestedInput
  }

  export type CalificacionUpsertWithWhereUniqueWithoutMateriaInput = {
    where: CalificacionWhereUniqueInput
    update: XOR<CalificacionUpdateWithoutMateriaInput, CalificacionUncheckedUpdateWithoutMateriaInput>
    create: XOR<CalificacionCreateWithoutMateriaInput, CalificacionUncheckedCreateWithoutMateriaInput>
  }

  export type CalificacionUpdateWithWhereUniqueWithoutMateriaInput = {
    where: CalificacionWhereUniqueInput
    data: XOR<CalificacionUpdateWithoutMateriaInput, CalificacionUncheckedUpdateWithoutMateriaInput>
  }

  export type CalificacionUpdateManyWithWhereWithoutMateriaInput = {
    where: CalificacionScalarWhereInput
    data: XOR<CalificacionUpdateManyMutationInput, CalificacionUncheckedUpdateManyWithoutMateriaInput>
  }

  export type AsistenciaUpsertWithWhereUniqueWithoutMateriaInput = {
    where: AsistenciaWhereUniqueInput
    update: XOR<AsistenciaUpdateWithoutMateriaInput, AsistenciaUncheckedUpdateWithoutMateriaInput>
    create: XOR<AsistenciaCreateWithoutMateriaInput, AsistenciaUncheckedCreateWithoutMateriaInput>
  }

  export type AsistenciaUpdateWithWhereUniqueWithoutMateriaInput = {
    where: AsistenciaWhereUniqueInput
    data: XOR<AsistenciaUpdateWithoutMateriaInput, AsistenciaUncheckedUpdateWithoutMateriaInput>
  }

  export type AsistenciaUpdateManyWithWhereWithoutMateriaInput = {
    where: AsistenciaScalarWhereInput
    data: XOR<AsistenciaUpdateManyMutationInput, AsistenciaUncheckedUpdateManyWithoutMateriaInput>
  }

  export type EstudianteCreateWithoutCalificacionInput = {
    estado?: $Enums.EstadoEstudiante
    tramites?: TramiteCreateNestedManyWithoutEstudianteInput
    grupo?: GrupoCreateNestedOneWithoutEstudiantesInput
    usuario: UsuarioCreateNestedOneWithoutEstudianteInput
    PadreFamilia?: PadreFamiliaCreateNestedOneWithoutEstudiantesInput
    Asistencia?: AsistenciaCreateNestedManyWithoutEstudianteInput
  }

  export type EstudianteUncheckedCreateWithoutCalificacionInput = {
    usuarioId: number
    grupoId?: number | null
    padreFamiliaId?: number | null
    estado?: $Enums.EstadoEstudiante
    tramites?: TramiteUncheckedCreateNestedManyWithoutEstudianteInput
    Asistencia?: AsistenciaUncheckedCreateNestedManyWithoutEstudianteInput
  }

  export type EstudianteCreateOrConnectWithoutCalificacionInput = {
    where: EstudianteWhereUniqueInput
    create: XOR<EstudianteCreateWithoutCalificacionInput, EstudianteUncheckedCreateWithoutCalificacionInput>
  }

  export type MateriaCreateWithoutCalificacionInput = {
    nombre: string
    profesor: ProfesorCreateNestedOneWithoutMateriaInput
    Asistencia?: AsistenciaCreateNestedManyWithoutMateriaInput
  }

  export type MateriaUncheckedCreateWithoutCalificacionInput = {
    id?: number
    nombre: string
    profesorId: number
    Asistencia?: AsistenciaUncheckedCreateNestedManyWithoutMateriaInput
  }

  export type MateriaCreateOrConnectWithoutCalificacionInput = {
    where: MateriaWhereUniqueInput
    create: XOR<MateriaCreateWithoutCalificacionInput, MateriaUncheckedCreateWithoutCalificacionInput>
  }

  export type EstudianteUpsertWithoutCalificacionInput = {
    update: XOR<EstudianteUpdateWithoutCalificacionInput, EstudianteUncheckedUpdateWithoutCalificacionInput>
    create: XOR<EstudianteCreateWithoutCalificacionInput, EstudianteUncheckedCreateWithoutCalificacionInput>
    where?: EstudianteWhereInput
  }

  export type EstudianteUpdateToOneWithWhereWithoutCalificacionInput = {
    where?: EstudianteWhereInput
    data: XOR<EstudianteUpdateWithoutCalificacionInput, EstudianteUncheckedUpdateWithoutCalificacionInput>
  }

  export type EstudianteUpdateWithoutCalificacionInput = {
    estado?: EnumEstadoEstudianteFieldUpdateOperationsInput | $Enums.EstadoEstudiante
    tramites?: TramiteUpdateManyWithoutEstudianteNestedInput
    grupo?: GrupoUpdateOneWithoutEstudiantesNestedInput
    usuario?: UsuarioUpdateOneRequiredWithoutEstudianteNestedInput
    PadreFamilia?: PadreFamiliaUpdateOneWithoutEstudiantesNestedInput
    Asistencia?: AsistenciaUpdateManyWithoutEstudianteNestedInput
  }

  export type EstudianteUncheckedUpdateWithoutCalificacionInput = {
    usuarioId?: IntFieldUpdateOperationsInput | number
    grupoId?: NullableIntFieldUpdateOperationsInput | number | null
    padreFamiliaId?: NullableIntFieldUpdateOperationsInput | number | null
    estado?: EnumEstadoEstudianteFieldUpdateOperationsInput | $Enums.EstadoEstudiante
    tramites?: TramiteUncheckedUpdateManyWithoutEstudianteNestedInput
    Asistencia?: AsistenciaUncheckedUpdateManyWithoutEstudianteNestedInput
  }

  export type MateriaUpsertWithoutCalificacionInput = {
    update: XOR<MateriaUpdateWithoutCalificacionInput, MateriaUncheckedUpdateWithoutCalificacionInput>
    create: XOR<MateriaCreateWithoutCalificacionInput, MateriaUncheckedCreateWithoutCalificacionInput>
    where?: MateriaWhereInput
  }

  export type MateriaUpdateToOneWithWhereWithoutCalificacionInput = {
    where?: MateriaWhereInput
    data: XOR<MateriaUpdateWithoutCalificacionInput, MateriaUncheckedUpdateWithoutCalificacionInput>
  }

  export type MateriaUpdateWithoutCalificacionInput = {
    nombre?: StringFieldUpdateOperationsInput | string
    profesor?: ProfesorUpdateOneRequiredWithoutMateriaNestedInput
    Asistencia?: AsistenciaUpdateManyWithoutMateriaNestedInput
  }

  export type MateriaUncheckedUpdateWithoutCalificacionInput = {
    id?: IntFieldUpdateOperationsInput | number
    nombre?: StringFieldUpdateOperationsInput | string
    profesorId?: IntFieldUpdateOperationsInput | number
    Asistencia?: AsistenciaUncheckedUpdateManyWithoutMateriaNestedInput
  }

  export type EstudianteCreateWithoutAsistenciaInput = {
    estado?: $Enums.EstadoEstudiante
    tramites?: TramiteCreateNestedManyWithoutEstudianteInput
    grupo?: GrupoCreateNestedOneWithoutEstudiantesInput
    usuario: UsuarioCreateNestedOneWithoutEstudianteInput
    PadreFamilia?: PadreFamiliaCreateNestedOneWithoutEstudiantesInput
    Calificacion?: CalificacionCreateNestedManyWithoutEstudianteInput
  }

  export type EstudianteUncheckedCreateWithoutAsistenciaInput = {
    usuarioId: number
    grupoId?: number | null
    padreFamiliaId?: number | null
    estado?: $Enums.EstadoEstudiante
    tramites?: TramiteUncheckedCreateNestedManyWithoutEstudianteInput
    Calificacion?: CalificacionUncheckedCreateNestedManyWithoutEstudianteInput
  }

  export type EstudianteCreateOrConnectWithoutAsistenciaInput = {
    where: EstudianteWhereUniqueInput
    create: XOR<EstudianteCreateWithoutAsistenciaInput, EstudianteUncheckedCreateWithoutAsistenciaInput>
  }

  export type MateriaCreateWithoutAsistenciaInput = {
    nombre: string
    profesor: ProfesorCreateNestedOneWithoutMateriaInput
    Calificacion?: CalificacionCreateNestedManyWithoutMateriaInput
  }

  export type MateriaUncheckedCreateWithoutAsistenciaInput = {
    id?: number
    nombre: string
    profesorId: number
    Calificacion?: CalificacionUncheckedCreateNestedManyWithoutMateriaInput
  }

  export type MateriaCreateOrConnectWithoutAsistenciaInput = {
    where: MateriaWhereUniqueInput
    create: XOR<MateriaCreateWithoutAsistenciaInput, MateriaUncheckedCreateWithoutAsistenciaInput>
  }

  export type EstudianteUpsertWithoutAsistenciaInput = {
    update: XOR<EstudianteUpdateWithoutAsistenciaInput, EstudianteUncheckedUpdateWithoutAsistenciaInput>
    create: XOR<EstudianteCreateWithoutAsistenciaInput, EstudianteUncheckedCreateWithoutAsistenciaInput>
    where?: EstudianteWhereInput
  }

  export type EstudianteUpdateToOneWithWhereWithoutAsistenciaInput = {
    where?: EstudianteWhereInput
    data: XOR<EstudianteUpdateWithoutAsistenciaInput, EstudianteUncheckedUpdateWithoutAsistenciaInput>
  }

  export type EstudianteUpdateWithoutAsistenciaInput = {
    estado?: EnumEstadoEstudianteFieldUpdateOperationsInput | $Enums.EstadoEstudiante
    tramites?: TramiteUpdateManyWithoutEstudianteNestedInput
    grupo?: GrupoUpdateOneWithoutEstudiantesNestedInput
    usuario?: UsuarioUpdateOneRequiredWithoutEstudianteNestedInput
    PadreFamilia?: PadreFamiliaUpdateOneWithoutEstudiantesNestedInput
    Calificacion?: CalificacionUpdateManyWithoutEstudianteNestedInput
  }

  export type EstudianteUncheckedUpdateWithoutAsistenciaInput = {
    usuarioId?: IntFieldUpdateOperationsInput | number
    grupoId?: NullableIntFieldUpdateOperationsInput | number | null
    padreFamiliaId?: NullableIntFieldUpdateOperationsInput | number | null
    estado?: EnumEstadoEstudianteFieldUpdateOperationsInput | $Enums.EstadoEstudiante
    tramites?: TramiteUncheckedUpdateManyWithoutEstudianteNestedInput
    Calificacion?: CalificacionUncheckedUpdateManyWithoutEstudianteNestedInput
  }

  export type MateriaUpsertWithoutAsistenciaInput = {
    update: XOR<MateriaUpdateWithoutAsistenciaInput, MateriaUncheckedUpdateWithoutAsistenciaInput>
    create: XOR<MateriaCreateWithoutAsistenciaInput, MateriaUncheckedCreateWithoutAsistenciaInput>
    where?: MateriaWhereInput
  }

  export type MateriaUpdateToOneWithWhereWithoutAsistenciaInput = {
    where?: MateriaWhereInput
    data: XOR<MateriaUpdateWithoutAsistenciaInput, MateriaUncheckedUpdateWithoutAsistenciaInput>
  }

  export type MateriaUpdateWithoutAsistenciaInput = {
    nombre?: StringFieldUpdateOperationsInput | string
    profesor?: ProfesorUpdateOneRequiredWithoutMateriaNestedInput
    Calificacion?: CalificacionUpdateManyWithoutMateriaNestedInput
  }

  export type MateriaUncheckedUpdateWithoutAsistenciaInput = {
    id?: IntFieldUpdateOperationsInput | number
    nombre?: StringFieldUpdateOperationsInput | string
    profesorId?: IntFieldUpdateOperationsInput | number
    Calificacion?: CalificacionUncheckedUpdateManyWithoutMateriaNestedInput
  }

  export type PadreFamiliaCreateManyUsuarioInput = {
    domicilio: string
  }

  export type PadreFamiliaUpdateWithoutUsuarioInput = {
    domicilio?: StringFieldUpdateOperationsInput | string
    estudiantes?: EstudianteUpdateManyWithoutPadreFamiliaNestedInput
  }

  export type PadreFamiliaUncheckedUpdateWithoutUsuarioInput = {
    domicilio?: StringFieldUpdateOperationsInput | string
    estudiantes?: EstudianteUncheckedUpdateManyWithoutPadreFamiliaNestedInput
  }

  export type PadreFamiliaUncheckedUpdateManyWithoutUsuarioInput = {
    domicilio?: StringFieldUpdateOperationsInput | string
  }

  export type TramiteCreateManyEstudianteInput = {
    id?: number
    tipo: $Enums.TipoTramite
    estado: $Enums.EstadoTramite
    fecha?: Date | string
  }

  export type CalificacionCreateManyEstudianteInput = {
    id?: number
    materiaId: number
    parcial1?: number
    parcial2?: number
    ordinario?: number
    final?: number
    fecha?: Date | string
  }

  export type AsistenciaCreateManyEstudianteInput = {
    id?: number
    materiaId: number
    parcial1?: number
    parcial2?: number
    final?: number
    fecha?: Date | string
  }

  export type TramiteUpdateWithoutEstudianteInput = {
    tipo?: EnumTipoTramiteFieldUpdateOperationsInput | $Enums.TipoTramite
    estado?: EnumEstadoTramiteFieldUpdateOperationsInput | $Enums.EstadoTramite
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    inscripcion?: InscripcionUpdateOneWithoutTramiteNestedInput
    Pago?: PagoUpdateOneWithoutTramiteNestedInput
  }

  export type TramiteUncheckedUpdateWithoutEstudianteInput = {
    id?: IntFieldUpdateOperationsInput | number
    tipo?: EnumTipoTramiteFieldUpdateOperationsInput | $Enums.TipoTramite
    estado?: EnumEstadoTramiteFieldUpdateOperationsInput | $Enums.EstadoTramite
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    inscripcion?: InscripcionUncheckedUpdateOneWithoutTramiteNestedInput
    Pago?: PagoUncheckedUpdateOneWithoutTramiteNestedInput
  }

  export type TramiteUncheckedUpdateManyWithoutEstudianteInput = {
    id?: IntFieldUpdateOperationsInput | number
    tipo?: EnumTipoTramiteFieldUpdateOperationsInput | $Enums.TipoTramite
    estado?: EnumEstadoTramiteFieldUpdateOperationsInput | $Enums.EstadoTramite
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CalificacionUpdateWithoutEstudianteInput = {
    parcial1?: FloatFieldUpdateOperationsInput | number
    parcial2?: FloatFieldUpdateOperationsInput | number
    ordinario?: FloatFieldUpdateOperationsInput | number
    final?: FloatFieldUpdateOperationsInput | number
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    materia?: MateriaUpdateOneRequiredWithoutCalificacionNestedInput
  }

  export type CalificacionUncheckedUpdateWithoutEstudianteInput = {
    id?: IntFieldUpdateOperationsInput | number
    materiaId?: IntFieldUpdateOperationsInput | number
    parcial1?: FloatFieldUpdateOperationsInput | number
    parcial2?: FloatFieldUpdateOperationsInput | number
    ordinario?: FloatFieldUpdateOperationsInput | number
    final?: FloatFieldUpdateOperationsInput | number
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CalificacionUncheckedUpdateManyWithoutEstudianteInput = {
    id?: IntFieldUpdateOperationsInput | number
    materiaId?: IntFieldUpdateOperationsInput | number
    parcial1?: FloatFieldUpdateOperationsInput | number
    parcial2?: FloatFieldUpdateOperationsInput | number
    ordinario?: FloatFieldUpdateOperationsInput | number
    final?: FloatFieldUpdateOperationsInput | number
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AsistenciaUpdateWithoutEstudianteInput = {
    parcial1?: IntFieldUpdateOperationsInput | number
    parcial2?: IntFieldUpdateOperationsInput | number
    final?: IntFieldUpdateOperationsInput | number
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    materia?: MateriaUpdateOneRequiredWithoutAsistenciaNestedInput
  }

  export type AsistenciaUncheckedUpdateWithoutEstudianteInput = {
    id?: IntFieldUpdateOperationsInput | number
    materiaId?: IntFieldUpdateOperationsInput | number
    parcial1?: IntFieldUpdateOperationsInput | number
    parcial2?: IntFieldUpdateOperationsInput | number
    final?: IntFieldUpdateOperationsInput | number
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AsistenciaUncheckedUpdateManyWithoutEstudianteInput = {
    id?: IntFieldUpdateOperationsInput | number
    materiaId?: IntFieldUpdateOperationsInput | number
    parcial1?: IntFieldUpdateOperationsInput | number
    parcial2?: IntFieldUpdateOperationsInput | number
    final?: IntFieldUpdateOperationsInput | number
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MaterialEducativoCreateManyProfesorInput = {
    id?: number
    titulo: string
    descripcion: string
    categoria: string
    existencia?: boolean
    fecha?: Date | string
    tipoArchivo: string
    grupoId: number
  }

  export type MateriaCreateManyProfesorInput = {
    id?: number
    nombre: string
  }

  export type MaterialEducativoUpdateWithoutProfesorInput = {
    titulo?: StringFieldUpdateOperationsInput | string
    descripcion?: StringFieldUpdateOperationsInput | string
    categoria?: StringFieldUpdateOperationsInput | string
    existencia?: BoolFieldUpdateOperationsInput | boolean
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    tipoArchivo?: StringFieldUpdateOperationsInput | string
    grupo?: GrupoUpdateOneRequiredWithoutMaterialesNestedInput
    archivo?: ArchivoSubidoUpdateManyWithoutMaterialNestedInput
  }

  export type MaterialEducativoUncheckedUpdateWithoutProfesorInput = {
    id?: IntFieldUpdateOperationsInput | number
    titulo?: StringFieldUpdateOperationsInput | string
    descripcion?: StringFieldUpdateOperationsInput | string
    categoria?: StringFieldUpdateOperationsInput | string
    existencia?: BoolFieldUpdateOperationsInput | boolean
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    tipoArchivo?: StringFieldUpdateOperationsInput | string
    grupoId?: IntFieldUpdateOperationsInput | number
    archivo?: ArchivoSubidoUncheckedUpdateManyWithoutMaterialNestedInput
  }

  export type MaterialEducativoUncheckedUpdateManyWithoutProfesorInput = {
    id?: IntFieldUpdateOperationsInput | number
    titulo?: StringFieldUpdateOperationsInput | string
    descripcion?: StringFieldUpdateOperationsInput | string
    categoria?: StringFieldUpdateOperationsInput | string
    existencia?: BoolFieldUpdateOperationsInput | boolean
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    tipoArchivo?: StringFieldUpdateOperationsInput | string
    grupoId?: IntFieldUpdateOperationsInput | number
  }

  export type MateriaUpdateWithoutProfesorInput = {
    nombre?: StringFieldUpdateOperationsInput | string
    Calificacion?: CalificacionUpdateManyWithoutMateriaNestedInput
    Asistencia?: AsistenciaUpdateManyWithoutMateriaNestedInput
  }

  export type MateriaUncheckedUpdateWithoutProfesorInput = {
    id?: IntFieldUpdateOperationsInput | number
    nombre?: StringFieldUpdateOperationsInput | string
    Calificacion?: CalificacionUncheckedUpdateManyWithoutMateriaNestedInput
    Asistencia?: AsistenciaUncheckedUpdateManyWithoutMateriaNestedInput
  }

  export type MateriaUncheckedUpdateManyWithoutProfesorInput = {
    id?: IntFieldUpdateOperationsInput | number
    nombre?: StringFieldUpdateOperationsInput | string
  }

  export type EstudianteCreateManyPadreFamiliaInput = {
    usuarioId: number
    grupoId?: number | null
    estado?: $Enums.EstadoEstudiante
  }

  export type EstudianteUpdateWithoutPadreFamiliaInput = {
    estado?: EnumEstadoEstudianteFieldUpdateOperationsInput | $Enums.EstadoEstudiante
    tramites?: TramiteUpdateManyWithoutEstudianteNestedInput
    grupo?: GrupoUpdateOneWithoutEstudiantesNestedInput
    usuario?: UsuarioUpdateOneRequiredWithoutEstudianteNestedInput
    Calificacion?: CalificacionUpdateManyWithoutEstudianteNestedInput
    Asistencia?: AsistenciaUpdateManyWithoutEstudianteNestedInput
  }

  export type EstudianteUncheckedUpdateWithoutPadreFamiliaInput = {
    usuarioId?: IntFieldUpdateOperationsInput | number
    grupoId?: NullableIntFieldUpdateOperationsInput | number | null
    estado?: EnumEstadoEstudianteFieldUpdateOperationsInput | $Enums.EstadoEstudiante
    tramites?: TramiteUncheckedUpdateManyWithoutEstudianteNestedInput
    Calificacion?: CalificacionUncheckedUpdateManyWithoutEstudianteNestedInput
    Asistencia?: AsistenciaUncheckedUpdateManyWithoutEstudianteNestedInput
  }

  export type EstudianteUncheckedUpdateManyWithoutPadreFamiliaInput = {
    usuarioId?: IntFieldUpdateOperationsInput | number
    grupoId?: NullableIntFieldUpdateOperationsInput | number | null
    estado?: EnumEstadoEstudianteFieldUpdateOperationsInput | $Enums.EstadoEstudiante
  }

  export type EstudianteCreateManyGrupoInput = {
    usuarioId: number
    padreFamiliaId?: number | null
    estado?: $Enums.EstadoEstudiante
  }

  export type InscripcionCreateManyGrupoInput = {
    tramiteId: number
  }

  export type MaterialEducativoCreateManyGrupoInput = {
    id?: number
    titulo: string
    descripcion: string
    categoria: string
    existencia?: boolean
    fecha?: Date | string
    tipoArchivo: string
    profesorId: number
  }

  export type EstudianteUpdateWithoutGrupoInput = {
    estado?: EnumEstadoEstudianteFieldUpdateOperationsInput | $Enums.EstadoEstudiante
    tramites?: TramiteUpdateManyWithoutEstudianteNestedInput
    usuario?: UsuarioUpdateOneRequiredWithoutEstudianteNestedInput
    PadreFamilia?: PadreFamiliaUpdateOneWithoutEstudiantesNestedInput
    Calificacion?: CalificacionUpdateManyWithoutEstudianteNestedInput
    Asistencia?: AsistenciaUpdateManyWithoutEstudianteNestedInput
  }

  export type EstudianteUncheckedUpdateWithoutGrupoInput = {
    usuarioId?: IntFieldUpdateOperationsInput | number
    padreFamiliaId?: NullableIntFieldUpdateOperationsInput | number | null
    estado?: EnumEstadoEstudianteFieldUpdateOperationsInput | $Enums.EstadoEstudiante
    tramites?: TramiteUncheckedUpdateManyWithoutEstudianteNestedInput
    Calificacion?: CalificacionUncheckedUpdateManyWithoutEstudianteNestedInput
    Asistencia?: AsistenciaUncheckedUpdateManyWithoutEstudianteNestedInput
  }

  export type EstudianteUncheckedUpdateManyWithoutGrupoInput = {
    usuarioId?: IntFieldUpdateOperationsInput | number
    padreFamiliaId?: NullableIntFieldUpdateOperationsInput | number | null
    estado?: EnumEstadoEstudianteFieldUpdateOperationsInput | $Enums.EstadoEstudiante
  }

  export type InscripcionUpdateWithoutGrupoInput = {
    tramite?: TramiteUpdateOneRequiredWithoutInscripcionNestedInput
  }

  export type InscripcionUncheckedUpdateWithoutGrupoInput = {
    tramiteId?: IntFieldUpdateOperationsInput | number
  }

  export type InscripcionUncheckedUpdateManyWithoutGrupoInput = {
    tramiteId?: IntFieldUpdateOperationsInput | number
  }

  export type MaterialEducativoUpdateWithoutGrupoInput = {
    titulo?: StringFieldUpdateOperationsInput | string
    descripcion?: StringFieldUpdateOperationsInput | string
    categoria?: StringFieldUpdateOperationsInput | string
    existencia?: BoolFieldUpdateOperationsInput | boolean
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    tipoArchivo?: StringFieldUpdateOperationsInput | string
    profesor?: ProfesorUpdateOneRequiredWithoutMaterialesNestedInput
    archivo?: ArchivoSubidoUpdateManyWithoutMaterialNestedInput
  }

  export type MaterialEducativoUncheckedUpdateWithoutGrupoInput = {
    id?: IntFieldUpdateOperationsInput | number
    titulo?: StringFieldUpdateOperationsInput | string
    descripcion?: StringFieldUpdateOperationsInput | string
    categoria?: StringFieldUpdateOperationsInput | string
    existencia?: BoolFieldUpdateOperationsInput | boolean
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    tipoArchivo?: StringFieldUpdateOperationsInput | string
    profesorId?: IntFieldUpdateOperationsInput | number
    archivo?: ArchivoSubidoUncheckedUpdateManyWithoutMaterialNestedInput
  }

  export type MaterialEducativoUncheckedUpdateManyWithoutGrupoInput = {
    id?: IntFieldUpdateOperationsInput | number
    titulo?: StringFieldUpdateOperationsInput | string
    descripcion?: StringFieldUpdateOperationsInput | string
    categoria?: StringFieldUpdateOperationsInput | string
    existencia?: BoolFieldUpdateOperationsInput | boolean
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    tipoArchivo?: StringFieldUpdateOperationsInput | string
    profesorId?: IntFieldUpdateOperationsInput | number
  }

  export type ReciboCreateManyPagoInput = {
    id?: number
    monto: number
    fecha?: Date | string
  }

  export type ReciboUpdateWithoutPagoInput = {
    monto?: FloatFieldUpdateOperationsInput | number
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ReciboUncheckedUpdateWithoutPagoInput = {
    id?: IntFieldUpdateOperationsInput | number
    monto?: FloatFieldUpdateOperationsInput | number
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ReciboUncheckedUpdateManyWithoutPagoInput = {
    id?: IntFieldUpdateOperationsInput | number
    monto?: FloatFieldUpdateOperationsInput | number
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ArchivoSubidoCreateManyMaterialInput = {
    id?: number
    nombreArchivo: string
    urlNube: string
  }

  export type ArchivoSubidoUpdateWithoutMaterialInput = {
    nombreArchivo?: StringFieldUpdateOperationsInput | string
    urlNube?: StringFieldUpdateOperationsInput | string
  }

  export type ArchivoSubidoUncheckedUpdateWithoutMaterialInput = {
    id?: IntFieldUpdateOperationsInput | number
    nombreArchivo?: StringFieldUpdateOperationsInput | string
    urlNube?: StringFieldUpdateOperationsInput | string
  }

  export type ArchivoSubidoUncheckedUpdateManyWithoutMaterialInput = {
    id?: IntFieldUpdateOperationsInput | number
    nombreArchivo?: StringFieldUpdateOperationsInput | string
    urlNube?: StringFieldUpdateOperationsInput | string
  }

  export type CalificacionCreateManyMateriaInput = {
    id?: number
    estudianteId: number
    parcial1?: number
    parcial2?: number
    ordinario?: number
    final?: number
    fecha?: Date | string
  }

  export type AsistenciaCreateManyMateriaInput = {
    id?: number
    estudianteId: number
    parcial1?: number
    parcial2?: number
    final?: number
    fecha?: Date | string
  }

  export type CalificacionUpdateWithoutMateriaInput = {
    parcial1?: FloatFieldUpdateOperationsInput | number
    parcial2?: FloatFieldUpdateOperationsInput | number
    ordinario?: FloatFieldUpdateOperationsInput | number
    final?: FloatFieldUpdateOperationsInput | number
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    estudiante?: EstudianteUpdateOneRequiredWithoutCalificacionNestedInput
  }

  export type CalificacionUncheckedUpdateWithoutMateriaInput = {
    id?: IntFieldUpdateOperationsInput | number
    estudianteId?: IntFieldUpdateOperationsInput | number
    parcial1?: FloatFieldUpdateOperationsInput | number
    parcial2?: FloatFieldUpdateOperationsInput | number
    ordinario?: FloatFieldUpdateOperationsInput | number
    final?: FloatFieldUpdateOperationsInput | number
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CalificacionUncheckedUpdateManyWithoutMateriaInput = {
    id?: IntFieldUpdateOperationsInput | number
    estudianteId?: IntFieldUpdateOperationsInput | number
    parcial1?: FloatFieldUpdateOperationsInput | number
    parcial2?: FloatFieldUpdateOperationsInput | number
    ordinario?: FloatFieldUpdateOperationsInput | number
    final?: FloatFieldUpdateOperationsInput | number
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AsistenciaUpdateWithoutMateriaInput = {
    parcial1?: IntFieldUpdateOperationsInput | number
    parcial2?: IntFieldUpdateOperationsInput | number
    final?: IntFieldUpdateOperationsInput | number
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
    estudiante?: EstudianteUpdateOneRequiredWithoutAsistenciaNestedInput
  }

  export type AsistenciaUncheckedUpdateWithoutMateriaInput = {
    id?: IntFieldUpdateOperationsInput | number
    estudianteId?: IntFieldUpdateOperationsInput | number
    parcial1?: IntFieldUpdateOperationsInput | number
    parcial2?: IntFieldUpdateOperationsInput | number
    final?: IntFieldUpdateOperationsInput | number
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AsistenciaUncheckedUpdateManyWithoutMateriaInput = {
    id?: IntFieldUpdateOperationsInput | number
    estudianteId?: IntFieldUpdateOperationsInput | number
    parcial1?: IntFieldUpdateOperationsInput | number
    parcial2?: IntFieldUpdateOperationsInput | number
    final?: IntFieldUpdateOperationsInput | number
    fecha?: DateTimeFieldUpdateOperationsInput | Date | string
  }



  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}